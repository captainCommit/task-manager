var changedRowIndexArr=[];
var changedarr=[];
var today = new Date();
var dd = String(today.getDate()).padStart(2, '0');
var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
var yyyy = today.getFullYear();
today = mm + '/' + dd + '/' + yyyy;
function Handson(containerid){
  
         var container = document.getElementById(containerid);
   //     var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
        
        var options = {
          data:[],
           colWidths: [100,120,140,100,100,130,100,100,100,100,100,100,100,450,130,100,100,100,100,100,100,100,100,100],
            //  rowHeights:20,
           comments: true,
                search:true,
                /*columnSorting: true,
                sortIndicator: true,*/
                manualColumnResize: true,
                manualRowResize: true, 
                preventOverflow: 'horizontal',
             //   filters:true,
               // multiselect:true,
                colHeaders:true,
                contextMenu: {
                       items: {  "copy": {name: "Copy"},
                           "paste": {
                               name: 'Paste',
                               callback: function () {
                                   this.copyPaste.triggerPaste();
                               }
                           } }
                   },
                contextMenuCopyPaste: {
                    swfPath: 'js/ZeroClipboard.swf'
                  },
               afterChange: function(changes, source){
                if(source === 'edit' || source === 'paste'){
                   if((changedRowIndexArr!=null && changedRowIndexArr.length==0) || $.inArray(changes[0][0], changedRowIndexArr) == -1){
                    changedRowIndexArr.push(changes[0][0]);
                   }
                    }
               } , 
            
              
             /* afterOnCellMouseDown: function(event, coords){
                  // 'coords.row < 0' because we only want to handle clicks on the header row
                 // alert(coords.row);
                var rowTemp= coords.row;
                 var data=this.getDataAtRow(coords.row);
                 var data1 = JSON.stringify(data);
                 var b= getIsLockedContract(data1);
                
                 if(b == true)
            {
             alert("This row is being edited by some other user....Please try after some time");
             this.deselectCell();
             if(rowTemp == 0){
               this.selectCell(rowTemp+1,rowTemp+1);
             }else{
               this.selectCell(rowTemp-1,rowTemp-1);
             }
             
             return false;
            }
           
              },
              */
             /* contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        }
                    }*/
              
                        /*"row_above":{name: "Insert a row above"
                          
                      },
                    "row_below":{name: "Insert a row below"},
                   "remove_row":{name: "Remove",
                     callback: function(key, selection) {
                          var amount = selection.end.row - selection.start.row + 1;
                          if(amount>1){
                            alert("Please select only one row to delete");
                            return false;
                          }else{
                            var strconfirm = confirm("Are you sure you want to delete?");
                              if (strconfirm == false) {
                                  return false;
                              }
                         var data=this.getDataAtRow(selection.start.row);
                          var data1 = JSON.stringify(data);
                          //alert("data: "+data1);
                          jQuery.ajax({
                                  type:"POST",
                                  dataType:"json",
                                  url:urlPrefix+"/JanssenSCG/deleteRow",                    
                                  data:{data: data1},
                                  async:false,
                                  success: function(responseText) { 
                                      Response= responseText;                                      
                                        },
                           complete: function(){
                                fil = Response[0];
                                        }
                             });
                          //removeRow(data1);
                          this.alter('remove_row', selection.start.row, amount);
                     }
                        }
                     }
                      }*/
               /* },
              contextMenuCopyPaste: {
                  swfPath: 'js/ZeroClipboard.swf'
                },*/
              fixedColumnsLeft: 7,
              manualColumnFreeze:true,
             
            //  dropdownMenu: true,
            //  filters:true,
              nestedHeaders: [
                              [{label: ' ', colspan:7},{label: 'OD Input', colspan:17},{label:' ',colspan:1}],
                            
                             ['OD Contact','Account Lead','Customer','Channel','Product','Unique Identifier','Date Offer Requested','Document Type','Customer Type','Book Of Business','Medical/Pharmacy','Effective Date','End Date','Comments','Attachement(If any)','Contract Delivery Date','CPC Approval','CPC Approval Date','Execution Date','Lost Date','TRIM Number','Date Request Sent To ECS','Contract Status','Delete?']],
                 columns: [
                               
                               
                                {   
                        data:'odLead',
                        renderer:safeHtmlRenderer,
                      readOnly:true
                       },
                       {   
                        data:'accountLead',
                        renderer:safeHtmlRenderer,
                        readOnly:true
                     },
                     {   
                          data:'accountName',
                          renderer:safeHtmlRenderer,
                          readOnly:true
                       },
                    {   
                       data:'channel',
                       renderer:safeHtmlRenderer, 
                       readOnly:true
                     },
                     {   
                         data:'product',
                         renderer:safeHtmlRenderer,  
                         readOnly:true
                       },
                                     {
                                          data:'uniqueIdentifier',
                                       renderer:safeHtmlRenderer,
                                          readOnly:true
                                       },
                                        {
                                        data:'startDate',
                                           renderer:safeHtmlRenderer,
                                             readOnly:true
                                          },
                                       {
                                          data:'documentType',
                                        editor: 'select',
                                      renderer:safeHtmlRenderereditable,
                                        selectOptions: ['Amendment','Contract','Master','NDA','Notice','Term Sheet','Proposal','Waiver','Letter'],
                                        readOnly:false
                                       },
                                       
                                     {
                                       data:'customerType',
                                       editor: 'select',
                                     renderer:safeHtmlRenderereditable,
                                       selectOptions: ['MBM - Capitated','MBM - Limited','MCO','PBM',' '],
                                       readOnly:false
                                       },
                                      
                                      {
                                        data:'bookOfBusiness',
                                      editor: 'select',
                                       renderer:safeHtmlRenderereditable,
                                         selectOptions: ['CHIP','Commercial','Managed Medicaid','Medicare Advantage','Medicare Part D','QHP','Others-See Comments'],
                                         readOnly:false
                                        },
                                        {
                                         data:'medicalPharmacy' ,
                                         editor: 'select',
                                         renderer: safeHtmlRenderereditable,
                                           selectOptions: ['Medical','Medical if Pharmacy','Pharmacy','Pharmacy if Medical','Pharmacy and Medical','Others-See Comments'],
                                         readOnly:false
                                           
                                        
                                        },
                                        {
                                       data:'effectiveDate',
                                      type: 'date',
                                      dateFormat: 'MM/DD/YYYY',
                                          correctFormat: true,
                                          //  defaultDate: '06/29/2016',
                                          allowEmpty: false,
                                        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                          datePickerConfig: {
                                          // First day of the week (0: Sunday, 1: Monday, etc)
                                          firstDay: 0,
                                          showWeekNumber: true,
                                          numberOfMonths: 1,
                                          disableDayFn: function(date)
                            	        	{   }
                                          
                                        },
                                      renderer:safeHtmlDateRenderereditable,
                                      readOnly:false
                                    
                                    },
                                        
                                        {
                                           data:'endDate',
                                          type: 'date',
                                          dateFormat: 'MM/DD/YYYY',
                                              correctFormat: true,
                                              //    defaultDate: '06/29/2016',
                                          allowEmpty: false,
                                        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                          datePickerConfig: {
                                          // First day of the week (0: Sunday, 1: Monday, etc)
                                          firstDay: 0,
                                          showWeekNumber: true,
                                          numberOfMonths: 1,
                                          disableDayFn: function(date)
                            	        	{   }
                                          
                                        },
                                      renderer:safeHtmlDateRenderereditable,
                                      readOnly:false
                                        
                                        },
                                      {
                                          data:'comments',
                                          renderer:safeHtmlRenderereditable,
                                          readOnly:false
                                      },
                                      {
                                        data:'fileExtension',
                                      readOnly:true,
                                      renderer:customRenderer
                                      },
                                      //od
                                      {
                                      data:'contractDeliverydate',
                                       type: 'date',
                                       dateFormat: 'MM/DD/YYYY',
                                            correctFormat: true,
                                            //   defaultDate: '06/29/2016',
                                        allowEmpty: false,
                                      // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                        datePickerConfig: {
                                        // First day of the week (0: Sunday, 1: Monday, etc)
                                        firstDay: 0,
                                        showWeekNumber: true,
                                        numberOfMonths: 1,
                                        
                                      },
                                      renderer:safeHtmlRenderereditable,
                                      readOnly:false
                                      },
                                      {
                                          data:'cpcApproval',
                                        editor: 'select',
                                      renderer:safeHtmlRenderereditable,
                                        selectOptions: ['Yes', 'No'],
                                        readOnly:false
                                       },
                                      
                                        {
                                            data:'cpcApprovalDate',
                                             type: 'date',
                                             dateFormat: 'MM/DD/YYYY',
                                                  correctFormat: true,
                                                  //    defaultDate: '06/29/2016',
                                              allowEmpty: false,
                                            // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                              datePickerConfig: {
                                              // First day of the week (0: Sunday, 1: Monday, etc)
                                              firstDay: 0,
                                              showWeekNumber: true,
                                              numberOfMonths: 1,
                                              disableDayFn: function(date)
                              	        	{   }
                                              
                                              },
                                            renderer:safeHtmlRenderereditable,
                                            readOnly:false
                                            },
                                      {
                                      data:'executionDate',
                                       type: 'date',
                                       dateFormat: 'MM/DD/YYYY',
                                            correctFormat: true,
                                            //  defaultDate: '06/29/2016',
                                        allowEmpty: false,
                                      // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                        datePickerConfig: {
                                        // First day of the week (0: Sunday, 1: Monday, etc)
                                        firstDay: 0,
                                        showWeekNumber: true,
                                        numberOfMonths: 1,
                                        disableDayFn: function(date)
                          	        	{   }
                                        
                                        },
                                      renderer:safeHtmlRenderereditable,
                                      readOnly:false
                                      },
                                      {
                                      data:'lostDate',
                                       type: 'date',
                                       dateFormat: 'MM/DD/YYYY',
                                       correctFormat: true,
                                       //defaultDate: '06/29/2016',
                                        allowEmpty: false,
                                      // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                        datePickerConfig: {
                                        // First day of the week (0: Sunday, 1: Monday, etc)
                                        firstDay: 0,
                                        showWeekNumber: true,
                                        numberOfMonths: 1,
                                        disableDayFn: function(date)
                          	        	{   }
                                        
                                        },
                                      renderer:safeHtmlRenderereditable,
                                      readOnly:false
                                      },
                                      {
                                        data:'trimNo',
                                        readOnly:false,
                                        renderer:safeHtmlRenderereditable
                                      },
                                      
                                    	  {
                                              data:'dateRequestSent',
                                              type: 'date',
                                 	    	  dateFormat: 'MM/DD/YYYY',
                               	          correctFormat: true,
                               	          defaultDate: today,
                               	          allowEmpty: true,
                               	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                               	          datePickerConfig: {
                               	          // First day of the week (0: Sunday, 1: Monday, etc)
                               	          
                               	        	disableDayFn: function(date)
                               	        	{  return date.getDay() === 0 || date.getDay() === 6 || moment().isBefore(moment(date), 'day')|| moment(); } 
                               	          
                               	                            },
                               	     readOnly:false,
                               	     renderer:safeHtmlRenderereditable
                                     
                                              },
                                      {
                                        data:'contractStatus',
                                        readOnly:true,
                                        renderer:safeHtmlRenderer
                                      },
                                      {
                                        data:'delete',
                                        readOnly:true,
                                        renderer:customDeleteRenderer
                                      },
                                      ] ,
                                  
                                        afterGetColHeader: function(col, TH) {
                          var TR = TH.parentNode;
                          var THEAD = TR.parentNode;
                          var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                          function applyClass(elem, className) {
                            if (!Handsontable.Dom.hasClass(elem, className)) {
                              Handsontable.Dom.addClass(elem, className);
                            }
                          }

                          // first level from the top
                          if (headerLevel === -2 && (col===0||col===1||col===2||col===3||col===4||col===5||col===6)) {
                              applyClass(TH, 'color2');

                            // second level from the top
                            }else if (headerLevel === -2 && (col>6 && col<21)) {
                                applyClass(TH, 'contractodinputcolor');

                              // second level from the top
                             /* } else if (headerLevel === -2 && (col>15 && col<22)) {
                                  applyClass(TH, 'contractodinputcolor');*/

                                // second level from the top
                                } else if (headerLevel === -1) {
                              applyClass(TH, 'color1');
                               
                            }
                         
                       }
                          
          
            }
        
        var network = new Handsontable(container, options);
        
        this.updateOptions = function(newOptions){
          console.log("inside update");
          network.updateSettings(newOptions);
        }
        
        this.render = function(){
          console.log("inside render");
          network.render();
        }
        
        this.getSourceData = function(){
          console.log("inside source");
           return network.getSourceData();
          
        }
        
        var numberValidator = /^\d+$/;
        /*var notEmpty = function (value, callback) {
          alert("dghjfdhg");
          var numberValidator = /^\d+$/;
          var patt = new RegExp("/^\d+$/");
            if (patt.test(value)) {
                alert("a number");
                
            } else {
               alert("not a number");
               callback(false);
            }
        };*/
        
        function getIsLockedContract(data1)
        {
        
        jQuery.ajax({
          type:"get",
          dataType:"json",
          url:urlPrefix+"/JanssenSCG/lockStatusContract",
          data:{data:data1},
          async:false,
          success: function(responseText) { 
              Response= responseText;
        },
        complete: function(){
          data = Response;
         }
         });
         
         return data;
        }
        
        
}
            
function viewfile(filename){
  //alert("view attachment"+filename);
  flag=true;
   var form = $('<form></form>').attr('action', "/JanssenSCG/viewAttachement").attr('method', 'post');
      // Add the one key/value
      form.append($("<input></input>").attr('type', 'hidden').attr('name', 'filename').attr('value', filename));
      //send request
      form.appendTo('body').submit().remove();
      
  /*jQuery.ajax({
    type:"post",
    dataType:"json",
    url:urlPrefix+"/JanssenSCG/viewAttachement",
    data:{data:filename},
    async:false,
    success: function(responseText) { 
      alert(success);
        //Response= responseText;
  },
  complete: function(){
    //data = Response;
   }
   });*/
}

function deleteRow(uniqueId){
  var Response;
   swal({
          title: "Are you sure?",
          text: "Are you sure you want to Delete?",
          type: "warning",
          showCancelButton: true,
          confirmButtonColor: "#DD6B55",
          confirmButtonText: "Yes",
          cancelButtonText: "No",
          closeOnConfirm: true,
          closeOnCancel: true
      },
        function(isConfirm) {
            if (isConfirm) {
              jQuery.ajax({
                        type:"POST",
                        dataType:"json",
                        url:urlPrefix+"/JanssenSCG/deleteRow",                    
                        data:{data: uniqueId},
                        async:false,
                        success: function(responseText) { 
                          Response=responseText;
                                                                  
                          },
                       complete: function(){
                         if(Response.saveSuccessMsg){
                           handsonComm.updateOptions({                  
                          data:getData()
                           });
                           handsonComm.render();
                         }else{
                           alert("Some erorr has occured!!Please contact IT!");
                         }
                        }
                   });
              
            }
            
          }
            
            
        );
}


function customRenderer(instance, td, row, col, prop, value, cellProperties) {
  
     var value1;
  //alert(value);
     var rowdata=instance.getSourceDataAtRow(row);
   
         //var uniqueId='"'+rowdata.uniqueIdentifier+'"';
         var uniqueId='"'+rowdata.id+'"';
        // alert("Row::"+uniqueId);
            if(value == null ){
                 value1="";
                  var workaround = "<div>"+value1+"</div>";
                   $(td).html(workaround);
                  }else{
                   //alert("else");
                  var workaround = "<input type='button' style='margin-top:20px' value='View Attachment' id='file_viewer"+rowdata.uniqueIdentifier+"' onclick='viewfile("+uniqueId+");'/>";
                 // $(td).css({"margin-top":'20px'});
                   $(td).html(workaround);
                  
                  }
           
          return td;
    }

function customDeleteRenderer(instance, td, row, col, prop, value, cellProperties) {  
     var value1;
  //alert(value);
     var rowdata=instance.getSourceDataAtRow(row); 
         var uniqueId=rowdata.id;
        
                  var workaround = "<div><button type='button' class='btn btn-primary' style='margin-top:20px' id='delete"+rowdata.id+"' onclick='deleteRow("+uniqueId+");'>Delete</button></div>";
                 // $(td).css({"margin-top":'20px'});
                   $(td).html(workaround);
             
       return td;
    }
