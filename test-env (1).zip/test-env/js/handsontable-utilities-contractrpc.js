var changedRowIndexArr=[];
var changedarr=[];
function Handson(containerid){
  
         var container = document.getElementById(containerid);
   //     var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
        
        var options = {
          data:[],
           colWidths: [100,150,100,90,90,120,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,450,130,130,100,100,100,100,100,90,100,100,100,100,100,140,100,100,100,100],
            //  rowHeights:20,
           comments: true,
                search:true,
                /*columnSorting: true,
                sortIndicator: true,*/
                manualColumnResize: true,
                manualRowResize: true, 
                preventOverflow: 'horizontal',
             //   filters:true,
                colHeaders:true,
             viewportColumnRenderingOffset:38,
                contextMenu: {
                       items: {  "copy": {name: "Copy"},
                           "paste": {
                               name: 'Paste',
                               callback: function () {
                                   this.copyPaste.triggerPaste();
                               }
                           } }
                   },
                contextMenuCopyPaste: {
                    swfPath: 'js/ZeroClipboard.swf'
                  },
               afterChange: function(changes, source){
            	   if(source === 'edit' ){
                       if((changedRowIndexArr!=null && changedRowIndexArr.length==0) || $.inArray(changes[0][0], changedRowIndexArr) == -1){
                        changedRowIndexArr.push(changes[0][0]);
                        src=source;
                       }
                        }
                  
                    if(source === 'paste')
                	{
                    	 for (var i = 0; i < changes.length; i++) {
                             if(changedRowIndexArr.indexOf(changes[i][0]) < 0){
                             	changedRowIndexArr.push(changes[i][0]);
                             }
                           }
                    	src=source;
                    	
                		
                	}
                   } ,
            
              
             /* afterOnCellMouseDown: function(event, coords){
                  // 'coords.row < 0' because we only want to handle clicks on the header row
                 // alert(coords.row);
                var rowTemp= coords.row;
                 var data=this.getDataAtRow(coords.row);
                 var data1 = JSON.stringify(data);
                 var b= getIsLockedContract(data1);
                
                 if(b == true)
            {
             alert("This row is being edited by some other user....Please try after some time");
             this.deselectCell();
             if(rowTemp == 0){
               this.selectCell(rowTemp+1,rowTemp+1);
             }else{
               this.selectCell(rowTemp-1,rowTemp-1);
             }
             
             return false;
            }
           
              },
              */
             /* contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        }
                    }*/
              
                        /*"row_above":{name: "Insert a row above"
                          
                      },
                    "row_below":{name: "Insert a row below"},
                   "remove_row":{name: "Remove",
                     callback: function(key, selection) {
                          var amount = selection.end.row - selection.start.row + 1;
                          if(amount>1){
                            alert("Please select only one row to delete");
                            return false;
                          }else{
                            var strconfirm = confirm("Are you sure you want to delete?");
                              if (strconfirm == false) {
                                  return false;
                              }
                         var data=this.getDataAtRow(selection.start.row);
                          var data1 = JSON.stringify(data);
                          //alert("data: "+data1);
                          jQuery.ajax({
                                  type:"POST",
                                  dataType:"json",
                                  url:urlPrefix+"/JanssenSCG/deleteRow",                    
                                  data:{data: data1},
                                  async:false,
                                  success: function(responseText) { 
                                      Response= responseText;                                      
                                        },
                           complete: function(){
                                fil = Response[0];
                                        }
                             });
                          //removeRow(data1);
                          this.alter('remove_row', selection.start.row, amount);
                     }
                        }
                     }
                      }*/
               /* },
              contextMenuCopyPaste: {
                  swfPath: 'js/ZeroClipboard.swf'
                },*/
              fixedColumnsLeft: 7,
              manualColumnFreeze:true,
             
            //  dropdownMenu: true,
            //  filters:true,
              nestedHeaders: [
                              [{label: ' ', colspan:7},{label: 'Contract Information', colspan:24},{label: 'ECS Input', colspan:9}],
                            
                             ['SMD','Customer','OD Lead','Channel','Product','Unique Identifier','Date Offer Requested','Document Type','Customer Type','Book Of Business','Medical/Pharmacy','EPU Description','Utilization Management','Rebate %','Strategy Name','Performance Rebate %(If App)','IR Annual Ceiling Cap %','Baseline DLP date(if App)','Admin/Service Fee(If App)','Effective Date','End Date','Comments','Attachment(If any)','Contract Delivery Date','CPC Approval','CPC Approval Date','Execution Date (If App)','Lost Date (If App)','TRIM Number','Date Request Sent to ECS','Contract Status','ECS','CORE Action','Extension Time (If App)(Days)','Due Date','Date Activated','Activator(Firstname Lastname)','Contract ID','CRG','ECS Comments','Last Modified By','Last Modified Date'
                              ]],
                 columns: [
                               
                               
                       {   
                        data:'accountLead',
                        renderer:safeHtmlRenderer,
                        readOnly:true
                     },
                     {   
                          data:'accountName',
                          renderer:safeHtmlRenderer,
                          readOnly:true
                       },
                       {   
                            data:'odLead',
                            renderer:safeHtmlRenderer,
                            readOnly:true
                         },
                    {   
                       data:'channel',
                       renderer:safeHtmlRenderer, 
                       readOnly:true
                     },
                     {   
                         data:'product',
                         renderer:safeHtmlRenderer,  
                         readOnly:true
                       },
                                     {
                                          data:'uniqueIdentifier',
                                       renderer:safeHtmlRenderer,
                                          readOnly:true
                                       },
                                      {
                                          data:'startDate',
                                             renderer:safeHtmlRenderer,
                                               readOnly:true
                                            },
                                       {
                                          data:'documentType',
                                        renderer:safeHtmlRenderer,
                                        readOnly:true
                                       },
                                       
                                     {
                                       data:'customerType',
                                    renderer:safeHtmlRenderer,
                                    readOnly:true
                                       },
                                      
                                      {
                                        data:'bookOfBusiness',
                                      renderer:safeHtmlRenderer,
                                        readOnly:true
                                        },
                                        {
                                         data:'medicalPharmacy' ,
                                         renderer:safeHtmlRenderer,
                                              readOnly:true
                                        },
                                        {
                                         data:'epuDescription',
                                        renderer:safeHtmlRenderer,
                                            readOnly:true
                                        },
                                        {
                                           data:'utilizationManagement',
                                           renderer:safeHtmlRenderer,
                                              readOnly:true
                                        
                                        },
                                        {
                                            data:'rebate', 
                                          renderer:safeHtmlRendererPercentage,
                                          readOnly:true
                                           },
                                         {
                                           data:'strategyName',
                                          renderer:safeHtmlRenderer,
                                            readOnly:true
                                         },
                                          {
                                            data:'performanceRebate',
                                         renderer:safeHtmlRendererPercentage,
                                          readOnly:true
                                          },
                                          {
                                            data:'irCeiling',
                                           renderer:safeHtmlRendererPercentage,
                                              readOnly:true
                                            },
                                            
                                        {
                                          data:'baselineDLPDate',
                                          renderer:safeHtmlRenderer,
                                              readOnly:true
                                        },
                                      {
                                        data:'adminFee',
                                        renderer:safeHtmlRendererPercentage,
                                          readOnly:true
                                        },
                                        {
                                            data:'effectiveDate',
                                                renderer:safeHtmlRenderer,
                                                  readOnly:true
                                        },
                                        
                                        {
                                           data:'endDate',
                                           renderer:safeHtmlRenderer,
                                                  readOnly:true
                                        
                                        },
                                      {
                                          data:'comments',
                                          renderer:safeHtmlRenderer,
                                                readOnly:true
                                      },
                                      {
                                        data:'fileExtension',
                                      readOnly:true,
                                      renderer:customRenderer
                                      },
                                    //OD
                                      {
                                      data:'contractDeliverydate',
                                      renderer:safeHtmlRenderer,
                                            readOnly:true
                                      },
                                      {   
                                          data:'cpcApproval', 
                                      renderer:safeHtmlRenderer,
                                          readOnly:true
                                       },
                                       {   
                                           data:'cpcApprovalDate', 
                                       renderer:safeHtmlRenderer,
                                           readOnly:true
                                        },
                                      {
                                      data:'executionDate',
                                      renderer:safeHtmlRenderer,
                                            readOnly:true
                                      },
                                      {
                                      data:'lostDate',
                                      renderer:safeHtmlRenderer,
                                            readOnly:true
                                      },
                                      {
                                        data:'trimNo',
                                        readOnly:true,
                                        renderer:safeHtmlRenderer
                                      },
                                      {
                                      data:'dateRequestSent',
                                      renderer:safeHtmlRenderer,
                                            readOnly:true
                                      },
                                     
                                      {
                                        data:'contractStatus',
                                        readOnly:true,
                                        renderer:safeHtmlRenderer
                                      },

                                      //RPC
                                      {   
                          data:'contractAnalystOps',
                          renderer:safeHtmlRenderer,
                          readOnly:true
                       },
                       {   
                          data:'carsAction',
                          editor: 'select',
                          renderer:safeHtmlRenderereditable,
                            selectOptions: ['Yes','No'],
                            readOnly:false
                       },
                       {   
                         data:'extensionTime',
                                    renderer:safeHtmlRenderereditableNumeric,
                                   readOnly:false
                       },
                       
                       {   
                          data:'dueDate',   
                        type: 'date',
                        dateFormat: 'MM/DD/YYYY',
                                          correctFormat: true,
                                          //  defaultDate: '06/29/2016',
                                      allowEmpty: false,
                                    // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                      datePickerConfig: {
                                      // First day of the week (0: Sunday, 1: Monday, etc)
                                      firstDay: 0,
                                      showWeekNumber: true,
                                      numberOfMonths: 1,
                                      
                                      },
                                  renderer:safeHtmlRenderer,
                                  readOnly:true
                       },
                       {   
                          data:'dateActivated',
                        type: 'date',
                        dateFormat: 'MM/DD/YYYY',
                                        correctFormat: true,
                                        // defaultDate: '06/29/2016',
                                    allowEmpty: false,
                                  // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                    datePickerConfig: {
                                    // First day of the week (0: Sunday, 1: Monday, etc)
                                    firstDay: 0,
                                    showWeekNumber: true,
                                    numberOfMonths: 1,
                                    
                                    },
                                    renderer:safeHtmlRenderereditable,
                                readOnly:false
                       },
                       {   
                          data:'activator',
                      renderer:safeHtmlRenderereditable,
                          readOnly:false
                       },
                       {   
                          data:'contractId',
                      renderer:safeHtmlRenderereditable,
                          readOnly:false
                       },
                       {   
                          data:'crg',
                      renderer:safeHtmlRenderereditable,
                          readOnly:false
                       },
                      {   
                          data:'ecsComments',
                      renderer:safeHtmlRenderereditable,
                          readOnly:false
                       }
                      ] ,
                                  
                            afterGetColHeader: function(col, TH) {
                          var TR = TH.parentNode;
                          var THEAD = TR.parentNode;
                          var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                          function applyClass(elem, className) {
                            if (!Handsontable.Dom.hasClass(elem, className)) {
                              Handsontable.Dom.addClass(elem, className);
                            }
                          }

                          // first level from the top
                          if (headerLevel === -2 && (col===0||col===1||col===2||col===3||col===4||col===5||col===6)) {
                              applyClass(TH, 'color2');

                            // second level from the top
                            }else if (headerLevel === -2 && (col>6 && col<29)) {
                                applyClass(TH, 'contractfieldinputcolor');

                              // second level from the top
                              } else if (headerLevel === -2 && (col>28 && col<37)) {
                                  applyClass(TH, 'contractrpcinputcolor');

                                // second level from the top
                                } else if (headerLevel === -1) {
                              applyClass(TH, 'color1');
                               
                            }
                         
                       }
                          
          
            }
        
        var network = new Handsontable(container, options);
        
        this.updateOptions = function(newOptions){
          console.log("inside update");
          network.updateSettings(newOptions);
        }
        
        this.render = function(){
          console.log("inside render");
          network.render();
        }
        
        this.getSourceData = function(){
          console.log("inside source");
           return network.getSourceData();
          
        }
        
        var numberValidator = /^\d+$/;
        /*var notEmpty = function (value, callback) {
          alert("dghjfdhg");
          var numberValidator = /^\d+$/;
          var patt = new RegExp("/^\d+$/");
            if (patt.test(value)) {
                alert("a number");
                
            } else {
               alert("not a number");
               callback(false);
            }
        };*/
        
        function getIsLockedContract(data1)
        {
        
        jQuery.ajax({
          type:"get",
          dataType:"json",
          url:urlPrefix+"/JanssenSCG/lockStatusContract",
          data:{data:data1},
          async:false,
          success: function(responseText) { 
              Response= responseText;
        },
        complete: function(){
          data = Response;
         }
         });
         
         return data;
        }
        
        
}
            
function viewfile(filename){
  //alert("view attachment"+filename);
  flag=true;
   var form = $('<form></form>').attr('action', "/JanssenSCG/viewAttachement").attr('method', 'post');
      // Add the one key/value
      form.append($("<input></input>").attr('type', 'hidden').attr('name', 'filename').attr('value', filename));
      //send request
      form.appendTo('body').submit().remove();
      
  /*jQuery.ajax({
    type:"post",
    dataType:"json",
    url:urlPrefix+"/JanssenSCG/viewAttachement",
    data:{data:filename},
    async:false,
    success: function(responseText) { 
      alert(success);
        //Response= responseText;
  },
  complete: function(){
    //data = Response;
   }
   });*/
}

function customDropdownRenderer(instance, td, row, col, prop, value, cellProperties) {
    var selectedId;
    var optionsList = cellProperties.chosenOptions.data;
    $(td).css({"background-color":'#e0e2e5'});
    var values = (value + "").split(",");
    var value = [];
    for (var index = 0; index < optionsList.length; index++) {
        if (values.indexOf(optionsList[index].id + "") > -1) {
            selectedId = optionsList[index].id;
            value.push(optionsList[index].label);
        }
    }
    value = value.join(", ");
    var workaround = "<div class='work'>"+value+"</div>";
       $(td).html(workaround);
    Handsontable.TextCell.renderer.apply(this, arguments);
}  
function safeHtmlRendererPercentage(instance, td, row, col, prop, value, cellProperties) {
   if($.isNumeric(value)){
      $(td).css({"background-color":'#FFFFFF'});
         var value1=value;   
         var percentage="%";
         
       var workaround = "<div>"+value1+percentage+"</div>";
        $(td).html(workaround);                
       }
       else{
         $(td).css({"background-color":'#FFFFFF'});
         $(td).html(value);
       }
       return td;  
}
function safeHtmlRenderereditableNumeric(instance, td, row, col, prop, value, cellProperties) {
     if($.isNumeric(value)){
    $(td).css({"background-color":'#e0e2e5'});
       var value1=value;   
      
     var workaround = "<div>"+value1+"</div>";
      $(td).html(workaround);                
     }
     else{
       //$(td).css({"background-color":'#FF0000'});
       $(td).css({"background-color":'#e0e2e5'});
       $(td).html(value);
     }
     return td;  
    } 
function customRenderer(instance, td, row, col, prop, value, cellProperties) {
  
     var value1;
  //alert(value);
     var rowdata=instance.getSourceDataAtRow(row);
   
        // var uniqueId='"'+rowdata.uniqueIdentifier+'"';
         var uniqueId='"'+rowdata.id+'"';
        //alert("Row::"+uniqueId);
            if(value == null ){
                 value1="";
                  var workaround = "<div>"+value1+"</div>";
                   $(td).html(workaround);
                  }else{
                   //alert("else");
                  var workaround = "<input type='button' style='margin-top:20px' value='View Attachment' id='file_viewer"+rowdata.uniqueIdentifier+"' onclick='viewfile("+uniqueId+");'/>";
                 // $(td).css({"margin-top":'20px'});
                   $(td).html(workaround);
                  
                  }
           
          return td;
    }