$(document).ready(function()
{ 
	var UniqIdArray1=new Array();
	

$(".form-style-1").hide();

$(document).ready(function(){
jQuery.ajax({
    type:"get",
    dataType:"json",
    url:urlPrefix+"/JanssenSCG/CustomerTypeForDistributionEdit",
    data:{userId:userID},
    async:true,
    success: function(responseText) { 	
        Response= responseText;
},
complete: function(){
              
     /* $('<option/>').val("").html("Select").appendTo('#CustomerType');*/
     
      for(var i=0;i<Response.length;i++)
		{
			$('<option/>').val(Response[i]).html(Response[i]).appendTo('#CustomerType');
		}  
   	              
					
	

}
});

document
.getElementById("RequestorEmail").defaultValue =username;


$('#CustomerType').change(function(){
    //filter=$(this).val();
   var customerType=$('#CustomerType option:selected').text();
  // alert(customerType);
     jQuery.ajax({
           type:"get",
           dataType:"json",
           url:urlPrefix+"/JanssenSCG/ChannelForDistributionEdit",
           data:{userId:userID,customerType:customerType},
           async:true,
           success: function(responseText) { 
               Response= responseText;
               console.log(Response);
		},
    complete: function(){
    	 $('#Channel1').empty();
        
             $('<option/>').val("").html("Select Channel").appendTo('#Channel1');
            // $('#fieldDirectorPicker option[value="All"]').prop('selected', true);
          	for(var i=0;i<Response.length;i++)
          		{
						$('<option/>').val(Response[i]).html(Response[i]).appendTo('#Channel1');
					}               
          	$('<option/>').val("Other").html("Other").appendTo('#Channel1');
          
    }
    });
     
     

});
$('#Channel1').change(function(){
	var requestorType=$('#Channel1 option:selected').text();
	
	jQuery.ajax({
	    type:"get",
	    dataType:"json",
	    url:urlPrefix+"/JanssenSCG/ContractingForDistributionEdit",
	    data:{userId:userID,requestorType:requestorType},
	    async:true,
	    success: function(responseText) { 
	        Response= responseText;
	},
	complete: function(){
		 $('#ContractingParty').empty();
		 $('<option/>').val("").html("Select Contracting Party Legal Entity").appendTo('#ContractingParty');
            $('#ContractingParty option[value="All"]').prop('selected', true);
          for(var i=0;i<Response.length;i++)
            {
  $('<option/>').val(Response[i]).html(Response[i]).appendTo('#ContractingParty');
  }               
          $('<option/>').val("Other").html("Other").appendTo('#ContractingParty'); 
$(".selectpicker").selectpicker('refresh');
  
  }     	
	
	});
	
	
jQuery.ajax({
    type:"get",
    dataType:"json",
    url:urlPrefix+"/JanssenSCG/RequestorForDistributionEdit",
    data:{userId:userID,requestorType:requestorType},
    async:true,
    success: function(responseText) { 
        Response= responseText;
},
complete: function(){
	 $('#RequestType1').empty();
   
        $('<option/>').val("").html("Select Request Type").appendTo('#RequestType1');
       // $('#fieldDirectorPicker option[value="All"]').prop('selected', true);
     	for(var i=0;i<Response.length;i++)
     		{
					$('<option/>').val(Response[i]).html(Response[i]).appendTo('#RequestType1');
				}               
     	$('<option/>').val("Other").html("Other").appendTo('#RequestType1');
     
}
});




});

jQuery.ajax({
    type:"get",
    dataType:"json",
    url:urlPrefix+"/JanssenSCG/getUserProductNamesDistributionFFSView",
    data:{userId:userID},
    async:true,
    success: function(responseText) { 
        Response= responseText;
},
complete: function(){
          $('#Product').empty();     
     /* $('<option/>').val("").html("Select Product").appendTo('#Product');*/
     
     /*  $('<option/>').val("All").html("All").appendTo('#Product');
       $('#Product option[value="All"]').prop('selected', true);*/
          $('<option/>').val("N/A").html("N/A").appendTo('#Product');
       $.each(Response, function(key, value) {
           
			  $('<option/>').val(value).html(value).appendTo('#Product');
	});	        
 
$(".selectpicker").selectpicker('refresh');
   	
}

});

/*$("#Product").change(function(){
	var product=$('#Product option:selected').text();
	jQuery.ajax({
	    type:"get",
	    dataType:"json",
	    url:urlPrefix+"/JanssenSCG/ProductNdcNumberForDistributionEdit",
	    data:{userId:userID,product:product},
	    async:true,
	    success: function(responseText) { 
	        Response= responseText;
	},
	complete: function(){
		 $('#prdNDCNumber').empty();
	   console.log(Response);
	        $('<option/>').val("").html("select Request Type ").appendTo('#prdNDCNumber');
	       // $('#fieldDirectorPicker option[value="All"]').prop('selected', true);
	     	for(var i=0;i<Response.length;i++)
	     		{
						$('<option/>').val(Response[i]).html(Response[i]).appendTo('#prdNDCNumber');
	     	     	$('#prdNDCNumber').val(Response[i]).html(Response[i]);
					}               
	     	$('<option/>').val("Others").html("Others").appendTo('#prdNDCNumber');
	     
	}
	});

	
});
*/





});

//bootstrap data send

$(document).ready(function(){
    
	$('#rset').click(function(){
    	
	    
    	
   	 
		 $("#Product, #Approvaldropdown").val('default');
		 $("#requestorApproval, #PRdropdown").prop('selectedIndex',0);
		 $("#Product, #Approvaldropdown").selectpicker("refresh");	
	 	
   	 $("#StakeholderName").css( "border", ""); 
        $("#StakeholderName").css( "box-shadow", "");
   	
	 
	 
		 $("#StakeholderEmail").css( "border", ""); 
   	 $("#StakeholderEmail").css( "box-shadow", "");
		
	
	     $("#CompletionDate").css( "border", ""); 
        $("#CompletionDate").css( "box-shadow", "");
	   
	
  	  	$("#legalentity").css( "border", ""); 
  	  	$("#legalentity").css( "box-shadow", "");
  	 
	 

      	 $("#CustomerType").css( "border", ""); 
   	 $("#CustomerType").css( "box-shadow", "");
      	
	 
	
      	 $("#Channel1").css( "border", ""); 
   	 $("#Channel1").css( "box-shadow", "");
      	
	 
	
  	     $("#RequestType1").css( "border", ""); 
  	     $("#RequestType1").css( "box-shadow", "");
  	 	 
	 
	 
      	 $("#ContractingParty").css( "border", ""); 
   	 $("#ContractingParty").css( "box-shadow", "");
      	
	 
	
        $("#DocumentType1").css( "border", ""); 
   	 $("#DocumentType1").css( "box-shadow", "");
      	
	 
	
	 
	
      	 $("#Description").css( "border", ""); 
   	 $("#Description").css( "box-shadow", "");
      	
	 

   	 $("#InternalSignatoryName").css( "border", ""); 
  	 	 $("#InternalSignatoryName").css( "box-shadow", "");
      
	
        $("#InternalSignatoryTitle").css( "border", ""); 
  	 	 $("#InternalSignatoryTitle").css( "box-shadow", "");
       
        $("#InternalSignatoryEmail").css( "border", ""); 
 	 	 $("#InternalSignatoryEmail").css( "box-shadow", "");
    
    	 $("#hasinformed1").css( "border", ""); 
	 	 $("#hasinformed1").css( "box-shadow", "");
      	
      	 $("#ExternalSignatoryName").css( "border", ""); 
	 	 $("#ExternalSignatoryName").css( "box-shadow", "");
      	 
      	 $("#ExternalSignatoryTitle").css( "border", ""); 
	 	 $("#ExternalSignatoryTitle").css( "box-shadow", "");
      	
      	 $("#ExternalSignatoryEmail").css( "border", ""); 
	 	 $("#ExternalSignatoryEmail").css( "box-shadow", "");
      	
      	
	



	  
	   $("#OtherChannel").css( "border", ""); 
	   $("#OtherChannel").css( "box-shadow", "");

		   $("#OtherRequestor").css( "border", ""); 
		   $("#OtherRequestor").css( "box-shadow", "");
		  

	  
	   $("#OtherContractingparty").css( "border", ""); 
	   $("#OtherContractingparty").css( "box-shadow", "");
	  
	   $("#OtherDocumentType").css( "border", ""); 
	   $("#OtherDocumentType").css( "box-shadow", "");
	  
	   $("#productvalidation").css( "border", ""); 
 	 $("#productvalidation").css( "box-shadow", "");
 	 
	
	
});	
	
    $('#save').click(function(){
    	
    	
    	
    	
    	
    	
    	  var urlPrefix = window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
    	
    	
    	
    	
    	
    	 var InternalSignatoryName;
    	 var RequestorName;
    	 var StakeholderName1;
    	 var ExternalSignatoryName;
   //  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  

    	 
    	
    		 var requestor1=$("#requestor1").val();
             //requestor1= empty(requestor1)?data[0].Requestor:requestor1;
            
            
            //alert(product1);
             var   RequestorName=$("#RequestorName").val();
             var RequestorTitle=$("#RequestorTitle").val();
             var RequestorMail=$("#RequestorEmail").val();
             
     
         //alert(CustomerType);
         
          
          
         
           var Sname=$("#StakeholderName").val();
           var Stitle=$("#StakeholderTitle").val();
           var Smail=$("#StakeholderEmail").val();
           
        /*   if(empty(Sname))
       	{
        	   StakeholderName1=Smail;
       	}
       else if (empty(Smail)){
       	 
    	   StakeholderName1=Sname;
       }
       else if(empty(Smail)&&empty(Sname))
       	{
    	   StakeholderName1="";
       	}
       else{
       	
    	   StakeholderName1=Sname+","+Smail;
       }*/
        	//  var id=$("#UniqueId").val();
         
           var requestorApproval1=$("#requestorApproval").val();
        
          // var Approvaldropdown1=$("#Approvaldropdown").val();
           
           var Approvaldropdown1 = "";
			
			 var lth1=$("#Approvaldropdown").val().length;
	          for(var i=0;i<lth1;i++)
	   	   {
	   	   
	        	  Approvaldropdown1= $("#Approvaldropdown").val()[i]+", "+ Approvaldropdown1 ;
	   	   }
	          
	          Approvaldropdown1=Approvaldropdown1+" ";

	          Approvaldropdown1=  Approvaldropdown1.replace(",  ","");
	          
			
			
			
			
			
              var PRdropdown1=$("#PRdropdown").val();
           var PRNO=$("#pr_no").val();
           var  CompletionDate=$("#CompletionDate").val();
           var  Entity=$("#legalentity").val();
           var CustomerType=$("#CustomerType").val();
           var Channel1=$("#Channel1").val();
           var  OtherChannel=$("#OtherChannel").val();
           var RequestType1=$("#RequestType1").val();
           var  OtherRequestor=$("#OtherRequestor").val();
           var ContractingParty1="";
         //  var ContractingParty1=$("#ContractingParty").val();
        
          
           
         
          
           
           
           var  OtherContractingparty=$("#OtherContractingparty").val();
           var DocumentType1=$("#DocumentType1").val();
           var  OtherDocumentType=$("#OtherDocumentType").val();
            var ActiveMSASOW1=$("#Active").val();
            var  EmpICD =$("#EmpICD ").val();
          var Product2="";
          //var Product2=$("#Product").val();
          var lth=$("#Product").val().length;
          for(var i=0;i<lth;i++)
   	   {
   	   
        	  Product2= $("#Product").val()[i]+", "+ Product2 ;
   	   }
          
        Product2=Product2+" ";

       Product2=  Product2.replace(",  ","");
          
         // var ProductNDC=$("#prdNDCNumber").val();
         /* var ProductNDC=$("#prdNDCNumber").val();*/
           var Description1 =$("#Description").val();
           var CouponStatus1=$("#CouponStatus").val();
           var attachementDetails=$("#attachementdetails").val();
           var filecontract = $("#filecontract").get(0).files[0];
           
            var IntSignatoryName=$("#InternalSignatoryName").val();
            var IntSignatoryMail=$("#InternalSignatoryEmail").val();
            var IntSignatoryTitle=$("#InternalSignatoryTitle").val();
            
        
         /*  if(empty(name))
            	{
            	InternalSignatoryName=mail;
            	}
            else if (empty(mail)){
            	 
            	 InternalSignatoryName=name;
            }
            else if(empty(mail)&&empty(name))
            	{
            	InternalSignatoryName="";
            	}
            else{
            	
            	InternalSignatoryName=name+","+mail;
            }*/
           var hasinformed1=$("#hasinformed1").val();
           
           var ExtSignatoryName=$("#ExternalSignatoryName").val();
           var ExtSignatoryEmail=$("#ExternalSignatoryEmail").val();
           var ExtSignatoryTitle=$("#ExternalSignatoryTitle").val();
           
       /*    if(empty(Ename))
       	{
        	   ExternalSignatoryName=mail;
       	}
       else if (empty(Email)){
       	 
    	   ExternalSignatoryName=name;
       }
       else if(empty(Email)&&empty(Ename))
       	{
    	   ExternalSignatoryName="";
       	}
       else{
    	   ExternalSignatoryName=Ename+","+Email;
    	   
       }*/
           
         //  var ExternalSignatoryName=$("#ExternalSignatoryName").val()+","+$("#ExternalSignatoryEmail").val();
           
           var EffectiveDate=$("#EffectiveDate").val();
           var  EndDate=$("#enddate").val();
           var TotalityNumber=$("#TotalityNumber").val();
           var OtherTotality=$("#OtherTotality").val();
           var HCCStatus=$("#HCCStatus").val();
           var otherApproval=$("#otherApproval").val();
            var k;
           var Comments=$("#comments").val(); 
           var notifyFD=$("#notifyFD").is(':checked');
           var stakeholder=$("#Stakeholder").val();
        
          var validateSuccess= validatefilesize(filecontract);;
            
          // alert(notifyFD);
           var formData = new FormData();
          formData.append('filecontract', filecontract);
          formData.append('notifyFD',notifyFD);
          
            
      if(validateSuccess)
    	  {
           //alert();
          var urlPrefix = window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
          var MaxId
      //    for(k=0;k<lth1;k++)
   	  // {
          
        	  
        	  var dataArray=new Array();
   	   ContractingParty1= $("#ContractingParty").val();
  // UniqueId= data1.responseJSON +Math.floor(Math.random()*1000);
  // UniqIdArray.push(UniqueId);
          
       	   var data={'Requestor':requestor1,  'RequestorName':RequestorName,'RequestorTitle':RequestorTitle,'RequestorMail':RequestorMail,'channel':Channel1,'RequestType':RequestType1
      			   , 'StakeholderName':Sname,'Stakeholder':Stitle, 'StakeholderMail':Smail,'Approval':requestorApproval1
      			   ,'Approvaldropdown':Approvaldropdown1.toString() ,'otherApproval':otherApproval, 'PurchaseNum':PRdropdown1,'otherPurchaseNum':PRNO
      			  , 'ContractingParty':ContractingParty1,'DocumentType':DocumentType1 ,'Active':ActiveMSASOW1 
      			 ,'product':Product2.toString(),'Description':Description1,'CouponStatus':CouponStatus1
      			,'ISignatoryName':IntSignatoryName,'ISignatoryMail':IntSignatoryMail,'ISignatoryTitle':IntSignatoryTitle,"HasInformed":hasinformed1
      			   ,"ExSignatoryName":ExtSignatoryName,'ExSignatoryTitle':ExtSignatoryTitle,'ExSignatoryMail':ExtSignatoryEmail,"TotalityNum":TotalityNumber,"otherTotalityNum":OtherTotality
      			   ,"TotalityStatus":HCCStatus ,"CompletionDate":CompletionDate,"Entity":Entity
      			   ,"otherChannel":OtherChannel,"otherRequestType":OtherRequestor,"otherContractingParty":OtherContractingparty
      			   ,"otherDocumentType":OtherDocumentType,"EmpICD":EmpICD,"EffectiveDate":EffectiveDate,"EndDate":EndDate,"Comments":Comments
       			   ,"Hasattachment":attachementDetails,"CustomType":CustomerType
       			   
       	   
       	   
       	   };	  
       	   dataArray.push(data);
        
           
            var jsonData = JSON.stringify(dataArray);
          //  alert(jsonData);
            
            if(validateSuccess){
          	  
         	   $("#CommGrid").css('visibility', 'hidden');
                //alert("hi1");
                 //$("#savediv").style.visibility = "hidden";
                 $("#savediv").hide();
                 // alert("hi2");
                // document.getElementById("confirmdiv").style.visibility = "hidden";
                 
                  //alert("hi4");
                 $("#loadingmsg").css('visibility', 'hidden');
                 
            formData.append('content', jsonData);
                  jQuery.ajax({
                type:"post",
                dataType:"json",
              
                url:urlPrefix+"/JanssenSCG/distributionadd",
                data:formData,
                async:true,
              processData: false,
              contentType: false,
                success: function(response) { 
               	// alert("ajax response contractadd"+response.saveSuccessMsg);
               	
               	 var identifier=response.identifier;
              
               	// alert(identifier);
                    var title;
                    var alertText;
                    var UniqArray="";
                    
                  if(!empty(identifier)){
                	  UniqIdArray1.push(identifier)
               	 title="Sucessfully Submitted";
               	 text="Successfully submitted. Do you want to submit another request?"
                    type="success";
                  }else{
                 	 title="Oops! Data Not saved";	  	                      	 
                 	 text=response.validationMessage+".Do you want to Raise again?";
                 	type="warning";
                  }
              //  $('#productPicker').val(product1);
                 // $('#businessPicker').val(customer1);
                  //$('#channelPicker').val(channel1);
                    swal({
				        title: title,
				        text: text,
				        type: type,
				        showCancelButton: true,
				        confirmButtonColor: "#DD6B55",
				        confirmButtonText: "YES",
				        cancelButtonText: "NO",
				        closeOnConfirm: true,
				        closeOnCancel: true,
	    				}, function(isConfirm) {
	    					for(i=0;i<UniqIdArray1.length;i++)
	    						
	    					UniqArray=UniqIdArray1[i]+","+UniqArray;
	    				
	    					//UniqIdArray =JSON.stringify(UniqIdArray);
	    			          handsonComm.updateOptions({		    					
	    				 			data:getDataByUniqIdArray(UniqArray)
	    				 	});
	    				 	handsonComm.render(); 
	    				 	//window.location.reload()
	    				if(isConfirm){
	    					
	    					//location.reload();
	    					//$(".myModalHorizontal").html("");
	    					
	    					 $('#myModalHorizontal').modal('show');
	    					 
	    				}
	    				if(!(isConfirm))
	    					{
	    					
	    					UniqIdArray1=[];
	    					}
	    				
  
	    				});
                 
 				
			},
         complete: function(){
       	 $("#CommGrid").css('visibility', 'visible');
            
             $("#savediv").show();
             $("#confirmdiv").show();
             
             $("#loadingmsg").css('visibility', 'hidden');  
         }
         });
            $('#myModalHorizontal').modal('hide');
            
                $("#CommGrid").css('visibility', 'hidden');
                
                 $("#savediv").hide();
                 $("#confirmdiv").hide();
                 
                 $("#loadingmsg").css('visibility', 'visible');                        
     }
    
          
    	
    }
          /*UniqIdArray =JSON.stringify(UniqIdArray);
          handsonComm.updateOptions({		    					
	 			data:getDataByUniqIdArray(UniqIdArray)
	 	});
	 	handsonComm.render(); */
    	 
    	 
});

	
	  
    
});  




//end

//dropdown menu 

$(document).ready(function(){
	 $('#requestorApproval').change(function(){
			if ($("#requestorApproval").val()=='Yes')
				{
				/*$('#Approvaldropdown').append('<option selected>Select Option</option>');*/
				$('#Approvaldropdown').append('<option value="Budget" class="approve">Budget</option>');
				$('#Approvaldropdown').append('<option class="approve" value="Bus. Partner Risk Assessment">Bus. Partner Risk Assessment</option>');
				$('#Approvaldropdown').append('<option class="approve" value="Contract and Pricing Committee">Contract and Pricing Committee</option>');

				$('#Approvaldropdown').append(' <option class="approve" value="Pharmacovigilance">Pharmacovigilance</option>');
				$('#Approvaldropdown').append('<option class="approve" value="Privacy">Privacy</option>');
				$('#Approvaldropdown').append('<option class="approve" value="Regulatory">Regulatory</option>');
				$('#Approvaldropdown').append('<option class="approve" value="Other">Other</option>');
				$(".selectpicker").selectpicker('refresh');
				}
			else
			{
				$('#Approvaldropdown').empty();
				$('#otherApproval').val(" ");
				$("#otherApproval")
				.prop(
						"readonly",
						true);
				 $(".selectpicker").selectpicker('refresh');
				}
		  });
	
	 $('#PRdropdown').change(function(){
			if ($("#PRdropdown").val()=='Yes')
				{
			  //  alert("Hello");
				$("#pr_no").prop("readonly",false);
				}
			else
				{
				$("#pr_no").prop("readonly",true);
				}
		  });
	 
	 
	 $('#RequestType1').change(function(){
			if ($("#RequestType1").val()=='Other')
				{
			  //  alert("Hello");
				$("#OtherRequestor").prop("readonly",false);
				}
			else
				{
				$("#OtherRequestor").prop("readonly",true);
				$("#OtherRequestor").val('');
				}
		  });
	 
	 
	 
	
	  $('#Channel1').change(function(){
		if ($("#Channel1").val()=='Other')
			{
		  //  alert("Hello");
			$("#OtherChannel").prop("readonly",false);
			}
		else
			{
			$("#OtherChannel").prop("readonly",true);
			$("#OtherChannel").val('');
			}
	  });
	  
	  $('#ContractingParty').change(function(){
			if ($("#ContractingParty").val()=='Other')
				{
			  //  alert("Hello");
				$("#OtherContractingparty").prop("readonly",false);
				}
			else
				{
				$("#OtherContractingparty").prop("readonly",true);
				$("#OtherContractingparty").val('');
				}
		  });
	  $('#DocumentType1').change(function(){
			if ($("#DocumentType1").val()=='Other')
				{
			  //  alert("Hello");
				$("#OtherDocumentType").prop("readonly",false);
				}
			else
				{
				$("#OtherDocumentType").prop("readonly",true);
				$("#OtherDocumentType").val('');
				}
		  });
	  $('#Active').change(function(){
			if ($("#Active").val()=='Yes')
				{
			  //  alert("Hello");
				$("#EmpICD").prop("readonly",false);
				}
			else
				{
				$("#EmpICD").prop("readonly",true);
				$("#EmpICD").val('');
				}
		  });
	  
	  $('#Approvaldropdown')
		.change(
				function() {
					if ($("#Approvaldropdown")
							.val().includes('Other')) {
						// alert("Hello");
						$("#otherApproval")
								.prop(
										"readonly",
										false);
					} else {
						$("#otherApproval")
								.prop(
										"readonly",
										true);
						$("#otherApproval").val('');
					}
				});
	  
	  $('#attachementdetails').change(function(){
			if ($("#attachementdetails").val()=='Yes')
				{
			  //  alert("Hello");
				$("#filecontract").prop("disabled",false);
				}
			else
				{
				$("#filecontract").val('');
				$("#filecontract").prop("disabled",true);
				}
		  });
	  
	  
	  
	  
	  
	  
	  $('#TotalityNumber').change(function(){
			if ($("#TotalityNumber").val()=='Yes')
				{
			  //  alert("Hello");
				$("#OtherTotality").prop("readonly",false);
				$("#HCCStatus").prop("disabled",false);
				}
			else
				{
				$("#OtherTotality").prop("readonly",true);
				$("#OtherTotality").val("");
				$("#HCCStatus").prop("disabled",true);
				$("#HCCStatus").prop('selectedIndex',0);
				}
		  });
	 
	  
	  
	  
	  
	});
       



//end



            
            
           /* $("#CustomerType").selectmenu();
            $("#Channel1").selectmenu({
                change: function (event, data) {
                    var firstVal = $("#CustomerType").val();
                    console.log('first', firstVal);
                    console.log('second', $(this).val())
                    return false;
                }
            });*/
            
            function emailIsValid(email) 
            {    
              var re = /^(?:[a-zA-Z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-zA-Z0-9-]*[a-zA-Z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
              return !re.test(email);
            }
            
            
            function empty(str)
      	  {
      	      if (typeof str == 'undefined' || !str || str.length === 0 || str === '' || !/[^\s]/.test(str) || /^\s*$/.test(str) )
      	      {
      	          return true;
      	      }
      	      else
      	      {
      	          return false;
      	      }
      	  }
            
            function checkfiletype(ext) {
            	var supportedfiletype=['xls', 'xlsx', 'doc','docx' , 'ppt', 'pptx', 'zip', 'pdf', 'jpg', 'jpeg'];
            	if(supportedfiletype.includes(ext)){
            		return true;
            	}
               return false;
            };    
            
            
  function validatefilesize(file)
            
        	{
        	//alert("file validation"+file.name);
        	var success=true;
        	//var requestorType=$("#requestor1").val();
        //	var  Stitle=$("#StakeholderName").val().split(",")[1];
        	  var startdate=$("#EffectiveDate").val();
            var enddate=$("#endDate").val();
            var name=$("#InternalSignatoryName").val();
            var mail=$("#InternalSignatoryEmail").val();
            var Ename=$("#ExternalSignatoryName").val();
            var Email=$("#ExternalSignatoryEmail").val();
            var title=$("#InternalSignatoryTitle").val();
            var Etitle=$("#ExternalSignatoryTitle").val();
           
             var hasinformed2=$("#hasinformed1").val();
            var se=$("#StakeholderEmail").val();
            var re=$("#RequestorEmail").val();
            var Description =$("#Description").val();
         var contractType=$("#CustomerType").val();
        var targetDate=$("#CompletionDate").val();
        var legalentity=$("#legalentity").val();
        var Channel2=$("#Channel1").val();
       var RequestType2=$("#RequestType1").val();
        var contractingEntity=$("#ContractingParty").val();
        var DocumentType1=$("#DocumentType1").val();
        var product1=$("#Product").val();  
         var  RequestorName1=$("#RequestorName").val();
      //  var Stitle=$("StakeholderName").val().split(",")[1];
         var RequestorMail1=$("#RequestorEmail").val();
         var stakeholder1=$("#StakeholderName").val();
      //   var ret=$("#RequestorTitle").val();
      //   var stakeholderTitle=$("#StakeholderTitle").val();
         var otherChannel=$("#OtherChannel").val();
         var otherRequestor=$("#OtherRequestor").val();
         var otherContracting=$("#OtherContractingparty").val();
         var otherDocument=$("#OtherDocumentType").val();
        /*if(empty(title)||empty(Etitle)||empty(hasinformed2)||empty(stakeholder1)||empty(product1) ||empty(RequestType2)||empty(targetDate)||empty(legalentity)||empty(Description)||empty(RequestorName1)||empty(contractType)||empty(Channel2)||empty(contractingEntity)||empty(DocumentType1)||empty(product1)||empty(name)||empty(Ename))
         */
         var k;var n=4;var c=0;
       /* if(empty(stakeholder1))
        	 {
        	 alert ("Please enter Stakeholder's Name.")
        	 success=false;
        	 }
        else if(empty(se))
	       	 {
	       	 alert ("Please enter Stakeholder's Email.")
	       	 success=false;
	       	 }
        else if(emailIsValid(se))
	       	 {
	       	 alert ("Stakeholder's Email entered is Invalid !!")
	       	 success=false;
	       	 }
        else if(empty(targetDate))
	       	 {
	       	 alert ("Please select Targeted Completion Date.")
	       	 success=false;
	       	 }
        else if(empty(legalentity))
	       	 {
	       	 alert ("Please select J&J Legal Entity.")
	       	 success=false;
	       	 }
        else if(empty(contractType))
	       	 {
	       	 alert ("Please select Contracting Party Type.")
	       	 success=false;
	       	 }
        else if(empty(Channel2))
	       	 {
	       	 alert ("Please select Channel.")
	       	 success=false;
	       	 }
        else if(empty(RequestType2))
	       	 {
	       	 alert ("Please select Request Type.")
	       	 success=false;
	       	 }
        else if(empty(contractingEntity))
	       	 {
	       	 alert ("Please select Contracting Party Legal Entity.")
	       	 success=false;
	       	 }
        else if(empty(DocumentType1))
	       	 {
	       	 alert ("Please select Document Type Requested.")
	       	 success=false;
	       	 }
        else if(empty(product1))
	       	 {
	       	 alert ("Please select Product(s) & NDC Number(s).")
	       	 success=false;
	       	 }
        else if(empty(Description))
	       	 {
	       	 alert ("Please enter Project Description.")
	       	 success=false;
	       	 }
        else if(empty(name))
	       	 {
	       	 alert ("Please enter Internal Signatory (Name).")
	       	 success=false;
	       	 }
        else if(empty(title))
	         {
	         alert ("Please enter Internal Signatory (Title).")
	         success=false;
	         }
        else if(empty(mail))
	         {
	         alert ("Please enter Internal Signatory (Email).")
	         success=false;
	         }
        else if(emailIsValid(mail))
	       	 {
	       	 alert ("Internal Signatory Email entered is Invalid !!")
	       	 success=false;
	       	 }
        else if(empty(hasinformed2))
	       	 {
	       	 alert ("Please select Has Internal Signatory Been Informed of Project?")
	       	 success=false;
	       	 }
        else if(empty(Ename))
	       	 {
	       	 alert ("Please enter External Signatory (Name).")
	       	 success=false;
	       	 }
        else if(empty(Etitle))
	       	 {
	       	 alert ("Please enter External Signatory (Title).")
	       	 success=false;
	       	 }
        else if(empty(Email))
	       	 {
	       	 alert ("Please enter External Signatory (Email)")
	       	 success=false;
	       	 }
        else if(emailIsValid(Email))
	       	 {
	       	 alert (" External Signatory Email entered is Invalid !!")
	       	 success=false;
	       	 }
        else if(empty(RequestorName1))
	       	 {
	       	 alert ("Please enter Requestor's Name.")
	       	 success=false;
	       	 }
        else if(empty(product1))
	       	 {
	       	 alert ("Please select Product(s) & NDC Number(s).")
	       	 success=false;
	       	 }
        else if(empty(re))
	       	 {
	       	 alert ("Please enter Requestor's Email.")
	       	 success=false;
	       	 }
        else if(emailIsValid(RequestorMail1))
	       	 {
	       	 alert ("Please enter Requestor's Email.")
	       	 success=false;
	       	 }*/
         var emptyFieldCount=0;
         var invalidFieldCount=0;
         if(empty(RequestorName1))
         	 {
         	 // alert ("Please select Requestor's Name.")
         	 $("#RequestorName").css( "border", "1px solid red"); 
         	 $("#RequestorName").css( "box-shadow", "none");
         	 emptyFieldCount++;
         	 success=false;
         	 }

          if(empty(re))
         	 {
         	 // alert ("Please enter Requestor's Email.")
         	 $("#RequestorEmail").css( "border", "1px solid red"); 
         	 $("#RequestorEmail").css( "box-shadow", "none");
         	 emptyFieldCount++;
         	 success=false;
         	 }
          
          if(empty(stakeholder1))
         	 {
         	 //alert ("Please enter Stakeholder's Name.")
         	 $("#StakeholderName").css( "border", "1px solid red"); 
         	 $("#StakeholderName").css( "box-shadow", "none");
         	 emptyFieldCount++;
         	 success=false;
         	 }
          
          
          if(empty(se))
         	 {
         	 //alert ("Please enter Stakeholder's Email.")
         	 $("#StakeholderEmail").css( "border", "1px solid red"); 
         	 $("#StakeholderEmail").css( "box-shadow", "none");
         	 emptyFieldCount++;
         	 success=false;
         	 }

         if(empty(targetDate))
           	 {
         	 //alert ("Please select Targeted Completion Date.")
           	 $("#CompletionDate").css( "border", "1px solid red"); 
         	 $("#CompletionDate").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(legalentity))
           	 {
         	 //alert ("Please select J&J Legal Entity.")
           	 $("#legalentity").css( "border", "1px solid red"); 
         	 $("#legalentity").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(contractType))
           	 {
         	 //alert ("Please select Contracting Party Type.")
           	 $("#CustomerType").css( "border", "1px solid red"); 
         	 $("#CustomerType").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(Channel2))
           	 {
         	 //alert ("Please select Channel.")
           	 $("#Channel1").css( "border", "1px solid red"); 
         	 $("#Channel1").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }
           
         if(empty(RequestType2))
           	 {
         	 //alert ("Please select Request Type.")
           	 $("#RequestType1").css( "border", "1px solid red"); 
         	 $("#RequestType1").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(contractingEntity))
           	 {
         	 //alert ("Please select Contracting Party Legal Entity.")
           	 $("#ContractingParty").css( "border", "1px solid red"); 
         	 $("#ContractingParty").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(DocumentType1))
           	 {
             // alert ("Please select Document Type Requested.")
           	 $("#DocumentType1").css( "border", "1px solid red"); 
         	 $("#DocumentType1").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(product1))
           	 {
             // alert ("Please select Product(s) & NDC Number(s).")
           	 $("#productvalidation").css( "border", "1px solid red"); 
         	 $("#productvalidation").css( "box-shadow", "none");
         	 $("#productvalidation").css( "border-radius", "5px");
         	 $("#productvalidation").css( "height", "38px");
         	 emptyFieldCount++;
           	 success=false;
           	 }
         else
        	 {
        	 $("#productvalidation").css( "border", ""); 
         	 $("#productvalidation").css( "box-shadow", "");
         	 $("#productvalidation").css( "border-radius", "");
         	 $("#productvalidation").css( "height", "38px");
        	 }
  
         if(empty(Description))
           	 {
             //alert ("Please enter Project Description.")
           	 $("#Description").css( "border", "1px solid red"); 
         	 $("#Description").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(name))
           	 {
         	 //alert ("Please enter Internal Signatory (Name).")
         	 $("#InternalSignatoryName").css( "border", "1px solid red"); 
         	 	 $("#InternalSignatoryName").css( "box-shadow", "none");
         	 emptyFieldCount++;
             success=false;
           	 }

         if(empty(title))
             {
             //alert ("Please enter Internal Signatory (Title).")
         	 $("#InternalSignatoryTitle").css( "border", "1px solid red"); 
         	 	 $("#InternalSignatoryTitle").css( "box-shadow", "none");
         	 emptyFieldCount++;
             success=false;
             }

         if(empty(mail))
            {
            // alert ("Please enter Internal Signatory Email.")
         	$("#InternalSignatoryEmail").css( "border", "1px solid red"); 
         	 	$("#InternalSignatoryEmail").css( "box-shadow", "none");
         	 	emptyFieldCount++;
            success=false;
            }

         if(empty(hasinformed2))
           	 {
           	 //alert ("Please select Has Internal Signatory Been Informed of Project?")
           	 $("#hasinformed1").css( "border", "1px solid red"); 
          	 $("#hasinformed1").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(Ename))
           	 {
           	 //alert ("Please enter External Signatory (Name).")
           	 $("#ExternalSignatoryName").css( "border", "1px solid red"); 
          	 $("#ExternalSignatoryName").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(Etitle))
           	 {
           	 // alert ("Please enter External Signatory (Title).")
           	 $("#ExternalSignatoryTitle").css( "border", "1px solid red"); 
          	 $("#ExternalSignatoryTitle").css( "box-shadow", "none");
         	 emptyFieldCount++;
           	 success=false;
           	 }

         if(empty(Email))
          	 {
          	 //alert ("Please enter External Signatory Email.")
          	 $("#ExternalSignatoryEmail").css( "border", "1px solid red"); 
          	 $("#ExternalSignatoryEmail").css( "box-shadow", "none");
         	 emptyFieldCount++;
          	 success=false;
          	 }

         if(emailIsValid(re))
           	 {
             //alert ("Requestor's Email entered is Invalid !!")
         	 $("#RequestorEmail").css( "border", "1px solid red"); 
         	 $("#RequestorEmail").css( "box-shadow", "none");
         	 invalidFieldCount++;
           	 success=false;
           	 }

         if(emailIsValid(se))
         	 {
         	// alert ("Stakeholder's Email entered is Invalid !!")
         	 $("#StakeholderEmail").css( "border", "1px solid red"); 
         	 $("#StakeholderEmail").css( "box-shadow", "none");
         	 invalidFieldCount++;
         	 success=false;
         	 }

         if(emailIsValid(Email))
           	 {
           	 //alert (" External Signatory Email entered is Invalid !!")
           	 $("#ExternalSignatoryEmail").css( "border", "1px solid red"); 
          	 $("#ExternalSignatoryEmail").css( "box-shadow", "none");
          	invalidFieldCount++;
           	 success=false;
           	 }

         if(emailIsValid(mail))
           	 {
           	 //alert ("Internal Signatory Email entered is Invalid !!")
         	 $("#InternalSignatoryEmail").css( "border", "1px solid red"); 
         	 $("#InternalSignatoryEmail").css( "box-shadow", "none");
         	 invalidFieldCount++;
           	 success=false;
           	 }


         //validation css border      
         	 if(RequestorName1)
            	 {
            	 $("#RequestorName").css( "border", ""); 
            	 $("#RequestorName").css( "box-shadow", "");
            	 
            	 }
         	 
         	 if(!(emailIsValid(re)))
            	 {
            	 $("#RequestorEmail").css( "border", ""); 
                 $("#RequestorEmail").css( "box-shadow", "");
            	 }
         	 
         	 if(stakeholder1)
            	 {
            	 $("#StakeholderName").css( "border", ""); 
                 $("#StakeholderName").css( "box-shadow", "");
            	 }
         	 
         	 if(!(emailIsValid(se)))
         		 {
         		 $("#StakeholderEmail").css( "border", ""); 
            	 $("#StakeholderEmail").css( "box-shadow", "");
         		 }
         	 
         	 if((targetDate))
               	 {
         	     $("#CompletionDate").css( "border", ""); 
                 $("#CompletionDate").css( "box-shadow", "");
         	     }
         	 
         	 if((legalentity))
           	 	{
           	  	$("#legalentity").css( "border", ""); 
           	  	$("#legalentity").css( "box-shadow", "");
           	 	}
         	 
         	 if((contractType))
               	 {
               	 $("#CustomerType").css( "border", ""); 
            	 $("#CustomerType").css( "box-shadow", "");
               	 }
         	 
         	 if((Channel2))
               	 {
               	 $("#Channel1").css( "border", ""); 
            	 $("#Channel1").css( "box-shadow", "");
               	 }
         	 
         	 if((RequestType2))
           	 	 {
           	     $("#RequestType1").css( "border", ""); 
           	     $("#RequestType1").css( "box-shadow", "");
           	 	 }
         	 
         	 if((contractingEntity))
               	 {
               	 $("#ContractingParty").css( "border", ""); 
            	 $("#ContractingParty").css( "box-shadow", "");
               	 }
         	 
         	 if((DocumentType1))
               	 {
                 $("#DocumentType1").css( "border", ""); 
            	 $("#DocumentType1").css( "box-shadow", "");
               	 }
         	 
         	 if((product1))
           	 	 {
         		// $(".productvalidation").css( "border", ""); 
         		// $(".productvalidation").css( "box-shadow", "");
           	 	 }
         	 
         	 if((Description))
               	 {
               	 $("#Description").css( "border", ""); 
            	 $("#Description").css( "box-shadow", "");
               	 }
         	 
         	 if((name))
               	 {
            	 $("#InternalSignatoryName").css( "border", ""); 
           	 	 $("#InternalSignatoryName").css( "box-shadow", "");
                 }
         	 
         	 if((title))
                 {
                 $("#InternalSignatoryTitle").css( "border", ""); 
           	 	 $("#InternalSignatoryTitle").css( "box-shadow", "");
                 }
         	 
         	 if(!(emailIsValid(mail)))
                 {
                 $("#InternalSignatoryEmail").css( "border", ""); 
          	 	 $("#InternalSignatoryEmail").css( "box-shadow", "");
                 }

         	 if((hasinformed2))
               	 {
             	 $("#hasinformed1").css( "border", ""); 
         	 	 $("#hasinformed1").css( "box-shadow", "");
               	 }
         	 
         	 if((Ename))
               	 {
               	 $("#ExternalSignatoryName").css( "border", ""); 
         	 	 $("#ExternalSignatoryName").css( "box-shadow", "");
               	 }
         	 
         	 if((Etitle))
               	 {
               	 $("#ExternalSignatoryTitle").css( "border", ""); 
         	 	 $("#ExternalSignatoryTitle").css( "box-shadow", "");
               	 }

         	 if(!(emailIsValid(Email)))
               	 {
               	 $("#ExternalSignatoryEmail").css( "border", ""); 
         	 	 $("#ExternalSignatoryEmail").css( "box-shadow", "");
               	
               	 }
         if (($("#Channel1").val()=='Other'))
   	   {
   		   if((empty(otherChannel)))
   			   {
   			   c++;
   			   /*alert("Please enter 'Other' fields value");
   	   			success=false;*/
   			 $("#OtherChannel").css( "border", "1px solid red"); 
			   $("#OtherChannel").css( "box-shadow", "none");
			
   			   }
   		else
		   {
		  
		   $("#OtherChannel").css( "border", ""); 
		   $("#OtherChannel").css( "box-shadow", "");
		   }
   	   }
         else if(($("#Channel1").val()!='Other') || empty($("#Channel1").val()))
    	 {
    	 $("#OtherChannel").css( "border", ""); 
		   $("#OtherChannel").css( "box-shadow", "");
    	 
    	 }
         if (($("#RequestType1").val()=='Other'))
   			   {

   		        if((empty(otherRequestor)))
   		        	{
   		   
   			      c++;
   		      /* alert("Please enter 'Other' fields value");
   	   			success=false;*/
   			   $("#OtherRequestor").css( "border", "1px solid red"); 
  			    $("#OtherRequestor").css( "box-shadow", "none");
  			 
 		        }
 		      else
 			   {
 			  
 			   $("#OtherRequestor").css( "border", ""); 
 			   $("#OtherRequestor").css( "box-shadow", "");
 			   }
   			   }
         
         else if(($("#RequestType1").val()!='Other') || empty($("#RequestType1").val()))
    	 {
    	 $("#OtherRequestor").css( "border", ""); 
		   $("#OtherRequestor").css( "box-shadow", "");
    	 
    	 }
         
         if (($("#ContractingParty").val()=='Other')){
   		   if((empty(otherContracting)))
   		   {
   			   //alert("Please enter 'Other' fields value");
   			   	c++;
   	   			//success=false;
   			 $("#OtherContractingparty").css( "border", "1px solid red"); 
			  $("#OtherContractingparty").css( "box-shadow", "none");
			 
 		   }
 		 else 
		   {
		  
		   $("#OtherContractingparty").css( "border", ""); 
		   $("#OtherContractingparty").css( "box-shadow", "");
		   }
   	  }
         else if(($("#ContractingParty").val()!='Other') || empty($("#ContractingParty").val()))
        	 {
        	 $("#OtherContractingparty").css( "border", ""); 
  		   $("#OtherContractingparty").css( "box-shadow", "");
        	 
        	 }
         if(($("#DocumentType1").val()=='Other'))
   		   {
   		   	if(empty(otherDocument))
   		   		{
   		   		/*alert("Please enter 'Other' fields value");
   	   			success=false;*/
   		          c++;
   		       $("#OtherDocumentType").css( "border", "1px solid red"); 
  			    $("#OtherDocumentType").css( "box-shadow", "none");
  			 
 		   		}
 		  else
		   {
		  
		   $("#OtherDocumentType").css( "border", ""); 
		   $("#OtherDocumentType").css( "box-shadow", "");
		   }      
   		   }
         else if(($("#DocumentType1").val()!='Other') || empty($("#DocumentType1").val()))
	       {
	 $("#OtherDocumentType").css( "border", ""); 
		   $("#OtherDocumentType").css( "box-shadow", "");
	 
	        } 
   	  //k=c; 
      
 		   
        else if(file!=null){
        var ext=(file.name).split('.')[1];
                	if(!checkfiletype(ext)) {
                	alert("File type not supported.")
                	// dlg.find("#mandatoryfieldMsgType").show(); 
                	 success=false;
                	}
                	if(file.size > 2*1024*1024)
                   	{
                   //  $(this).val('');
                     alert("File size exceeds 2MB.Please upload less size."); 
                     success=false;
                   	}
                	
            	}
         if(emptyFieldCount!=0)
     	{
 		 alert ("Please Enter Mandatory fields.")
 		 success=false;
     	}
 	 else if(invalidFieldCount!=0)  
 		 {
 		 alert ("Please Enter Valid email ID.")
 		 success=false;
 		 }
 	else if (c>0)
   	{
   	alert("Please enter 'Other' fields value");
   		success=false;
   	}
             	
             	return success;
             	} 
 

});



