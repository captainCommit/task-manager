function Handson(containerid,options){
	
	var container = document.getElementById(containerid);
	var network = new Handsontable(container, options);
	
	this.updateOptions = function(newOptions){
		console.log("inside update");
		network.updateSettings(newOptions);
	};
	
	this.render = function(){
		console.log("inside render");
		network.render();
	};
	
	this.getSourceData = function(){
		console.log("inside source");
		 return network.getSourceData();
		
	};
	
	this.getRowHeaders = function(){    			 
		 console.log("inside header");
		 return network.getRowHeader();
	};
	
	this.getColumnHeaders = function(){    			 
		 console.log("inside header");
		 return network.getSettings().nestedHeaders.toString();
	};
	
	this.getPlugin = function(pluginName) {
	    return network.getPlugin(pluginName);
	};
    		
}
        	  