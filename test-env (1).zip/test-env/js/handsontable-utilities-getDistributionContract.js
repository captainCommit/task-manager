var changedRowIndexArr=[];
var changedarr=[];
var network;
var epudesc=new Array();
var strategyname=new Array();
function Handson(containerid){
	
         var container = document.getElementById(containerid);
   //     var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
        
    		var options = {
    			data:[],
    			colWidths: [150,150,150,
    			            150,150
    		                  ,150,170,
    		                  220,150,150,
    		                  220,220,150,
    		                  150,150,150,150,
    		                  150,150,150,
    		                  150,150,150,
    		                  200,150,200,150,150,
    		                  150,150,150,200,200,
    		                  220,150,150,150,200,
    		                  150,150,200,150,150,150,
    		                  150,150,150],
    		      comments: true,
           	    search:true,
           	    columnSorting: true,
           	    sortIndicator: true,
           	    manualColumnResize: true,
           	    manualRowResize: true, 
           	 viewportColumnRenderingOffset:38,
           	    preventOverflow: 'horizontal',
           	 //   filters:true,
           	    colHeaders:true,
           	    contextMenu: {
                       items: {  "copy": {name: "Copy"},
                           "paste": {
                               name: 'Paste',
                               callback: function () {
                                   this.copyPaste.triggerPaste();
                               }
                           } }
                   },
           	    contextMenuCopyPaste: {
           	        swfPath: 'js/ZeroClipboard.swf'
           	      },
           	   afterChange: function(changes, source){
           		
                   if(source === 'edit' || source === 'paste'){
                	 if((changedRowIndexArr!=null && changedRowIndexArr.length==0) || $.inArray(changes[0][0], changedRowIndexArr) == -1){
                		changedRowIndexArr.push(changes[0][0]);
                	 }
                   }
               } , 
            
        	    
        	   /* afterOnCellMouseDown: function(event, coords){
        	        // 'coords.row < 0' because we only want to handle clicks on the header row
        	       // alert(coords.row);
        	    	var rowTemp= coords.row;
        	    	 var data=this.getDataAtRow(coords.row);
        	    	 var data1 = JSON.stringify(data);
        	    	 var b= getIsLockedContract(data1);
        	    	
        	    	 if(b == true)
						{
						 alert("This row is being edited by some other user....Please try after some time");
						 this.deselectCell();
						 if(rowTemp == 0){
							 this.selectCell(rowTemp+1,rowTemp+1);
						 }else{
							 this.selectCell(rowTemp-1,rowTemp-1);
						 }
						 
						 return false;
						}
					 
        	    },
        	    */
        	   /* contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        }
                    }*/
        	    
                        /*"row_above":{name: "Insert a row above"
                        	
                    	},
                    "row_below":{name: "Insert a row below"},
                   "remove_row":{name: "Remove",
                	   callback: function(key, selection) {
                		      var amount = selection.end.row - selection.start.row + 1;
                		      if(amount>1){
                		    	  alert("Please select only one row to delete");
                		    	  return false;
                		      }else{
                		    	  var strconfirm = confirm("Are you sure you want to delete?");
                		    	    if (strconfirm == false) {
                		    	        return false;
                		    	    }
                		     var data=this.getDataAtRow(selection.start.row);
                		      var data1 = JSON.stringify(data);
                		      //alert("data: "+data1);
                		      jQuery.ajax({
                                  type:"POST",
                                  dataType:"json",
                                  url:urlPrefix+"/JanssenSCG/deleteRow",                    
                                  data:{data: data1},
                                  async:false,
                                  success: function(responseText) { 
                                      Response= responseText;                                      
                                        },
                           complete: function(){
                                fil = Response[0];
                                        }
                             });
                		      //removeRow(data1);
                		      this.alter('remove_row', selection.start.row, amount);
                	   }
                		    }
                	   }
                    	}*/
               /* },
        	    contextMenuCopyPaste: {
        	        swfPath: 'js/ZeroClipboard.swf'
        	      },*/
        	    fixedColumnsLeft: 4,
        	    manualColumnFreeze:true,
        	   
        	  //  dropdownMenu: true,
        	  //  filters:true,
        	    nestedHeaders: [
        	                   //  [{label: ' ', colspan:7},{label: 'Field Input', colspan:16},{label: ' ', colspan:1}],
        	                  
        	                    ['Unique Identifier',
        	                     'Contract Status',
        	                     'OD Point-of-Contact',
        	                      'Requestor\'s Name',      
        	                      'Requestor\'s Email',
        	                      'Stakeholder\'s Name',
        	                      'Stakeholder\'s Email',
        	                      'Has Requestor Received All Necessary Approvals for This Request?',
        	                      'If \"Yes\" What Approvals Have Been Received?',  
        	                      'If \"Other\" Approval',
        	                      'eMarketplace Purchase Requisition (\"PR\") Number',
        		                  'If \"Yes\" What is the Purchase Requisition (\"PR\") Number?',
        	                     'Targeted Completion Date (If Applicable)',
        	                     'J&J Legal Entity',
        	                     'Contracting Party Type',
        	                     'Channel',
        	                     'If \"Other\" Channel',
        	                     'Request Type',
        	                     'If \"Other\" Request Type',
        	                     'Contracting Party Legal Entity',
        	                     'If \"Other\" Contracting Party Legal Entity',                     
        	                     'Document Type Requested',
        	                     'If \"Other\" Document Type',
        	                     'Product(s) & NDC Number(s)',
        	                     'Is There an Active MSA / SOW / WO / CO?',
        	                     'If \"Yes\" What is the Icertis / ICD Number?',
        	                     'Project Description',
        	                     'Coupon Checklist Status (If Applicable)',
        	                     'Attachments Included with Request?',
        	                     'If \"Yes\" Include Attachments Here',  
        	                     'Internal Signatory (Name)',
        	                     'Internal Signatory (Title)',
        	                     'Internal Signatory (Email)',
        	                     'Has Internal Signatory Been Informed of Project?',
        	                     'External Signatory (Name)',
        	                     'External Signatory (Title)',
        	                     'External Signatory (Email)',
        	                     'Date Requested',
        	                     'Effective Date',
        	                     'End Date',
        	                     'Totality Number',
        	                     'If \"Yes\" What is the Totality Number?',
        	                     'Has Contract Been Uploaded to Totality?',
        	                     'Totality HCC Status',
        	                     'Comments',
        	                     'Record Last Edited By',
        	                     'Delete'
        	                     ]],
        	                     cells: function(row, col, prop) {
        	                    	    var cellProperties = {};

        	                    	    if (prop === 'SMD') {
        	                    	      cellProperties.readOnly = false;
        	                    	    }

        	                    	    return cellProperties;
        	                    	  },
        	                    	  columns: [
        	                                    
        	                                    
        	                    	               {   
        	                    	                data:'Uniqueidentifier',
        	                    	            renderer:safeHtmlRenderer,
        	                    	                readOnly:true
        	                    	             },
        	                    	             {   
        	                    	                 data:'Status',
        	                    	             renderer:safeHtmlRenderer,
        	                    	                 readOnly:true
        	                    	              },
        	                    	              {   
         	                    	                 data:'ODpoc',
         	                    	             renderer:safeHtmlRenderer,
         	                    	                 readOnly:true
         	                    	              },
        	                    	          
        	                    	             {   
        	                    	                 data:'RequestorName',
        	                    	                renderer:safeHtmlRenderer,  
        	                    	                 readOnly:true
        	                    	               },
        	                    	               
        	                    	                {   
        	                    	                 data:'RequestorMail',
        	                    	                renderer:safeHtmlRenderer,  
        	                    	                 readOnly:true
        	                    	               },
        	                    	               {   
        	                    	                   data:'StakeholderName',
        	                    	                renderer:safeHtmlRenderer,    
        	                    	                   readOnly:true
        	                    	                 },
        	                    	            
        	                    	               {   
        	                    	                   data:'StakeholderMail',
        	                    	                renderer:safeHtmlRenderer,    
        	                    	                   readOnly:true
        	                    	                 },
        	                    	              
        	                    	             
        	                    	                             {
        	                    	                                  data:'Approval',
        	                    	                              renderer:safeHtmlRenderer,
        	                    	                                  readOnly:true
        	                    	                               },
        	                    	                               {
        	                    	                                   data:'Approvaldropdown',
        	                    	                               renderer:safeHtmlRenderer,
        	                    	                                   readOnly:true
        	                    	                                },
        	                    	                               
        	                    	                                {
         	                    	                                   data:'otherApproval',
         	                    	                               renderer:safeHtmlRenderer,
         	                    	                                   readOnly:true
         	                    	                                },
         	                    	                               
        	                    	                                
        	                    	                               {
        	                    	                               data:'PurchaseNum',
        	                    	                                renderer:safeHtmlRenderer,
        	                    	                                 readOnly:true
        	                    	                              },
        	                    	                              
        	                    	                              {
        	                    	                                  data:'otherPurchaseNum',
        	                    	                                   renderer:safeHtmlRenderer,
        	                    	                                    readOnly:true
        	                    	                                 },
        	                    	                               {
        	                    	                                  data:'CompletionDate',
        	                    	                                editor: 'select',
        	                    	                              renderer:safeHtmlRenderer,
        	                    	                                
        	                    	                                readOnly:true
        	                    	                               },
        	                    	                               
        	                    	                             {
        	                    	                               data:'Entity',
        	                    	                                                             
        	                    	                               renderer:safeHtmlRenderer,
        	                    	                               readOnly:true
        	                    	                               },
        	                    	                              
        	                    	                              {
        	                    	                                data:'CustomType',
        	                    	                               
        	                    	                                renderer:safeHtmlRenderer,
        	                    	                                  readOnly:true
        	                    	                               
        	                    	                                },
        	                    	                                {
        	                    	                                 data:'channel' ,
        	                    	                                
        	                    	                                 renderer:safeHtmlRenderer,
        	                    	                                     readOnly:true
        	                    	                                
        	                    	                                },
        	                    	                                
        	                    	                                {
        	                    	                                    data:'otherChannel' ,
        	                    	                                   
        	                    	                                    renderer:safeHtmlRenderer,
        	                    	                                        readOnly:true
        	                    	                                   
        	                    	                                   },
        	                    	                                {
        	                    	                                 data:'RequestType',
        	                    	                                 
        	                    	                                 renderer:safeHtmlRenderer,
        	                    	                                 readOnly:true
        	                    	                                
        	                    	                                },
        	                    	                                {
        	                    	                                    data:'otherRequestType',
        	                    	                                    
        	                    	                                    renderer:safeHtmlRenderer,
        	                    	                                    readOnly:true
        	                    	                                   
        	                    	                                   },
        	                    	                                
        	                    	                                {
        	                    	                                   data:'ContractingParty',
        	                    	                                  
        	                    	                                   renderer:safeHtmlRenderer,
        	                    	                                     
        	                    	                                 readOnly:true
        	                    	                                
        	                    	                                },
        	                    	                                {
        	                    	                                    data:'otherContractingParty',
        	                    	                                   
        	                    	                                    renderer:safeHtmlRenderer,
        	                    	                                      
        	                    	                                  readOnly:true
        	                    	                                 
        	                    	                                 },
        	                    	                                {
        	                    	                                    data:'DocumentType',
        	                    	                                    renderer:safeHtmlRenderer,                                          
        	                    	                                    readOnly:true
        	                    	                                   },
        	                    	                                   
        	                    	                                   {
        	                    	                                       data:'otherDocumentType',
        	                    	                                       renderer:safeHtmlRenderer,                                          
        	                    	                                       readOnly:true
        	                    	                                      },
        	                    	                                      {
              	                    	                                    data:'product', 
              	                    	                                    renderer:safeHtmlRenderer,                                          
              	                    	                                    readOnly:true
              	                    	                                  },
              	                    	                                
        	                    	                                 {
        	                    	                                   data:'Active',
        	                    	                                   renderer:safeHtmlRenderer,                                          
        	                    	                                     readOnly:true
        	                    	                                 },
        	                    	                                 {
        	                    	                                     data:'EmpICD',
        	                    	                                     renderer:safeHtmlRenderer,                                          
        	                    	                                       readOnly:true
        	                    	                                   },
        	                    	                                 
        	                    	                                    
        	                    	                                {
        	                    	                                  data:'Description',
        	                    	                                  renderer:safeHtmlRenderer,
        	                    	                                 
        	                    	                              readOnly:true
        	                    	                                },
        	                    	                              {
        	                    	                                data:'CouponStatus',
        	                    	                                renderer:safeHtmlRenderer,
        	                    	                                 readOnly:true
        	                    	                                },
        	                    	                                {
        	                    	                                    data:'Hasattachment',
        	                    	                                   renderer:safeHtmlRenderer,
        	                    	                                    readOnly:true
        	                    	                                  },
        	                    	                                {
        	                    	                                  data:'fileExtension',
        	                    	                                 renderer:customRenderer,
        	                    	                                  readOnly:true
        	                    	                                },
        	                    	                                
        	                    	                             
        	                    	                              {
        	                    	                                  data:'ISignatoryName',
        	                    	                                  renderer:safeHtmlRenderer,
        	                    	                                  readOnly:true
        	                    	                              },
        	                    	                              {
        	                    	                                  data:'ISignatoryTitle',
        	                    	                                  renderer:safeHtmlRenderer,
        	                    	                                  readOnly:true
        	                    	                              },
        	                    	                              {
        	                    	                                  data:'ISignatoryMail',
        	                    	                                  renderer:safeHtmlRenderer,
        	                    	                                  readOnly:true
        	                    	                              },
        	                    	                              
        	                    	                        
        	                    	             {   
        	                    	                data:'HasInformed',
        	                    	            renderer:safeHtmlRenderer,
        	                    	                readOnly:true
        	                    	             },
        	                    	             {   
        	                    	                data:'ExSignatoryName',
        	                    	            renderer:safeHtmlRenderer,
        	                    	                readOnly:true
        	                    	             },
        	                    	             {   
         	                    	                data:'ExSignatoryTitle',
         	                    	            renderer:safeHtmlRenderer,
         	                    	                readOnly:true
         	                    	             },
         	                    	            {   
         	                    	                data:'ExSignatoryMail',
         	                    	            renderer:safeHtmlRenderer,
         	                    	                readOnly:true
         	                    	             },
        	                    	             
        	                    	           
        	                    	             {   
        	                    	                data:'DateRequested',
        	                    	            renderer:safeHtmlRenderer,
        	                    	                readOnly:true
        	                    	             },
        	                    	             {   
        	                    	                data:'EffectiveDate',
        	                    	            renderer:safeHtmlRenderer,
        	                    	                readOnly:true
        	                    	             },
        	                    	             {   
        	                    	                data:'EndDate',
        	                    	            renderer:safeHtmlRenderer,
        	                    	                readOnly:true
        	                    	             },
        	                    	             {   
        	                    	                 data:'TotalityNum',
        	                    	             renderer:safeHtmlRenderer,
        	                    	                 readOnly:true
        	                    	              },
        	                    	              {   
        	                    	                  data:'otherTotalityNum',
        	                    	              renderer:safeHtmlRenderer,
        	                    	                  readOnly:true
        	                    	               },
        	                    	               {   
        	                    	                   data:'contractUploadTotality',
        	                    	                   renderer:safeHtmlRenderer,
        	                    	                   readOnly:true
        	                    	                } ,
        	                    	              {   
        	                    	                 data:'TotalityStatus',
        	                    	             renderer:safeHtmlRenderer,
        	                    	                 readOnly:true
        	                    	              },
        	                    	             {   
        	                    	                 data:'Comments',
        	                    	                 renderer:safeHtmlRenderer,
        	                    	                     readOnly:true
        	                    	                  } , 
        	                    	              {   
        	                    	                      data:'LastEditedBy',
        	                    	                      renderer:safeHtmlRenderer,
        	                    	                          readOnly:true
        	                    	                       },
        	                    	                       {   
        	                           	                      data:'Delete',
        	                           	                      renderer:customDeleteRenderer,
        	                           	                          readOnly:true
        	                           	                       },
        	                    	                  ] ,
        	                    	                              autoColumnSize:true,
        	                    	                                        afterGetColHeader: function(col, TH) {
        	                    	                          var TR = TH.parentNode;
        	                    	                          var THEAD = TR.parentNode;
        	                    	                          var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

        	                    	                          function applyClass(elem, className) {
        	                    	                            if (!Handsontable.Dom.hasClass(elem, className)) {
        	                    	                              Handsontable.Dom.addClass(elem, className);
        	                    	                            }
        	                    	                          }
        	                    	               if (headerLevel === -1 && (col===0||col===1||col===2||col===3||col===4||col===5)) {
        	                    	                              applyClass(TH, 'ht_clone_top_left_corner');

        	                    	                            // second level from the top
        	                    	                            }
        	                    	                         // first level from the top
        	                    	                          if (headerLevel === -2 && (col===0||col===1||col===2||col===3||col===4||col===5)) {
        	                    	                              applyClass(TH, 'distributioncolor');

        	                    	                            // second level from the top
        	                    	                            }else if (headerLevel === -2 && (col>5 && col<21)) {
        	                    	                                applyClass(TH, 'distributioncolor');

        	                    	                              // second level from the top
        	                    	                              } else if (headerLevel === -2 && (col>20 && col<27)) {
        	                    	                                  applyClass(TH, 'distributioncolor');

        	                    	                                // second level from the top
        	                    	                                } else if (headerLevel === -2 && (col>26 && col<35)) {
        	                    	                                  applyClass(TH, 'distributioncolor');

        	                    	                                // second level from the top
        	                    	                                }  else if (headerLevel === -2 && (col===34 && col===35)) {
        	                    	                                  applyClass(TH, 'distributioncolor');

        	                    	                                // second level from the top
        	                    	                                } else if (headerLevel === -1) {
        	                    	                              applyClass(TH, 'distributioncolor');
        	                    	                               
        	                    	                            }
        	                    	                         
        	                    	                       }
        	                    	                       
        	                    	                       

        	                    	            // });

                  	      
        	
        	  }
    		
    		 network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
    		
    	var numberValidator = function (value, callback) {
    		setTimeout(function(){
    		    if (!$.isNumeric(value)) {
    		      callback(false);
    		    }
    		    else {
    		      callback(true);
    		    }
    		  }, 1000);
    		};
    		
    		function getIsLockedContract(data1)
    		{
    		
    		jQuery.ajax({
    	 		type:"get",
    	 		dataType:"json",
    	 		url:urlPrefix+"/JanssenSCG/lockStatusContract",
    	 		data:{data:data1},
    	 		async:false,
    	 		success: function(responseText) { 
    			    Response= responseText;
    		},
    		complete: function(){
    			data = Response;
    		 }
    		 });
    		 
    		 return data;
    		}
    		
    		
}
        	  
function viewfile(filename){
	//alert("view attachment"+filename);
	flag=true;
	 var form = $('<form></form>').attr('action', "/JanssenSCG/viewAttachfile").attr('method', 'post');
	    // Add the one key/value
	    form.append($("<input></input>").attr('type', 'hidden').attr('name', 'filename').attr('value', filename));
	    //send request
	    form.appendTo('body').submit().remove();
	    
	/*jQuery.ajax({
 		type:"post",
 		dataType:"json",
 		url:urlPrefix+"/JanssenSCG/viewAttachement",
 		data:{data:filename},
 		async:false,
 		success: function(responseText) { 
 			alert(success);
		    //Response= responseText;
	},
	complete: function(){
		//data = Response;
	 }
	 });*/
}

function customDropdownRenderer(instance, td, row, col, prop, value, cellProperties) {
    var selectedId;
    var optionsList = cellProperties.chosenOptions.data;
    $(td).css({"background-color":'#e0e2e5'});
    var values = (value + "").split(",");
    var value = [];
    for (var index = 0; index < optionsList.length; index++) {
        if (values.indexOf(optionsList[index].id + "") > -1) {
            selectedId = optionsList[index].id;
            value.push(optionsList[index].label);
        }
    }
    value = value.join(", ");
    var workaround = "<div class='work'>"+value+"</div>";
       $(td).html(workaround);
    Handsontable.TextCell.renderer.apply(this, arguments);
} 

function safeHtmlRenderereditableNumeric(instance, td, row, col, prop, value, cellProperties) {
	   if($.isNumeric(value)){
		$(td).css({"background-color":'#e0e2e5'});
		   var value1=value;   
      	   var percentage="%";
      	   value=value+percentage;
    	   var workaround = "<div>"+value1+percentage+"</div>";
     	  $(td).html(workaround);     		       
	   }
	   else{
		   //$(td).css({"background-color":'#FF0000'});
		   $(td).css({"background-color":'#e0e2e5'});
		   $(td).html(value);
	   }
	   Handsontable.TextCell.renderer.apply(this, arguments);
	   return td;  
	  } 
function safeHtmlRenderereditable(instance, td, row, col, prop, value, cellProperties) {
	   $(td).css({"background-color":'#e0e2e5'});
	   
       if(!value ){
       value="";
       }
        var workaround = "<div class='work'>"+value+"</div>";
         $(td).html(workaround);
        /*  $(td).css({"overflow-y":'auto'});
         $(td).css({"overflow-x":'auto'}); */
         Handsontable.TextCell.renderer.apply(this, arguments);
         return td;
	  }

function customRenderer(instance, td, row, col, prop, value, cellProperties) {
	
	   var value1;
	//alert(value);
	   var rowdata=instance.getSourceDataAtRow(row);
	 
	    	 var uniqueId='"'+rowdata.Uniqueidentifier+'"';
	    //	alert("Row::"+uniqueId);
		    	  if(value == null ){
	               value1="";
	                var workaround = "<div>"+value1+"</div>";
	                 $(td).html(workaround);
	                }else{
	                 //alert("else");
	                var workaround = "<input type='button' style='margin-top:20px' value='View Attachment' id='file_viewer"+rowdata.uniqueIdentifier+"' onclick='viewfile("+uniqueId+");'/>";
	               // $(td).css({"margin-top":'20px'});
	                 $(td).html(workaround);
	                
	                }
     
    return td;
	  }  
/*function customDeleteRenderer(instance, td, row, col, prop, value, cellProperties) {	
	   var value1;
	   var workaround;
	   var rowdata=instance.getSourceDataAtRow(row); 
	    	 var uniqueId=rowdata.id;
	    	 if(rowdata.approve || !empty(rowdata.trimNo)){
	            workaround = "<div><button type='button' class='btn btn-primary' style='margin-top:5px'  id='approve"+rowdata.id+"' disabled onclick='updateRow("+uniqueId+");'>Approve</button><br><button type='button' class='btn btn-warning' disabled style='margin-top:4px;margin-bottom:2px' id='reject"+rowdata.id+"' onclick='updateRow("+uniqueId+");'>Reject</button> </div> "
	    	 }else{
	    		 workaround = "<div><button type='button' class='btn btn-primary' style='margin-top:5px' id='approve"+rowdata.id+"' onclick='updateRow("+uniqueId+",true);'>Approve</button><br><button type='button' class='btn btn-warning' style='margin-top:4px;margin-bottom:2px' id='reject"+rowdata.id+"' onclick='updateRow("+uniqueId+",false);'>Reject</button> </div> "
	    	 }
	               // $(td).css({"margin-top":'20px'});
	                 $(td).html(workaround);
	                 //$(td).html(workaround1);
	           
    return td;
	  }*/

function customDeleteRenderer(instance, td, row, col, prop, value, cellProperties) {	
	   var value1;
	//alert(value);
	   var rowdata=instance.getSourceDataAtRow(row); 
	    	 var uniqueId=rowdata.Uniqueidentifier;
	    	
	    	 var workaround;
	    	 
         	   workaround = "<div><button type='button' class='btn btn-lg btn-primary' style='margin-top:8px;margin-left:35px;background-color: #337AB7;border-color: #337AB7;' id='delete_"+rowdata.Uniqueidentifier+"'  onclick='deleteRow("+uniqueId+");'>Delete</button></div>";
          
	               // $(td).css({"margin-top":'20px'});
	                 $(td).html(workaround);
	  
 return td;
	  }

function deleteRow(uniqueId){
	var Response;
	text1="Sucessfully saved changes and Approved.";

	 swal({
	        title: "Are You Sure You Want to Delete?",
	        text: "Choose the appropriate option below.",
	     	type: "warning",
	        showCancelButton: true,
	        confirmButtonColor: "#DD6B55",
	        confirmButtonText: "Yes",
	        cancelButtonText: "No",
	        closeOnConfirm: true,
	        closeOnCancel: true
			},
		    function(isConfirm) {
		        if (isConfirm) {
		        	jQuery.ajax({
                     type:"POST",
                     dataType:"json",
                     url:urlPrefix+"/JanssenSCG/deletedistributionRow",                    
                     data:{data: uniqueId},
                     async:false,
                     success: function(responseText) { 
                     	Response=responseText;
                     	
                                                               
                       },
                    complete: function(){
                 	   if(Response.saveSuccessMsg){
                 		//alert("deleted");
                 		 handsonComm.updateOptions({		    					
                	 			data:getDataByIdentifier(uniqueId)
                 		   });
                 		   handsonComm.render();
                 		  

                 	   }else{
                 		   alert("Some erorr has occured!!Please contact IT!");
                 	   }
                     }
                });
		        	
		        }
		        
		      }
		       	
        	
    	);
}

function updateRow(uniqueId,flag){
	
	var Response;
	var data=handsonComm.getSourceData();
	var row = $.grep(data, function(obj){return obj.id === uniqueId;})[0];
	//alert(row.comments);
	row.approve=flag;
	row.fileContent =null;
	row.fileExtension = null;
	var finalData=new Array();
	finalData.push(row);
	//var obj={};
	//obj.id =uniqueId;
	//obj.approve =flag;
	//var finalDataModified=[];
	//finalDataModified.push(obj);
	
	
	
	var arr=JSON.stringify(finalData);
	console.log("Array is : ");
	console.log(arr);
	var arr1=JSON.stringify(finalData);
	console.log("Array1 is : ");
	console.log(arr1);
	var text;
	var title;
	var type;
	var text1;
	if(row.approve){
		text="Are you sure you want to Approve?";
		title="Sucessfully saved and Approved.";
		text1="Sucessfully saved changes and Approved.";
		
	}else{
		text="Are you sure you want to Reject?";
		title="Rejected";
		text1="Sucessfully saved changes and Rejected.";
	}
	 swal({
	        title: "Are you sure?",
	        text:text,
	        type: "warning",
	        showCancelButton: true,
	        confirmButtonColor: "#DD6B55",
	        confirmButtonText: "Yes",
	        cancelButtonText: "No",
	        closeOnConfirm: false,
	        closeOnCancel: true
			},
		    function(isConfirm) {
		        if (isConfirm) {
		        	$("#CommGrid").css('visibility', 'hidden');
                    
                    $("#loadingmsg").css('visibility', 'visible');  
                   
		        	jQuery.ajax({
                        type:"POST",
                        dataType:"json",
                        url:urlPrefix+"/JanssenSCG/updateContract",                    
                        data:{jsonFull1: arr},
                        async:false,
                        success: function(response) { 
                        	//alert("ajax response contractadd"+response);
 	                         Response= response.saveSuccess;
 	                        
 	                         var alertText;
 	                         var type;
 	                       if(Response=='saveSuccess'){ 
 	                       	title=title;
 	                       	type="success";
 	                       alertText=text1;
 	                       }else{
 	                      	 title="Oops! Data Not saved";
 	                      	alertText="Oops!Data not saved";
 	                      	type="error";
 	                      	alertText=alertText+response.validationMessage;
 	                       } 
 	                       //alert("hi");
 	                         swal({
						        title: title,
						        text: alertText,
						        type: type,
						        showCancelButton: false,
						        confirmButtonColor: "#DD6B55",
						        confirmButtonText: "OK",
						        cancelButtonText: "No",
						        closeOnConfirm: true,
						        closeOnCancel: true
			    				}, function(isConfirm) {
			    				
			    				if(isConfirm){
			    					$("#CommGrid").css('visibility', 'visible');
			                        
			                        $("#loadingmsg").css('visibility', 'hidden');
			    				 handsonComm.updateOptions({
	                        	 			data:getData()
	                        	 	});
	                        	 	var data=handsonComm.getSourceData();
				
					    			//alert(network.countRows());
					    			for (var i = 0; i < network.countRows(); i++) {
					    			//for (var i = 0; i < rowcount; i++) {
					    				var row=data[i];
					    				var approved=row.approve;
					    				//alert("Approved"+approved);
					    				if(approved){
						    		        for (var j = 0; j < network.countCols(); j++) {
						    		        
						    		            network.setCellMeta(i, j, "className", "readonlystyle");
						    		        	network.setCellMeta(i, j, "readOnly", true);
						    		        	
						    		        }
					    			   }
					    			}
		 
	                        	 	handsonComm.render();
			    				}
			    				});
	                        	 	
 					},
 	              complete: function(){
 	            	    $("#savediv").show();
                       $("#confirmdiv").show();
                       $("#loadingmsg").css('visibility', 'hidden'); 	                       
                       $("#CommGrid").css('visibility', 'visible');
                       
 	              }
 	              });
		        	
		        }else{
		        	handsonComm.updateOptions({
             			 data:getData()
             			});
             			var data=handsonComm.getSourceData();
   				
						    			//alert(network.countRows());
						    			for (var i = 0; i < network.countRows(); i++) {
						    			//for (var i = 0; i < rowcount; i++) {
						    				var row=data[i];
						    				var approved=row.approve;
						    				//alert("Approved"+approved);
						    				if(approved){
							    		        for (var j = 0; j < network.countCols(); j++) {
							    		        
							    		            network.setCellMeta(i, j, "className", "readonlystyle");
							    		        	network.setCellMeta(i, j, "readOnly", true);
							    		        	
							    		        }
						    			   }
						    			}
              		 handsonComm.render();
		        }
		        
		      }
		       	
           	
       	);
}