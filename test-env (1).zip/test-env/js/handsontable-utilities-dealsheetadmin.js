
function Handson(containerid){
	
         var container = document.getElementById(containerid);
   //     var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
    		var options = {
    				 data: getData(),
    	        	    colWidths: [100,100,100,150,100,150,90,90,120,120,90,90,100,100,100,100,150,100,100,100],
    	        	    comments: true,
    	        	    search:true,
    	        	    columnSorting: true,
    	        	    sortIndicator: true,
    	        	    manualColumnResize: true,
    	        	    manualRowResize: true, 
    	        	    colHeaders:true,
    	        	    contextMenuCopyPaste: {
    	        	        swfPath: 'js/ZeroClipboard.swf'
    	        	      },
    	        	    fillHandle: {
    	              	   autoInsertRow: false,
    	          		},
    	        	      
    	        	     /* cells: function (row, col, prop) {
    	        	          var cellProperties = {};

    	        	          if (this.instance.getData()[row][col] == 'readonly' || this.instance.getData()[row][col] == 9999.9999 || this.instance.getData()[row][col] =='Jan 1, 9900') {
    	        	            cellProperties.readOnly = true; // make cell read-only if it is first row or the text reads 'readOnly'
    	        	            this.renderer = readOnlyRenderer;

    	        	          }
    	        	         

    	        	          return cellProperties;
    	        	        },*/
    	        	      
    	        	    manualColumnFreeze:true,
    	        	   	nestedHeaders: [
    	        	                   
    	        	                   ['CHANNEL','PRODUCT','ACCOUNT','PHARMACY LIVES','MEDICAL LIVES','CURRENT FORMULARY STATUS','BASE REBATE','INCREMENTAL ANNUAL REBATE','4 QTR CONTRACTED GROSS SALES($M)','4 QTR CONTRACTED REBATES($M)','AVERAGE REBATE(%)','4 QTR GOPS($M)','4 QTR CONTRACTED GROSS SALES/GOPS(%)','CURRENTLY IN ACTIVE BID CYCLE','BID REBATE','BID APPROACH','PROJECTED FORMULARY STATUS','BID DUE DATE','LAST MODIFIED BY','LAST MODIFIED ON']],
    	        	   // colHeaders: [],
    	        	     columns: [
    	                               	   
    	                               	  
    	                                  	    {
    	                                  	      data:'channelName',
    	                                  	      renderer:safeHtmlRenderer,
    	                                  	      readOnly:true
    	                                  	   },
    	                                  	    {
    	                                  	      data:'productName',
    	                                  	      renderer:safeHtmlRenderer,
    	                                  	      readOnly:true
    	                                  	   },
    	                                  	    
    	                               	      {
    	                                  	      data:'accountName',
    	                                  	      renderer:safeHtmlRenderer,
    	                                  	      readOnly:true
    	                                  	   },
    	                             	      
    	                             	      {
    	                             	    	  data:'pharmacyLives',
    	                             	    	  renderer:safeHtmlRenderer,
    	                             	    	  readOnly:true
    	                             	    	 
    	                               	      },
    	                               	      {
    	                               	    	 data:'medicalLives' ,
    	                               	    	 renderer:safeHtmlRenderer,
    	                               	    	 readOnly:true
    	                               	    	
    	                               	      },
    	                               	      {
    	                                	    data:'currentFormularyStatus',
    	                                	    renderer:safeHtmlRenderer,
    	                                	    readOnly:true
    	                               	    	
    	                               	      },
    	                               	      {
    	                               	        data:'baserebate',
    	                               	        //type: 'numeric',
    	                               	         //format: '0.00%',
    	                               	        renderer:safeHtmlRenderer,
    	                                	    readOnly:true
    	                               	      
    	                               	      },
    	                               	       {
    	                               	         data:'incrementalRebate',
    	                               	        // type: 'numeric',
    	                               	         //format: '0.00%',
    	                               	        renderer:safeHtmlRenderer,
    	                               	         readOnly:true
    	                               	      
    	                               	      },
    	                               	      {
    	                               	         data:'contractedGrossSales',
    	                               	         //type: 'numeric',
    	                               	       //  format: '$0,0.00',
    	                               	        renderer:safeHtmlRenderer1,
    	                               	         autoWrapCol:true,
    	                                	     readOnly:true
    	                               	      
    	                               	      },
    	                               	      {
    	                               	         data:'contractedRebate',
    		                               	     // type: 'numeric',
    	                               	         //format: '$0,0.00',
    	                               	        renderer:safeHtmlRenderer1,
    		                                	 readOnly:true
    	                               	      
    	                               	      },
    	                               	      {
    	                               	         data:'averageRebate',
    	                               	    	 //  type: 'numeric',
    	                               	         //format: '0.00%',
    	                               	        renderer:safeHtmlRendererPercentageNotEditable,
    		                                	 readOnly:true
    	                               	      
    	                               	      },
    	                               	       {
    	                               	         data:'gopsDollar',
    	                               	         // type: 'numeric',
    	                               	         //format: '$0,0.00',
    	                               	        renderer:safeHtmlRenderer1,
    	                               	        autoWrapCol:true,
    	                                	    readOnly:true
    	                               	      
    	                               	      },
    	                               	       {
    	                               	         data:'calculatedContractedGrossSales',
    	                               	      renderer:safeHtmlRendererPercentageNotEditable,
    	                                	     readOnly:true
    	                               	      
    	                               	      },
    	                               	       {
    	                               	    	data:'isBidActive',
                                     	        editor: 'select',
                                     	       renderer:yesNoRenderer,
                                                selectOptions: ['Yes','No'],
                                                readOnly:false
    	                               	      
    	                               	      },
    	                               	       {
    	                               	         data:'bidRebate',
    	                               	        // type:'numeric',
    	                               	         renderer:safeHtmlRenderereditable,
    	                                	    	 readOnly:false
    	                               	      
    	                               	      },
    	                               	       {
    	                               	         data:'bidApproach',
    	                               	         renderer:safeHtmlRenderereditable,
    	                                	    	 readOnly:false
    	                               	      
    	                               	      },
    	                               	       {
    	                               	         data:'projectedFormularyStatus',
    	                               	         renderer:safeHtmlRenderereditable,
    	                                	    	 readOnly:false
    	                               	      
    	                               	      },
    	                               	      {
    	                               	    	  data:'bidDuedate',
                                     	    	  type: 'date',
                                     	    	  renderer:safeHtmlRenderereditable,
                                   	          dateFormat: 'MMM DD,YYYY',
                                   	          correctFormat: true,
                                   	          //defaultDate: '2016-06-29',
                                   	          allowEmpty: true,
                                   	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                                   	          datePickerConfig: {
                                   	          // First day of the week (0: Sunday, 1: Monday, etc)
                                   	          firstDay: 0,
                                   	          showWeekNumber: true,
                                   	          numberOfMonths: 1,
    	                             	          
    	                             	        },
    	                             	      readOnly:false
    	                               	    	},
    	                               	     {
    	                                    	     data:'lastModifiedBy',
    	                                    	     renderer:safeHtmlRenderer,
    	                                     	    readOnly:true
    	                                    	      
    	                                    	      },
    	                                 	      
    	                                 	     {
    	                                	    	  data:'lastModifiedOn',
    	                                	    	  type: 'date',
    	                                	    	  renderer:safeHtmlRenderer,
    	                              	          dateFormat: 'MMM DD,YYYY',
    	                              	          correctFormat: true,
    	                              	          //defaultDate: '2016-06-29',
    	                              	          allowEmpty: false,
    	                              	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
    	                              	          datePickerConfig: {
    	                              	          // First day of the week (0: Sunday, 1: Monday, etc)
    	                              	          firstDay: 0,
    	                              	          showWeekNumber: true,
    	                              	          numberOfMonths: 1,
    	                              	          
    	                              	        },
    	                              	        readOnly:true
    	                                	    	}
                                    	      
                               	      ] ,
                               	  
                               	        afterGetColHeader: function(col, TH) {
                    	    var TR = TH.parentNode;
                    	    var THEAD = TR.parentNode;
                    	    var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                    	    function applyClass(elem, className) {
                    	      if (!Handsontable.Dom.hasClass(elem, className)) {
                    	        Handsontable.Dom.addClass(elem, className);
                    	      }
                    	    }

                    	    // first level from the top
                    	    if (headerLevel === -2 && (col===0||col===1||col===2)) {
                      	      applyClass(TH, 'color2');

                      	    // second level from the top
                      	    }else if (headerLevel === -2 && (col===3||col===4||col===5||col===6||col===7||col===8||col===9||col===10)) {
                        	      applyClass(TH, 'bluecolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -1) {
                      	    	applyClass(TH, 'color1');
                       	       
                    	      }
                  	     
                       }
                  	      
        	
        	  }
    		
    		var network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
	 function safeHtmlRenderer(instance, td, row, col, prop, value, cellProperties) {
    		   		    	   //$(td).css({"overflow-y":'auto'});
    		   	                //alert(value);
		 					$(td).css({"background-color":'#FFFFFF'});
    		   	               if(!value || value=='readonly' || value == 'Jan 1, 9900'){
    		   	               value="";
    		   	               }
    		   	                var workaround = "<div class='work'>"+value+"</div>";
    		   	                 $(td).html(workaround);
    		   	                /*  $(td).css({"overflow-y":'auto'});
    		   	                 $(td).css({"overflow-x":'auto'}); */
    		   	                 return td;
    		   		    	  }
    		   		    	  
    		   		    	  
    		   		    	  function safeHtmlRenderer1(instance, td, row, col, prop, value, cellProperties) {
    		   		    	   //$(td).css({"overflow-y":'auto'});
    		   		    	   	var value1;
    		   		    	   
    			   		    	  if(!value ||  value == 9999.9999){
    			   	              	 if(value == null ||  value == 9999.9999){
    				   	               value1="";
    				   	                var workaround = "<div>"+value1+"</div>";
    				   	                 $(td).html(workaround);
    				   	                }else{
    				   	                value1=''; 
    				   	               var dollar="$";
    		   	              		  var million="M";
    		   	              		   var workaround = "<div>"+value1+"</div>";
    				   	                 $(td).html(workaround);
    				   	                }
    			   	               }else{
    			   	            	   value1=value;
    			   	               	   var dollar="$";
    		   	              		  var million="M";
    		   	              		   var workaround = "<div>"+dollar+value1+million+"</div>";
    		   	               	  $(td).html(workaround);
    		   	                		
    			   	               }
    			   		    	$(td).css({"background-color":'#FFFFFF'});
    		   	             
    		   	                 return td;
    		   		    	  }
    		   		    	  
    		   		    	  
    		   		    	 function safeHtmlRenderereditable(instance, td, row, col, prop, value, cellProperties) {
    		     		    	   $(td).css({"background-color":'#e0e2e5'});
    		     	                //alert(value);
    		     	               if(!value || value== 9999.9999 || value=='readonly' || value == 'Jan 1, 9900'){
    		     	               value="";
    		     	               }
    		     	                var workaround = "<div class='work'>"+value+"</div>";
    		     	                 $(td).html(workaround);
    		     	                /*  $(td).css({"overflow-y":'auto'});
    		     	                 $(td).css({"overflow-x":'auto'}); */
    		     	                 return td;
    		     		    	  }
    		   		    	 

    	         	    	  function yesNoRenderer(instance, td, row, col, prop, value, cellProperties) {
    	         	    	  if(!value){
    	         	    	  value='Select';
    	         	    	   td.innerHTML = value;
    	         	    	  }else{
    	         	    		  if(value == 'readonly'){
    	         	    			 value="";
    	         	    			 td.innerHTML = value;
    	         	    		  }else{
    	         	    			 td.innerHTML = value;
    	         	    		  }
    	         	    	   
    	         	    	  }
    	         	    	 
    	         	    	
    	                        if(value==='Y' || value==='N'|| value==='TBD'){
    	                     	 
    	                     	  td.innerHTML = value;
    	                        }
    	                        $(td).css({"background-color":'#e0e2e5'});
    	                      
    	         	    	    return td;
    	         	    	  }
    		   		    	  
    		   		    	  function safeHtmlRendererPercentage(instance, td, row, col, prop, value, cellProperties) {
    		   		    	 
    		   		    	   //$(td).css({"overflow-y":'auto'});
    		   		    	   	var value1;
    		   		    	   	
    			   		    	  if(!value ||  value == 9999.9999){
    				   		    	  if(value == null ||  value == 9999.9999){
    				   	               value1="";
    				   	                var workaround = "<div>"+value1+"</div>";
    				   	                 $(td).html(workaround);
    				   	                }else{
    				   	                value1=' '; 
    				   	                var workaround = "<div>"+value1+"</div>";
    				   	                 $(td).html(workaround);
    				   	                }
    			   	               
    			   	               }else{
    			   	               value1=value;
    			   	                var workaround = "<div>"+value1+"%</div>";
    		   	                 $(td).html(workaround);
    			   	               }
    		   	                 
    			   		    	$(td).css({"background-color":'#e0e2e5'});
    		   	                 return td;
    		   		    	  }
    		   		    	  
    		   		    	function safeHtmlRendererPercentageNotEditable(instance, td, row, col, prop, value, cellProperties) {
       		   		    	 
     		   		    	   //$(td).css({"overflow-y":'auto'});
     		   		    	   	var value1;
     		   		    	   	
     			   		    	  if(!value ||  value == 9999.9999){
     				   		    	  if(value == null ||  value == 9999.9999){
     				   	               value1="";
     				   	                var workaround = "<div>"+value1+"</div>";
     				   	                 $(td).html(workaround);
     				   	                }else{
     				   	                value1='0.00'; 
     				   	                var workaround = "<div>"+value1+"%</div>";
     				   	                 $(td).html(workaround);
     				   	                }
     			   	               
     			   	               }else{
     			   	               value1=value;
     			   	                var workaround = "<div>"+value1+"%</div>";
     		   	                 $(td).html(workaround);
     			   	               }
     		   	                 
     			   		    	$(td).css({"background-color":'#FFFFFF'});
     		   	                 return td;
     		   		    	  }
    		   		    	
    		   		     
    		   		    	function readOnlyRenderer(instance, td, row, col, prop, value, cellProperties) {
    		   		    	 if(!value || value== 9999.9999 || value=='readonly' || value == 'Jan 1, 9900'){
  		     	               value="";
  		     	               }
	    		   		    	var workaround = "<div class='work'>"+value+"</div>";
		     	                 $(td).html(workaround);
     			   		    	$(td).css({"background-color":'#FFFFFF'});
     		   	                 return td;
     		   		    	  }
		    	  
    		
}

