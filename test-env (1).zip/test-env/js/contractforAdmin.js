$(document).ready(function()
{ 
	
	

$(".form-style-1").hide();


jQuery.ajax({
    type:"get",
    dataType:"json",
    url:urlPrefix+"/JanssenSCG/epudesc",
    data:{userId:userID},
    async:true,
    success: function(responseText) { 
        Response= responseText;
},
complete: function(){
              
      $('<option/>').val("").html("Select").appendTo('#epudesc1');
     
       $.each(Response, function(key, value) {
       
					  $('<option/>').val(key).html(value).appendTo('#epudesc1');
					  epudesc.push(value);
			});	
   	              
					
	

}
});
jQuery.ajax({
    type:"get",
    dataType:"json",
    url:urlPrefix+"/JanssenSCG/strategyname",
    data:{userId:userID},
    async:true,
    success: function(responseText) { 
        Response= responseText;
},
complete: function(){              
      $('<option/>').val("").html("Select").appendTo('#strategyName');     
       $.each(Response, function(key, value) {  
     		  $('<option/>').val(key).html(value).appendTo('#strategyName');
			  strategyname.push(value);
});	
 
}
});


// ************************************************************

var new_dialog = 	function (type, row) {
                
	var dlg = $(".form-style-1").clone();
	var config;
	//alert(customer);
	 var options = '<option value="' + customer + '">'+customer+'</option>';
	 dlg.find("#customer1").val(customer);
	 dlg.find("#customer1").html(options);
	 dlg.find("#customer1").attr("disabled", true); 
	 	//dlg.find("#customer1").attr("disabled", true); 
	// options = '<option value="'+product+'">'+product+'</option>';
	$('#productPicker option').clone().appendTo(dlg.find("#product1"));
	 //dlg.find("#product1").html(options);
	// dlg.find("#product1").val(product);
 	//dlg.find("#product1").attr("disabled", true);
 	options = '<option value="'+channel+'">'+channel+'</option>';
 	 dlg.find("#channel1").html(options);
 	 dlg.find("#channel1").val(channel);
  	dlg.find("#channel1").attr("disabled", true); 
                //alert("new dialog");
                
                type = type || 'Create';
                 config = {
                    autoOpen: true,
                    width: 695,
                    height: 650,
                    modal: true,
                   // position: { my: "center", at: "center", of: window },
                    buttons: {
                        'Save': save_data,
                        'Reset': function () {
                        	dlg.find("#customertype1").val("");
                        	dlg.find("#document1").val("");
                            dlg.find("#bookofbusiness1").val("");
                           
                            dlg.find("#medicalpharmacy1").val("");
                            dlg.find("#epudesc1").val("");
                            dlg.find("#utilizationmanagement1").val("");
                            dlg.find("#strategyName").val("");
                            dlg.find("#rebate").val("");
                            dlg.find("#performanceRebate").val("");
                            dlg.find("#baselineDate").val("");
                            dlg.find("#adminFee").val("");
                            dlg.find("#irceiling").val("");
                            dlg.find("#startdate").val("");
                            dlg.find("#enddate").val("");
                            dlg.find("#comments").val("");
                                                           
                        }
                       
						
                    },
                    close: function () {
                        dlg.remove();
                    }
                };
               
                dlg.dialog(config); 
                
                
                function save_data(){
                	//alert("hi");
                	
                	var accountLead=$('#selection option:selected').text();
                	//alert(accountLead);
                	  var customer1=dlg.find("#customer1").val();
                	//alert(customer1);
                       var product1=dlg.find("#product1").val();
                      //alert(product1);
                       var channel1=dlg.find("#channel1").val();
                       
                       var document=dlg.find("#document1").val();
                     
                       var customertype1=dlg.find("#customertype1").val();
                     
                       var bokofbusiness=dlg.find("#bookofbusiness1").val();
                       var bokofbusinesses=bokofbusiness.toString().split(",");
                      //alert(bokofbusiness);
                       var medicalpharmacy=dlg.find("#medicalpharmacy1").val();
                       var epudesc1=dlg.find("#epudesc1").val();
                       var utilizationmanagement1=dlg.find("#utilizationmanagement1").val();
                       var strategyName=dlg.find("#strategyName").val();
                       var rebate=dlg.find("#rebate").val();
                       var performanceRebate=dlg.find("#performanceRebate").val();
                       var baselineDate=dlg.find("#baselineDate").val();
                       var adminFee=dlg.find("#adminFee").val();
                       var irceiling=dlg.find("#irceiling").val();
                       var startdate=dlg.find("#startdate").val();
                       var enddate=dlg.find("#enddate").val();
                       var comments=dlg.find("#comments").val();
                      // alert(comments);
                       var filecontract = dlg.find("#filecontract").get(0).files[0];
                       var validateSuccess=validatefilesize(filecontract,dlg);
                       var notifyFD=dlg.find("#notifyFD").is(':checked');
                      // alert(notifyFD);
                       var formData = new FormData();
                      formData.append('filecontract', filecontract);
                      formData.append('notifyFD',notifyFD);
                       //alert();
                       var urlPrefix = window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
                       var dataArray=new Array();
                       for(var i=0;i<bokofbusinesses.length;i++){
                    	   var data={'accountLead':accountLead, 'accountName':customer1, 'channel':channel1, 'product':product1,'documentType':document, 'customerType':customertype1,'bookOfBusiness':bokofbusiness[i].toString(),'medicalPharmacy':medicalpharmacy,'epuDescription':epudesc1.toString(),'utilizationManagement':utilizationmanagement1.toString(),'rebate':rebate,'strategyName':strategyName,'performanceRebate':performanceRebate,'irCeiling':irceiling,'baselineDLPDate':baselineDate,'requestorType':'FIELD','adminFee':adminFee,'effectiveDate':startdate,'endDate':enddate,'comments':comments};
                    	   dataArray.push(data);
                       }
                      
                       var jsonData = JSON.stringify(dataArray);
                      // alert(jsonData);
	                       if(validateSuccess){
	                    	  
	                    	   $("#CommGrid").css('visibility', 'hidden');
	                           //alert("hi1");
	                            //$("#savediv").style.visibility = "hidden";
	                            $("#savediv").hide();
	                            // alert("hi2");
	                           // document.getElementById("confirmdiv").style.visibility = "hidden";
	                            
	                             //alert("hi4");
	                            $("#loadingmsg").css('visibility', 'hidden');
	                       formData.append('content', jsonData);
	                       jQuery.ajax({
	  	                     type:"post",
	  	                     dataType:"json",
	  	                   
	  	                     url:urlPrefix+"/JanssenSCG/contractadd",
	  	                     data:formData,
	  	                     async:true,
	  	                   processData: false,
	  	                   contentType: false,
	  	                     success: function(response) { 
	  	                    	// alert("ajax response contractadd"+response.saveSuccessMsg);
	  	                    	 Response= response.saveSuccess;
	  	                    	 var identifier=response.identifier;
	  	                    	 //alert(identifier);
	  	                         var title;
	  	                         var alertText;
	  	                       if(Response=='saveSuccess'){
	  	                    	 title="Sucessfully saved";
	  	                    	 text="Successfully saved changes.Do you want to Raise another Offer?"
		  	                     type="success";
	  	                       }else{
	  	                      	 title="Oops! Data Not saved";	  	                      	 
	  	                      	 text=response.validationMessage+".Do you want to Raise again?";
	  	                      	type="warning";
	  	                       } 
	  	                     $('#productPicker').val(product1);
	  	                      // $('#businessPicker').val(customer1);
	  	                       //$('#channelPicker').val(channel1);
	  	                         swal({
							        title: title,
							        text: text,
							        type: type,
							        showCancelButton: true,
							        confirmButtonColor: "#DD6B55",
							        confirmButtonText: "YES",
							        cancelButtonText: "NO",
							        closeOnConfirm: true,
							        closeOnCancel: true,
				    				}, function(isConfirm) {
				    				
				    				if(isConfirm){
				    					new_dialog();
				    					 
				    				}
                  /* else
                    {
                      alert("Hello");
                    }*/
				    				});
	  	                      
			    				 handsonComm.updateOptions({		    					
	                        	 			data:getDataByIdentifier(identifier)
	                        	 	});
	                        	 	handsonComm.render();
	  					},
	  	              complete: function(){
	  	            	 $("#CommGrid").css('visibility', 'visible');
	                       
	                        $("#savediv").show();
	                        $("#confirmdiv").show();
	                        
	                        $("#loadingmsg").css('visibility', 'hidden');  
	  	              }
	  	              });
	                       dlg.dialog("close");    
		                       $("#CommGrid").css('visibility', 'hidden');
		                       
		                        $("#savediv").hide();
		                        $("#confirmdiv").hide();
		                        
		                        $("#loadingmsg").css('visibility', 'visible');                        
	                }
                }
                   
             
          };
          var customer;
          var product;
          var channel;
          var accountLead;  
            $("#newoffer").click(function(){
            	accountLead=$("#selection").val();
            	
            	
            	  customer=$("#businessPicker").val();
            	 
                    product=$("#productPicker").val();
                   
                    channel=$("#channelPicker").val();
                   
                   if(empty(accountLead) || empty(customer) || empty(channel)){
                	   alert("Please select account,product,channel to raise new request");
                   }else{
                	   /*alert("hi");
                	   alert("new offer"+accountLead);
                	   alert("new offer"+customer);
                	   alert("new offer"+product);
                	   alert("new offer"+channel);*/
                	   new_dialog();
                   }
            }); 
            
            function empty(str)
      	  {
      	      if (typeof str == 'undefined' || !str || str.length === 0 || str === '' || !/[^\s]/.test(str) || /^\s*$/.test(str) )
      	      {
      	          return true;
      	      }
      	      else
      	      {
      	          return false;
      	      }
      	  }
            
            function checkfiletype(ext) {
            	var supportedfiletype=['xls', 'xlsx', 'doc','docx' , 'ppt', 'pptx', 'zip', 'pdf', 'jpg', 'jpeg','msg'];
            	if(supportedfiletype.includes(ext)){
            		return true;
            	}
               return false;
            };      
            function validatefilesize(file,dlg)
            	{
            	//alert("file validation"+file.name);
            	var success=true;
            	  var startdate=dlg.find("#startdate").val();
                  var enddate=dlg.find("#enddate").val();
                  var bokofbusiness=dlg.find("#bookofbusiness1").val();
                  var bokofbusinesses=bokofbusiness.toString().split(",");
                   var customertype1=dlg.find("#customertype1").val();
                 //alert(bokofbusiness);
                  var product1=dlg.find("#product1").val();
                  var medicalpharmacy=dlg.find("#medicalpharmacy1").val();
                  var document=dlg.find("#document1").val();
                  var epudesc1=dlg.find("#epudesc1").val();
                  var utilizationmanagement1=dlg.find("#utilizationmanagement1").val();
                  var strategyName=dlg.find("#strategyName").val();
                  var rebate=dlg.find("#rebate").val();
                  var notifyFD=dlg.find("#notifyFD").is(':checked');
                  //alert("start date"+startdate+"End date"+enddate);
                  if(empty(bokofbusiness) || empty(document) || empty(product1) || empty(medicalpharmacy) || empty(epudesc1) || empty(strategyName)||empty(rebate)||empty(customertype1)||empty(utilizationmanagement1)||(!dlg.find("#notifyFD").is(':checked'))){
                	  dlg.find("#mandatorystartenddatedifference").hide();
                	  dlg.find("#mandatoryfield").show(); 
                	  success=false;
                  }else if(empty(startdate) || empty(enddate)){
                	  dlg.find("#mandatorystartenddate").show(); 
                	  success=false;
                 
                  }else if(enddate<startdate){
                	  dlg.find("#mandatorystartenddate").hide();
                	  dlg.find("#mandatorystartenddatedifference").show(); 
                	  success=false;
                  }
            	if(file!=null){
	            	var ext=(file.name).split('.')[1];
	            	if(!checkfiletype(ext)) {
	            	
	            	 dlg.find("#mandatoryfieldMsgType").show(); 
	            	 success=false;
	            	}
	            	if(file.size > 5*1024*1024)
	               	{
	               //  $(this).val('');
	                 dlg.find("#mandatoryfieldMsgSize").show(); 
	                 success=false;
	               	}
	            	
            	}
            	return success;
            	
             } 
 
});



