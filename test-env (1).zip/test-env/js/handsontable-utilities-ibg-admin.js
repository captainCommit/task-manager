
function Handson(containerid){
	
         var container = document.getElementById(containerid);
        var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
         var data;
         console.log("filter"+filter);
         
    		var options = {
    			data:[],
        	    colWidths: [75,75,75, 100,100,200,200,200,100,100,300,100, 200, 200,100,100,300,200,200,200,200,150,100,200,100,200,200],
        	  //  rowHeights:20,
        	    comments: true,
        	    search:true,
        	    columnSorting: true,
        	    sortIndicator: true,
        	    manualColumnResize: true,
        	    manualRowResize: true, 
        	    preventOverflow: 'horizontal',
        	 //   filters:true,
        	    colHeaders:true,
        	    contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        } }
                },
        	    contextMenuCopyPaste: {
        	        swfPath: 'js/ZeroClipboard.swf'
        	      },
        	    fixedColumnsLeft: 3,
        	    manualColumnFreeze:true,
        	  //  dropdownMenu: true,
        	  //  filters:true,
        	    nestedHeaders: [
        	                    [{label: ' ', colspan:5}, {label: 'REMICADE Access Insights', colspan:8}, {label: 'VOC  Intelligence', colspan:6}, {label: 'Post Launch - Supplemental GPO Contract Offer', colspan:10}],
       	                   //  ['Field Director','Business Name', 'IBG Tier','Segmentation','PHS Mix','Remicades Pre-Biosim Launch Formulary Status? ','Projected Date of REMICADE vs. Inflectra P&T Formulary Review? ','What do you expect the outcome of the P&T Formulary Review will be for Remicade? ','Remicade Current Formulary Status? ','Inflectra Current Formulary Status? ','Will your customer treat Remicade and the biosimilar as interchangeable?','Do you expect the customer to employ Non-Medical Switching to Inflectra?','Please add any additional Comments regarding Remicade Access for this Account','Has this account received a  competitive offer?','Was the competitive offer for an individual product,  as part of portfolio overlay, or both','Has the customer compliantly informed you of the net discount range that  will be required by Janssen to maintain competitive access ','Please select the form of  discount requested','Required Date for Remicades competitive pricing/contract response ','Please add any additional VOC regarding the offer required by Janssen to remain competitive in this account.','Total Remicade  Sales $','Rebate Eligible MD Sales','Overlay Contract Status','Remicade Blended Discount; Before Supplemental GPO Offer','Is Janssen putting a Supplemental GPO Discount into the market','Date the Supplemental GPO contract was delivered to customer','Please provide any customer feedback/status regarding the Supplemental GPO Contract Offer','Date the Supplemental GPO contract was signed by the customer','Remicade Proposed Supplemental GPO Discount','Remicade Blended Discount After Supplemental GPO Offer']],
        	                      ['Field Director','Business Name', 'IBG Tier','Segmentation','PHS Mix','Remicade Current Formulary Status? ','Inflectra Current Formulary Status? ','Renflexis Current Formulary Status?','Will your customer treat Remicade and the biosimilar as interchangeable?','Do you expect the customer to employ Non-Medical Switching to biosimilars?','Please add any additional Comments regarding Remicade Access for this Account','Has this account received a  competitive offer?','Was the competitive offer for an individual product,  as part of portfolio overlay, or both','Has the customer compliantly informed you of the net discount range that  will be required by Janssen to maintain competitive access ','Please select the form of  discount requested','Required Date for Remicades competitive pricing/contract response ','Please add any additional VOC regarding the offer required by Janssen to remain competitive in this account.','Total Remicade  Sales $','Rebate Eligible MD Sales','Overlay Contract Status','Remicade Blended Discount; Before Supplemental GPO Offer','Is Janssen putting a Supplemental GPO Discount into the market','Date the Supplemental GPO contract was delivered to customer','Please provide any customer feedback/status regarding the Supplemental GPO Contract Offer','Date the Supplemental GPO contract was signed by the customer','Remicade Proposed Supplemental GPO Discount','Remicade Blended Discount After Supplemental GPO Offer']],
       	         columns: [
                      	    	{
                              	      data:'ibgRemicadeId.fieldDirectorId',
                              	      readOnly:true
                              	  },                                 	    
                           	      {
                              	      data:'ibgRemicadeId.businessNameId',
                              	      readOnly:true
                              	   },
                              	   {
                              	      data:'ibgRemicadeId.ibgTierId',
                              	      readOnly:true
                              	   },
                         	      {
                         	    	  data:'segmentation',
                         	    	  renderer:safeHtmlRenderer,
                        	    	  allowInvalid: false,
                                      validator: limit_validator_regexp
                         	    	 
                           	      },
                           	      {
                         	    	  data:'phsMix',
                         	    	  renderer:safeHtmlRenderer,
                        	    	  allowInvalid: false,
                                      validator: limit_validator_regexp
                         	    	 
                           	      },
                         	     /* {
                         	    	  data:'prebiosimlaunch',
                         	    	  renderer:safeHtmlRenderer,
                        	    	  allowInvalid: false,
                                      editor: 'select',
                                      selectOptions: ['Formulary Preferred', 'Formulary Equal Status', 'Non Formulary']
                         	    	 
                           	      },
                           	      {
                           	    	  data:'projectdateof' ,
                           	    	  type: 'date',
                         	          dateFormat: 'MM/DD/YYYY',
                         	          correctFormat: true,
                         	          defaultDate: '2016-06-29',
                         	          allowEmpty: false,
                         	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                         	          datePickerConfig: {
                         	          // First day of the week (0: Sunday, 1: Monday, etc)
                         	          firstDay: 0,
                         	          showWeekNumber: true,
                         	          numberOfMonths: 1,
                         	         
                         	          }
                           	    	
                           	      },
                           	      {
                            	    	 data:'exceptoutcome',
                            	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                            	    	 editor: 'select',
                                         selectOptions: ['P&T review already complete','Formulary Preferred', 'Formulary Equal Status', 'Non Formulary']
                           	    	
                           	      },*/
                           	      {
                           	    	  	 data:'statusafter',                               	    	 
                               	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                            	    	 editor: 'select',
                                         selectOptions: ['Formulary Preferred', 'Formulary Equal Status', 'Non Formulary']
                           	    	},
                           	    	
                           	      {
                           	    		data:'inflectrastatusafter',
                           	    		renderer:safeHtmlRenderer,
                               	   		allowInvalid: false,
	                               	   	editor: 'select',
	                                    selectOptions: ['Formulary Preferred', 'Formulary Equal Status', 'Non Formulary']
                               	    	 
                           	      },
                           	      {
                         	    		data:'inflexisstatusafter',
                         	    		renderer:safeHtmlRenderer,
                             	   		allowInvalid: false,
	                               	   	editor: 'select',
	                                    selectOptions: ['Formulary Preferred', 'Formulary Equal Status', 'Non Formulary']
                             	    	 
                         	      },
                           	       {
                            	    	 data:'customerTreatRemicade',                            	    	 
                            	    	 renderer:yesNoRenderer,
                            	    	 editor: 'select',
                                         selectOptions: ['Y', 'N']
                           	    	  
                           	      },
                           	      {
                            	    	 data:'employnonmedical',
                            	    	 renderer:yesNoRenderer,
                            	    	 editor: 'select',
                                         selectOptions: ['Y', 'N']
                           	    	  
                           	      },
                           	      {
                               	    	 data:'additionalcomments',
                               	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                                         validator: limit_validator_regexp
                           	      },
                           	      
                           	      {
	                               	     data:'competitiveoffer',
	                               	     renderer:yesNoRenderer,
                            	    	 editor: 'select',
                                         selectOptions: ['Y', 'N']
                           	        
                           	      },
                           	      {
                               	    	 data:'productportfolio',
	                               	     renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                            	    	 editor: 'select',
 	                                     selectOptions: ['Product', 'Portfolio', 'Both']
                           	      },
                           	      {
                              	    	 data:'netdiscountrange',                               	    	 
                              	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                            	    	 editor: 'select',
 	                                     selectOptions: ['15-20%', '20-25%', '25-30%', '30-35%', '35-40%', '40-45%', '45-50%', '50-55%', '55-60%', '60-65%', '65-70%', '70-75%', '75-80%', '80-85%', '85-90%', '90-95%', '95-100%']
                           	      },
                           	      {
                              	    	 data:'formofdiscount',
                              	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                            	    	 editor: 'select',
 	                                     selectOptions: ['OID', 'Rebate', 'Mix of OID & Rebate', 'Other']
                              	       
                           	      },
                           	      {
                             	    	data:'pricingcontract',
                             	    	type: 'date',
                             	    	dateFormat: 'MM/DD/YYYY',
                             	    	correctFormat: true,
                             	    	defaultDate: '2016-06-29',
                             	    	allowEmpty: false,
                         	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                             	    	datePickerConfig: {
                         	          // First day of the week (0: Sunday, 1: Monday, etc)
                             	    	firstDay: 0,
                             	    	showWeekNumber: true,
                             	    	numberOfMonths: 1,
                         	         
                         	          }
                           	      },
                           	      {
                               	    	 data:'additionaloffer',
	                               	     renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                                         validator: limit_validator_regexp
                           	      },
                           	      {
                            	    	 data:'totalremicadesales' ,
                            	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                                         validator: limit_validator_regexp
                           	    	    
                           	      },
                           	      {
                         	    	 data:'rebateEligibleMDSales' ,
                         	    	 renderer:safeHtmlRenderer,
                         	    	 allowInvalid: false,
                                      validator: limit_validator_regexp
                            	    	    
                            	   },
                           	      {
                            	    	 data:'procontractstatus' ,
                            	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                                         validator: limit_validator_regexp
                           	    	
                           	      },
                           	     {
                            	    	 data:'beforesupplementalgpo' ,
                            	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                                         validator: limit_validator_regexp
                           	    	
                           	      },
                           	       {
                            	    	 data:'supplementalGPODiscount' ,
                            	    	 renderer:yesNoRenderer,
                            	    	 editor: 'select',
                                         selectOptions: ['Y', 'N']
                           	    	
                           	      },
                           	      {
                           	    	  	data:'datesupplementgpo' ,
                            	    	type: 'date',
                            	    	dateFormat: 'MM/DD/YYYY',
                            	    	correctFormat: true,
                            	    	defaultDate: '2016-06-29',
                            	    	allowEmpty: true,
                         	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                            	    	datePickerConfig: {
                         	          // First day of the week (0: Sunday, 1: Monday, etc)
                            	    	firstDay: 0,
                            	    	showWeekNumber: true,
                            	    	numberOfMonths: 1,
                         	         
                         	          }
                           	      },
                           	      {
                            	    	 data:'feedbackstatus' ,
                            	    	 renderer:safeHtmlRenderer,
                            	    	 allowInvalid: false,
                                         validator: limit_validator_regexp
                           	    	
                           	      },
                           	      {
                           	    	  	data:'datesupplementalgpocontract' ,
                            	    	type: 'date',
                            	    	dateFormat: 'MM/DD/YYYY',
                            	    	correctFormat: true,
                            	    	defaultDate: '2016-06-29',
                            	    	allowEmpty: true,
                         	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                            	    	datePickerConfig: {
                         	          // First day of the week (0: Sunday, 1: Monday, etc)
                            	    	firstDay: 0,
                            	    	showWeekNumber: true,
                            	    	numberOfMonths: 1,
                         	         
                         	          }                               	    	
                           	      },
                           	      {
                         	    	 data:'proposedsupplementgpo' ,
                         	    	 renderer:safeHtmlRenderer,
                         	    	 allowInvalid: false,
                                      validator: limit_validator_regexp
                        	    	
                        	      },
                        	      {
                         	    	 data:'aftersupplementalgpo' ,
                         	    	 renderer:safeHtmlRenderer,
                         	    	 allowInvalid: false,
                                      validator: limit_validator_regexp
                        	    	
                        	      }
                               	      ] ,
                               	      
                               	        afterGetColHeader: function(col, TH) {
                    	    var TR = TH.parentNode;
                    	    var THEAD = TR.parentNode;
                    	    var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                    	    function applyClass(elem, className) {
                    	      if (!Handsontable.Dom.hasClass(elem, className)) {
                    	        Handsontable.Dom.addClass(elem, className);
                    	      }
                    	    }

                    	    // first level from the top
                    	    if (headerLevel === -2 && (col===0||col===1||col===2||col===3||col===4)) {
                      	      applyClass(TH, 'color2');

                      	    // second level from the top
                      	    }else if (headerLevel === -2 && (col===5||col===6||col===7||col===8||col===9||col===10||col===11||col===12)) {
                        	      applyClass(TH, 'bluecolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -2 && (col===13||col===14||col===15||col===16||col===17||col===18)) {
                        	      applyClass(TH, 'marooncolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -2 && (col===19||col===20||col===21||col===22||col===23||col===24||col===25||col===26||col===27||col===28)) {
                        	      applyClass(TH, 'greencolor');

                        	    // second level from the top
                        	    }  else if (headerLevel === -1) {
                      	    	applyClass(TH, 'color1');
                       	       
                    	      }
                  	     
                       }
                  	      
        	
        	  }
    		
    		var network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
    	
      
    		
}
        	  