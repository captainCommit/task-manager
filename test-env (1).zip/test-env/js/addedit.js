function onload(){
    const stg = document.getElementById('stg')
    console.log(stg)
}
const head = [
    {
      key : 'index',
      thClass : "bg-primary text-light font-weight-bold justify-content-center font-10 nopad",
      tdClass : "smallcol justify-content-center bg-info"
    },
    
    {
      key: 'customer_name',
      label: 'Customer Name',
      sortable: true,
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "medcol bg-info"
    },
    {
      key: 'contract_description',
      label: 'Contract Description',
      sortable: true,
      thClass : "bg-primary medcol text-light font-weight-bold font-10",
      tdClass : "bg-info"
    },
    // {
    //   key: 'bundle_description',
    //   label: 'Bundle Description',
    //   sortable: true,
    //   thClass : "bg-primary text-light font-weight-bold font-10",
    //   tdClass : "bg-info"
    // },
    {
      key : 'action',
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "smallcol justify-content-center bg-info",
      _showDetails: true
    },
  ]
const sub = [
    {
      key : 'index',
      tdClass : "smallcol justify-content-center bg-light"
    },
    {
      key: 'bundle_uid',
      label: 'UID',
      sortable: true,
      tdClass : "smallcol bg-light"
    },
    {
      key: 'customer_name',
      label: 'Customer Name',
      sortable: true,
      tdClass : "medcol bg-light"
    },
    {
      key: 'contract_description',
      label: 'Contract Description',
      sortable: true,
      tdClass : "bg-light medcol"
    },
    {
      key : 'bundle_description',
      label: 'Bundle Description',
      tdClass : "justify-content-center bg-light",
    },
  ]
const dump = [
    {
      
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        }
      ]
    },
    {
      
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        }
      ]
    },
    {
      
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        },
        {
          "bundle_uid" : 1002,
          "bundle_description" : "Stelara PsA Additional Rebate",
        },
        {
          "bundle_uid" : 1003,
          "bundle_description" : "Pending",
        }
      ]
    },
    {
      
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        },
        {
          "bundle_uid" : 1002,
          "bundle_description" : "Stelara PsA Additional Rebate",
        },
        {
          "bundle_uid" : 1003,
          "bundle_description" : "Pending",
        }
      ]
    },
    {
      
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        },
        {
          "bundle_uid" : 1002,
          "bundle_description" : "Stelara PsA Additional Rebate",
        },
        {
          "bundle_uid" : 1003,
          "bundle_description" : "Pending",
        }
      ]
    },
    {
      
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        },
        {
          "bundle_uid" : 1002,
          "bundle_description" : "Stelara PsA Additional Rebate",
        },
        {
          "bundle_uid" : 1003,
          "bundle_description" : "Pending",
        }
      ]
    },
    {
      
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        },
        {
          "bundle_uid" : 1002,
          "bundle_description" : "Stelara PsA Additional Rebate",
        },
        {
          "bundle_uid" : 1003,
          "bundle_description" : "Pending",
        }
      ]
    }
  ]