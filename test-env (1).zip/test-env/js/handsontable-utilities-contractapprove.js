var changedRowIndexArr=[];
var changedarr=[];
var network;
var epudesc=new Array();
var strategyname=new Array();
function Handson(containerid){
	
         var container = document.getElementById(containerid);
   //     var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
        
    		var options = {
    			data:[],
    			 colWidths: [90,120,140,120,120,150,120,100,120,120,120,120,120,120,140,100,100,100,100,100,100,450,130,100],
        	  //  rowHeights:20,
    			 comments: true,
           	    search:true,
           	    columnSorting: true,
           	    sortIndicator: true,
           	    manualColumnResize: true,
           	    manualRowResize: true, 
           	 viewportColumnRenderingOffset:38,
           	    preventOverflow: 'horizontal',
           	 //   filters:true,
           	    colHeaders:true,
           	    contextMenu: {
                       items: {  "copy": {name: "Copy"},
                           "paste": {
                               name: 'Paste',
                               callback: function () {
                                   this.copyPaste.triggerPaste();
                               }
                           } }
                   },
           	    contextMenuCopyPaste: {
           	        swfPath: 'js/ZeroClipboard.swf'
           	      },
           	   afterChange: function(changes, source){
           		
                   if(source === 'edit' || source === 'paste'){
                	 if((changedRowIndexArr!=null && changedRowIndexArr.length==0) || $.inArray(changes[0][0], changedRowIndexArr) == -1){
                		changedRowIndexArr.push(changes[0][0]);
                	 }
                   }
               } , 
            
        	    
        	   /* afterOnCellMouseDown: function(event, coords){
        	        // 'coords.row < 0' because we only want to handle clicks on the header row
        	       // alert(coords.row);
        	    	var rowTemp= coords.row;
        	    	 var data=this.getDataAtRow(coords.row);
        	    	 var data1 = JSON.stringify(data);
        	    	 var b= getIsLockedContract(data1);
        	    	
        	    	 if(b == true)
						{
						 alert("This row is being edited by some other user....Please try after some time");
						 this.deselectCell();
						 if(rowTemp == 0){
							 this.selectCell(rowTemp+1,rowTemp+1);
						 }else{
							 this.selectCell(rowTemp-1,rowTemp-1);
						 }
						 
						 return false;
						}
					 
        	    },
        	    */
        	   /* contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        }
                    }*/
        	    
                        /*"row_above":{name: "Insert a row above"
                        	
                    	},
                    "row_below":{name: "Insert a row below"},
                   "remove_row":{name: "Remove",
                	   callback: function(key, selection) {
                		      var amount = selection.end.row - selection.start.row + 1;
                		      if(amount>1){
                		    	  alert("Please select only one row to delete");
                		    	  return false;
                		      }else{
                		    	  var strconfirm = confirm("Are you sure you want to delete?");
                		    	    if (strconfirm == false) {
                		    	        return false;
                		    	    }
                		     var data=this.getDataAtRow(selection.start.row);
                		      var data1 = JSON.stringify(data);
                		      //alert("data: "+data1);
                		      jQuery.ajax({
                                  type:"POST",
                                  dataType:"json",
                                  url:urlPrefix+"/JanssenSCG/deleteRow",                    
                                  data:{data: data1},
                                  async:false,
                                  success: function(responseText) { 
                                      Response= responseText;                                      
                                        },
                           complete: function(){
                                fil = Response[0];
                                        }
                             });
                		      //removeRow(data1);
                		      this.alter('remove_row', selection.start.row, amount);
                	   }
                		    }
                	   }
                    	}*/
               /* },
        	    contextMenuCopyPaste: {
        	        swfPath: 'js/ZeroClipboard.swf'
        	      },*/
        	    fixedColumnsLeft: 7,
        	    manualColumnFreeze:true,
        	   
        	  //  dropdownMenu: true,
        	  //  filters:true,
        	    nestedHeaders: [
        	                    [{label: ' ', colspan:7},{label: 'Field Input', colspan:16},{label: ' ', colspan:1}],
        	                  
       	                     ['SMD','Customer','OD Contact','Channel','Product','Unique Identifier','Date Offer Requested','Document Type','Customer Type','Book Of Business','Medical/Pharmacy','Utilization Management','EPU Description','Rebate %','Strategy Name','Performance Rebate %(If App)','IR Annual Ceiling Cap %','Baseline DLP date(if App)','Admin/Service Fee(If App)','Effective Date','End Date','Comments','Attachment(If any)','Approve']],
       	         columns: [
                      	    	 
                      	    	 
								       {   
									      data:'accountLead',
									      renderer:safeHtmlRenderer,
									      readOnly:true
									   },
									   {   
										      data:'accountName',
										      renderer:safeHtmlRenderer,
										      readOnly:true
										   },
								        {   
										    data:'odLead',
										    renderer:safeHtmlRenderer,
											readOnly:true
								       },
									  {   
									     data:'channel',
									     renderer:safeHtmlRenderer, 
									     readOnly:true
									   },
									   {   
										     data:'product',
										     renderer:safeHtmlRenderer,  
										     readOnly:true
										   },
                      	    	       {
                                   	      data:'uniqueIdentifier',
                                   	   renderer:safeHtmlRenderer,
                                   	      readOnly:true
                                   	   },
                                   	   {
                                  	     data:'startDate',
                                  	     renderer:safeHtmlRenderer,
                                	      	 readOnly:true
                                  	    },
                                   	   {
                                  	      data:'documentType',
                                  	    editor: 'select',
                                  	  renderer:safeHtmlRenderereditable,
                                        selectOptions: ['Amendment', 'Master-Existing Account', 'Master-New Account','New-Product Document','proposal'],
                                        readOnly:false
                                  	   },
                                  	   
                                  	 {
                                   	   data:'customerType',
                                   	   editor: 'select',
                                   	 renderer:safeHtmlRenderereditable,
                                       selectOptions: ['MBM - Capitated','MBM - Limited','MCO','PBM'],
                                   	   readOnly:false
                                   	   },
                              	      
                              	      {
                              	    	  data:'bookOfBusiness',
                              	    	editor: 'select',
                              	    	renderer: safeHtmlRenderereditable,
                              	    	 selectOptions: ['Commercial','Managed Medicaid','Meicare Part D','QHP','Others-See Comments'],
                                     	   readOnly:false
                                       
                                	      },
                                	      {
                                	    	 data:'medicalPharmacy' ,
                                	    	 editor: 'select',
                                	    	 renderer: safeHtmlRenderereditable,
                                  	    	 selectOptions: ['Medical','Medical if Pharmacy','Pharmacy','Pharmacy if Medical','Medical and Pharmacy','Others-See Comments'],
                                	    	
                                             readOnly:false
                                	    	
                                	      },
                                	      {
                                 	         data:'utilizationManagement',
                                 	         renderer: customDropdownRenderer,
                                              editor: 'chosen',
                                              //width: 150,
                                              chosenOptions: {
                                                  multiple: true,
                                                  data: [
                                                      {
                                                          id: "SE",
                                                          label: "SE"
                                                      }, {
                                                          id: "NDC Block",
                                                          label: "NDC Block"
                                                      }
                                                      , {
                                                          id: "PA/NDC Block",
                                                          label: "PA/NDC Block"
                                                      }, {
                                                          id: "Co-Pay Diff",
                                                          label: "Co-Pay Diff"
                                                      },{
                                                          id: "Others-See Comments",
                                                          label: "Others-See Comments"
                                                      }
                                                  ]
                                              },
                                 	         
                                  	    	 readOnly:false
                                 	      
                                 	      },
                                	      {
                                 	    	 data:'epuDescription',
                                 	    	editor: 'select',
                                	    	   renderer: safeHtmlRenderereditable,
                                	    	  trimDropdown:false,
                                  	          selectOptions:epudesc,
                                 	    	 readOnly:false
                                	    	 
                                	      },
                                	     
                                	      {
                                      	    data:'rebate', 
                                      	  renderer:safeHtmlRenderereditableNumeric,
                                	      //type: 'numeric',
                                	       readOnly:false
                                      	   },
                                      	 {
                                         	 data:'strategyName',
                                         	editor: 'select',
                             	    	   renderer: safeHtmlRenderereditable,
                             	    	    trimDropdown:false,
                               	            selectOptions:strategyname,
                              	    	    readOnly:false
                                         },
                                          {
                                       	    data:'performanceRebate',
                                       	 renderer:safeHtmlRenderereditableNumeric,
	                               	     
                                            readOnly:false
                                          },
                                          {
                                         	  data:'irCeiling',
                                         	 renderer:safeHtmlRenderereditableNumeric,
                                              readOnly:false
                                            },
                                         	  
                                	      {
                                	    	  data:'baselineDLPDate',
                                	    	  type: 'date',
                                	    	  dateFormat: 'MM/DD/YYYY',
                              	          correctFormat: true,
                              	        /* defaultDate: '06/29/2016',*/
                              	          allowEmpty: true,
                              	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                              	          datePickerConfig: {
                              	          // First day of the week (0: Sunday, 1: Monday, etc)
                              	          firstDay: 0,
                              	          showWeekNumber: true,
                              	          numberOfMonths: 1,
                              	          
                              	        },
                              	      renderer:safeHtmlDateRenderereditable,
                              	      readOnly:false
                                	    	},
                                	    {
                                	      data:'adminFee',
                                	     renderer:safeHtmlRenderereditableNumeric,
                                	      //type: 'numeric',
                                	     // format: '$0,0.00',
                                	     //allowInvalid: true,
                                	      
                                 	    	 readOnly:false
                                	    	},
                                	    	{
                                	    		  data:'effectiveDate',
                                	    	  type: 'date',
                                	    	  dateFormat: 'MM/DD/YYYY',
                                  	          correctFormat: true,
                                  	        /* defaultDate: '06/29/2016',*/
                              	          allowEmpty: false,
                              	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                              	          datePickerConfig: {
                              	          // First day of the week (0: Sunday, 1: Monday, etc)
                              	          firstDay: 0,
                              	          showWeekNumber: true,
                              	          numberOfMonths: 1,
                              	          
                              	        },
                              	      renderer:safeHtmlDateRenderereditable,
                              	      readOnly:false
                                	    	},
                                	    	
                                	    	{
                                	    		 data:'endDate',
                                	    	  type: 'date',
                                	    	  dateFormat: 'MM/DD/YYYY',
                                  	          correctFormat: true,
                                  	        /* defaultDate: '06/29/2016',*/
                              	          allowEmpty: false,
                              	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                              	          datePickerConfig: {
                              	          // First day of the week (0: Sunday, 1: Monday, etc)
                              	          firstDay: 0,
                              	          showWeekNumber: true,
                              	          numberOfMonths: 1,
                              	          
                              	        },
                              	      renderer:safeHtmlDateRenderereditable,
                              	      readOnly:false
                                	    	
                                	    	},
                                	    {
                                	    		data:'comments',
                                	    		renderer:safeHtmlRenderereditable,
                                	    		readOnly:false
                                	    },
                                	    {
                                	    	data:'fileExtension',
                                	    readOnly:true,
                                	    renderer:customRenderer
                                	    },
                                	    {
                                	    	data:'approve',
                                	    readOnly:true,
                                	    renderer:customDeleteRenderer
                                	    }
                               	      ] ,
                               	  
                               	        afterGetColHeader: function(col, TH) {
                    	    var TR = TH.parentNode;
                    	    var THEAD = TR.parentNode;
                    	    var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                    	    function applyClass(elem, className) {
                    	      if (!Handsontable.Dom.hasClass(elem, className)) {
                    	        Handsontable.Dom.addClass(elem, className);
                    	      }
                    	    }

                    	    // first level from the top
                    	    if (headerLevel === -2 && (col===0||col===1||col===2||col===3||col===4 ||col===5||col===6)) {
                      	      applyClass(TH, 'color2');

                      	    // second level from the top
                      	    }else if (headerLevel === -2 && (col>6 && col<18)) {
                        	      applyClass(TH, 'contractfieldinputcolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -1) {
                      	    	applyClass(TH, 'color1');
                       	       
                    	      }
                  	     
                       }
                  	      
        	
        	  }
    		
    		 network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
    		
    	var numberValidator = function (value, callback) {
    		setTimeout(function(){
    		    if (!$.isNumeric(value)) {
    		      callback(false);
    		    }
    		    else {
    		      callback(true);
    		    }
    		  }, 1000);
    		};
    		
    		function getIsLockedContract(data1)
    		{
    		
    		jQuery.ajax({
    	 		type:"get",
    	 		dataType:"json",
    	 		url:urlPrefix+"/JanssenSCG/lockStatusContract",
    	 		data:{data:data1},
    	 		async:false,
    	 		success: function(responseText) { 
    			    Response= responseText;
    		},
    		complete: function(){
    			data = Response;
    		 }
    		 });
    		 
    		 return data;
    		}
    		
    		
}
        	  
function viewfile(filename){
	//alert("view attachment"+filename);
	flag=true;
	 var form = $('<form></form>').attr('action', "/JanssenSCG/viewAttachement").attr('method', 'post');
	    // Add the one key/value
	    form.append($("<input></input>").attr('type', 'hidden').attr('name', 'filename').attr('value', filename));
	    //send request
	    form.appendTo('body').submit().remove();
	    
	/*jQuery.ajax({
 		type:"post",
 		dataType:"json",
 		url:urlPrefix+"/JanssenSCG/viewAttachement",
 		data:{data:filename},
 		async:false,
 		success: function(responseText) { 
 			alert(success);
		    //Response= responseText;
	},
	complete: function(){
		//data = Response;
	 }
	 });*/
}

function customDropdownRenderer(instance, td, row, col, prop, value, cellProperties) {
    var selectedId;
    var optionsList = cellProperties.chosenOptions.data;
    $(td).css({"background-color":'#e0e2e5'});
    var values = (value + "").split(",");
    var value = [];
    for (var index = 0; index < optionsList.length; index++) {
        if (values.indexOf(optionsList[index].id + "") > -1) {
            selectedId = optionsList[index].id;
            value.push(optionsList[index].label);
        }
    }
    value = value.join(", ");
    var workaround = "<div class='work'>"+value+"</div>";
       $(td).html(workaround);
    Handsontable.TextCell.renderer.apply(this, arguments);
} 

function safeHtmlRenderereditableNumeric(instance, td, row, col, prop, value, cellProperties) {
	   if($.isNumeric(value)){
		$(td).css({"background-color":'#e0e2e5'});
		   var value1=value;   
      	   var percentage="%";
      	   value=value+percentage;
    	   var workaround = "<div>"+value1+percentage+"</div>";
     	  $(td).html(workaround);     		       
	   }
	   else{
		   //$(td).css({"background-color":'#FF0000'});
		   $(td).css({"background-color":'#e0e2e5'});
		   $(td).html(value);
	   }
	   Handsontable.TextCell.renderer.apply(this, arguments);
	   return td;  
	  } 
function safeHtmlRenderereditable(instance, td, row, col, prop, value, cellProperties) {
	   $(td).css({"background-color":'#e0e2e5'});
	   
       if(!value ){
       value="";
       }
        var workaround = "<div class='work'>"+value+"</div>";
         $(td).html(workaround);
        /*  $(td).css({"overflow-y":'auto'});
         $(td).css({"overflow-x":'auto'}); */
         Handsontable.TextCell.renderer.apply(this, arguments);
         return td;
	  }

function customRenderer(instance, td, row, col, prop, value, cellProperties) {
	
	   var value1;
	//alert(value);
	   var rowdata=instance.getSourceDataAtRow(row);
	 
	    	 var uniqueId='"'+rowdata.id+'"';
	    	//alert("Row::"+uniqueId);
		    	  if(value == null ){
	               value1="";
	                var workaround = "<div>"+value1+"</div>";
	                 $(td).html(workaround);
	                }else{
	                 //alert("else");
	                var workaround = "<input type='button' style='margin-top:20px' value='View Attachment' id='file_viewer"+rowdata.uniqueIdentifier+"' onclick='viewfile("+uniqueId+");'/>";
	               // $(td).css({"margin-top":'20px'});
	                 $(td).html(workaround);
	                
	                }
        
       return td;
	  }
function customDeleteRenderer(instance, td, row, col, prop, value, cellProperties) {	
	   var value1;
	   var workaround;
	   var rowdata=instance.getSourceDataAtRow(row); 
	    	 var uniqueId=rowdata.id;
	    	 if(rowdata.approve || !empty(rowdata.trimNo)){
	            workaround = "<div><button type='button' class='btn btn-primary' style='margin-top:5px'  id='approve"+rowdata.id+"' disabled onclick='updateRow("+uniqueId+");'>Approve</button><br><button type='button' class='btn btn-warning' disabled style='margin-top:4px;margin-bottom:2px' id='reject"+rowdata.id+"' onclick='updateRow("+uniqueId+");'>Reject</button> </div> "
	    	 }else{
	    		 workaround = "<div><button type='button' class='btn btn-primary' style='margin-top:5px' id='approve"+rowdata.id+"' onclick='updateRow("+uniqueId+",true);'>Approve</button><br><button type='button' class='btn btn-warning' style='margin-top:4px;margin-bottom:2px' id='reject"+rowdata.id+"' onclick='updateRow("+uniqueId+",false);'>Reject</button> </div> "
	    	 }
	               // $(td).css({"margin-top":'20px'});
	                 $(td).html(workaround);
	                 //$(td).html(workaround1);
	           
    return td;
	  }

function updateRow(uniqueId,flag){
	
	var Response;
	var data=handsonComm.getSourceData();
	var row = $.grep(data, function(obj){return obj.id === uniqueId;})[0];
	//alert(row.comments);
	console.log(row);
	row.approve=flag;
	row.fileContent = null;
	row.fileExtension = null;
	var finalData=new Array();
	finalData.push(row);
	//var obj={};
	//obj.id =uniqueId;
	//obj.approve =flag;
	//var finalDataModified=[];
	//finalDataModified.push(obj);
	
	
	
	var arr=JSON.stringify(finalData);
	console.log("Array is : ");
	console.log(arr);
	var arr1=JSON.stringify(finalData);
	console.log("Array1 is : ");
	console.log(arr1);
	var text;
	var title;
	var type;
	var text1;
	if(row.approve){
		text="Are you sure you want to Approve?";
		title="Sucessfully saved and Approved.";
		text1="Sucessfully saved changes and Approved.";
		
		 swal({
		        title: "Are you sure ?",
		        text:text,
		       // html: true,
		        type:'warning',
		        showCancelButton: true,
		        confirmButtonColor: "#DD6B55",
		        confirmButtonText: "Yes",
		        cancelButtonText: "No",
		        closeOnConfirm: false,
		        closeOnCancel: true
				},
				
			    function(isConfirm) {
					var text="";
					
			        if (isConfirm) {
			        	
			        	$("#CommGrid").css('visibility', 'hidden');
	                    
	                    $("#loadingmsg").css('visibility', 'visible');  
	                   
	                   
	                    
	        			
			        	jQuery.ajax({
	                        type:"POST",
	                        dataType:"json",
	                        url:urlPrefix+"/JanssenSCG/updateContract",                    
	                        data:{jsonFull1: arr,approvalComments:text},
	                        async:false,
	                        success: function(response) { 
	                        	//alert("ajax response contractadd"+response);
	 	                         Response= response.saveSuccess;
	 	                        
	 	                         var alertText;
	 	                         var type;
	 	                       if(Response=='saveSuccess'){ 
	 	                       	title=title;
	 	                       	type="success";
	 	                       alertText=text1;
	 	                       }else{
	 	                      	 title="Oops! Data Not saved";
	 	                      	alertText="Oops!Data not saved";
	 	                      	type="error";
	 	                      	alertText=alertText+response.validationMessage;
	 	                       } 
	 	                       //alert("hi");
	 	                         swal({
							        title: title,
							        text: alertText,
							        type: type,
							        showCancelButton: false,
							        confirmButtonColor: "#DD6B55",
							        confirmButtonText: "OK",
							        cancelButtonText: "No",
							        closeOnConfirm: true,
							        closeOnCancel: true
				    				}, function(isConfirm) {
				    				
				    				if(isConfirm){
				    					$("#CommGrid").css('visibility', 'visible');
				                        
				                        $("#loadingmsg").css('visibility', 'hidden'); 
				    				 handsonComm.updateOptions({
		                        	 			data:getData()
		                        	 	});
		                        	 	var data=handsonComm.getSourceData();
					
						    			//alert(network.countRows());
						    			for (var i = 0; i < network.countRows(); i++) {
						    			//for (var i = 0; i < rowcount; i++) {
						    				var row=data[i];
						    				var approved=row.approve;
						    				//alert("Approved"+approved);
						    				if(approved){
							    		        for (var j = 0; j < network.countCols(); j++) {
							    		        
							    		            network.setCellMeta(i, j, "className", "readonlystyle");
							    		        	network.setCellMeta(i, j, "readOnly", true);
							    		        	
							    		        }
						    			   }
						    			}
			 
		                        	 	handsonComm.render();
				    				}
				    				});
		                        	 	
	 					},
	 	              complete: function(){
	 	            	    $("#savediv").show();
	                       $("#confirmdiv").show();
	                       $("#loadingmsg").css('visibility', 'hidden'); 	                       
	                       $("#CommGrid").css('visibility', 'visible');
	                       
	 	              }
	 	              });
			        	
			        }else{
			        	handsonComm.updateOptions({
	             			 data:getData()
	             			});
	             			var data=handsonComm.getSourceData();
	   				
							    			//alert(network.countRows());
							    			for (var i = 0; i < network.countRows(); i++) {
							    			//for (var i = 0; i < rowcount; i++) {
							    				var row=data[i];
							    				var approved=row.approve;
							    				//alert("Approved"+approved);
							    				if(approved){
								    		        for (var j = 0; j < network.countCols(); j++) {
								    		        
								    		            network.setCellMeta(i, j, "className", "readonlystyle");
								    		        	network.setCellMeta(i, j, "readOnly", true);
								    		        	
								    		        }
							    			   }
							    			}
	              		 handsonComm.render();
			        }
				
			      }
		//}   	
	           	
	       	);
		
	}else{
		text:
		title="Rejected";
		text1="Sucessfully saved changes and Rejected.";
	
	
	
	 swal({
	        title: "Please Add Commentary To Support The Rejection",
	        text:"<textarea class='form-control' rows='5' placeholder='Comment...' id='text'></textarea>",
	        html: true,
	        type:'warning',
	        showCancelButton: true,
	        confirmButtonColor: "#DD6B55",
	        confirmButtonText: "Yes",
	        cancelButtonText: "No",
	        closeOnConfirm: false,
	        closeOnCancel: true
			},
			
		    function(isConfirm) {
				text=$("#text").val();
				
		        if (isConfirm) {
		        	
		        	$("#CommGrid").css('visibility', 'hidden');
                    
                    $("#loadingmsg").css('visibility', 'visible');  
                   
                   
                    
        			
		        	jQuery.ajax({
                        type:"POST",
                        dataType:"json",
                        url:urlPrefix+"/JanssenSCG/updateContract",                    
                        data:{jsonFull1: arr,approvalComments:text},
                        async:false,
                        success: function(response) { 
                        	//alert("ajax response contractadd"+response);
 	                         Response= response.saveSuccess;
 	                        
 	                         var alertText;
 	                         var type;
 	                       if(Response=='saveSuccess'){ 
 	                       	title=title;
 	                       	type="success";
 	                       alertText=text1;
 	                       }else{
 	                      	 title="Oops! Data Not saved";
 	                      	alertText="Oops!Data not saved";
 	                      	type="error";
 	                      	alertText=alertText+response.validationMessage;
 	                       } 
 	                       //alert("hi");
 	                         swal({
						        title: title,
						        text: alertText,
						        type: type,
						        showCancelButton: false,
						        confirmButtonColor: "#DD6B55",
						        confirmButtonText: "OK",
						        cancelButtonText: "No",
						        closeOnConfirm: true,
						        closeOnCancel: true
			    				}, function(isConfirm) {
			    				
			    				if(isConfirm){
			    					$("#CommGrid").css('visibility', 'visible');
			                        
			                        $("#loadingmsg").css('visibility', 'hidden'); 
			    				 handsonComm.updateOptions({
	                        	 			data:getData()
	                        	 	});
	                        	 	var data=handsonComm.getSourceData();
				
					    			//alert(network.countRows());
					    			for (var i = 0; i < network.countRows(); i++) {
					    			//for (var i = 0; i < rowcount; i++) {
					    				var row=data[i];
					    				var approved=row.approve;
					    				//alert("Approved"+approved);
					    				if(approved){
						    		        for (var j = 0; j < network.countCols(); j++) {
						    		        
						    		            network.setCellMeta(i, j, "className", "readonlystyle");
						    		        	network.setCellMeta(i, j, "readOnly", true);
						    		        	
						    		        }
					    			   }
					    			}
		 
	                        	 	handsonComm.render();
			    				}
			    				});
	                        	 	
 					},
 	              complete: function(){
 	            	    $("#savediv").show();
                       $("#confirmdiv").show();
                       $("#loadingmsg").css('visibility', 'hidden'); 	                       
                       $("#CommGrid").css('visibility', 'visible');
                       
 	              }
 	              });
		        	
		        }else{
		        	handsonComm.updateOptions({
             			 data:getData()
             			});
             			var data=handsonComm.getSourceData();
   				
						    			//alert(network.countRows());
						    			for (var i = 0; i < network.countRows(); i++) {
						    			//for (var i = 0; i < rowcount; i++) {
						    				var row=data[i];
						    				var approved=row.approve;
						    				//alert("Approved"+approved);
						    				if(approved){
							    		        for (var j = 0; j < network.countCols(); j++) {
							    		        
							    		            network.setCellMeta(i, j, "className", "readonlystyle");
							    		        	network.setCellMeta(i, j, "readOnly", true);
							    		        	
							    		        }
						    			   }
						    			}
              		 handsonComm.render();
		        }
			
		      }
	//}   	
           	
       	);
	}
}