$(document).ready(function()
{ 
	
	

$(".form-style-1").hide();





// ************************************************************

var new_dialog = 	function (type, row) {
                
	var dlg = $(".form-style-1").clone();
	var config;
	 customer=$("#businessPicker").val();	 
     product=$("#productPicker").val();    
     channel=$("#channelPicker").val();
     $('#uniqueIdentifier').val(" ");
	 var options = '<option value="' + customer + '">'+customer+'</option>';
	 $('#businessPicker option').clone().appendTo(dlg.find("#customer1"));
	 dlg.find("#customer1").val(customer);
	 //dlg.find("#customer1").html(options);
	 //dlg.find("#customer1").attr("disabled", true); 
	 	//dlg.find("#customer1").attr("disabled", true); 
	 /* options = '<option value="'+product+'">'+product+'</option>';
	 dlg.find("#product1").html(options);
	 dlg.find("#product1").val(product);
 	dlg.find("#product1").attr("disabled", true);*/
 	 $('#productPicker option').clone().appendTo(dlg.find("#product1"));
 	 dlg.find("#product1").val(product);
 	//options = '<option value="'+channel+'">'+channel+'</option>';
 	// dlg.find("#channel1").html(options);
 	 $('#channelPicker option').clone().appendTo(dlg.find("#channel1"));
	// dlg.find("#customer1").val(customer);
 	 dlg.find("#channel1").val(channel);
  	//dlg.find("#channel1").attr("disabled", true); 
                //alert("new dialog");
                
                type = type || 'Create';
                 config = {
                    autoOpen: true,
                    width: 695,
                    height: 650,
                    modal: true,
                   // position: { my: "center", at: "center", of: window },
                    buttons: {
                        'Save': save_data,
                        'Reset': function () {
                        	dlg.find("#customertype1").val("");
                        	dlg.find("#document1").val("");
                            dlg.find("#bookofbusiness1").val("");
                           
                            dlg.find("#medicalpharmacy1").val("");
                            dlg.find("#epudesc1").val("");
                            dlg.find("#utilizationmanagement1").val("");
                            dlg.find("#strategyName").val("");
                            dlg.find("#rebate").val("");
                            dlg.find("#performanceRebate").val("");
                            dlg.find("#baselineDate").val("");
                            dlg.find("#adminFee").val("");
                            dlg.find("#irceiling").val("");
                            dlg.find("#startdate").val("");
                            dlg.find("#enddate").val("");
                            dlg.find("#comments").val("");
                               
                        }
						
                    },
                    close: function () {
                        dlg.remove();
                    }
                };
               
                dlg.dialog(config); 
                
                
                function save_data(){
                	//alert("hi");
                	
                	
                	  var customer1=dlg.find("#customer1").val();
                	//alert(customer1);
                       var product1=dlg.find("#product1").val();
                      
                       var channel1=dlg.find("#channel1").val();
                       if(empty(customer1) || empty(product1) || empty(channel1)){
                    	 alert("Please select account,product or channel");
                    	 return false;
                       }
                       
                       var document=dlg.find("#document1").val();                   
                       var customertype1=dlg.find("#customertype1").val();
                     
                       var bokofbusiness=dlg.find("#bookofbusiness1").val();
                       var bokofbusinesses=bokofbusiness.toString().split(",");
                       //alert("book of business"+bokofbusiness);
                       var medicalpharmacy=dlg.find("#medicalpharmacy1").val();
                       //alert("medicalpharmacy"+medicalpharmacy);
                       var effectivedate=dlg.find("#effectivedate").val();
                       //alert("effectivedate"+effectivedate);
                       var enddate=dlg.find("#enddate").val();
                       //alert("enddate"+enddate);
                       var contractdeliverydate=dlg.find("#contractdeliverydate").val();
                       //alert("contractdeliverydate"+contractdeliverydate);
                       var executiondate=dlg.find("#executiondate").val();
                       //alert("executiondate"+executiondate);
                       var lostdate=dlg.find("#lostdate").val();
                       
                      // var daterequestsentops=dlg.find("#daterequestsentops").val();
                       var trimnumber=dlg.find("#trimnumber").val();
                       var comments=dlg.find("#comments").val();
                      // alert(comments);
                       var filecontract = dlg.find("#filecontract").get(0).files[0];
                       var validateSuccess=validatefilesize(filecontract,dlg);
                       
                       //alert(filecontract);
                       var formData = new FormData();
                      formData.append('filecontract', filecontract);
                       //alert();
                       var urlPrefix = window.location.protocol+'//'+window.location.hostname+(window.location.port ? ':'+window.location.port: '');
                       var dataArray=new Array();
                       for(var i=0;i<bokofbusinesses.length;i++){
                    	   var data={'accountLead': accountLead, 'accountName':customer1, 'channel':channel1, 'product':product1,'documentType':document, 'customerType':customertype1,'bookOfBusiness':bokofbusiness[i].toString(),'medicalPharmacy':medicalpharmacy,'effectiveDate':effectivedate,'endDate':enddate,'contractDeliverydate':contractdeliverydate,'executionDate':executiondate,/*'dateRequestSent':daterequestsentops,*/'requestorType':'OD','lostDate':lostdate,'trimNo':trimnumber,'comments':comments};
                    	   dataArray.push(data);
                       }
                       var jsonData = JSON.stringify(dataArray);
                       //alert(jsonData);
	                       if(validateSuccess){
	                    	  
	                    	   $("#CommGrid").css('visibility', 'hidden');
	                           //alert("hi1");
	                            //$("#savediv").style.visibility = "hidden";
	                            $("#savediv").hide();
	                            // alert("hi2");
	                           // document.getElementById("confirmdiv").style.visibility = "hidden";
	                            
	                             //alert("hi4");
	                            $("#loadingmsg").css('visibility', 'hidden');
	                       formData.append('content', jsonData);
	                       jQuery.ajax({
	  	                     type:"post",
	  	                     dataType:"json",
	  	                   
	  	                     url:urlPrefix+"/JanssenSCG/contractadd",
	  	                     data:formData,
	  	                     async:true,
	  	                   processData: false,
	  	                   contentType: false,
	  	                     success: function(response) { 
	  	                    	// alert("ajax response contractadd"+response.saveSuccessMsg);
	  	                    	 Response= response.saveSuccess;
	  	                    	 var identifier=response.identifier;
	  	                         var title;
	  	                         var alertText;
	  	                         var type;
	  	                       if(Response=='saveSuccess'){ 
	  	                       	title="Sucessfully saved";
	  	                       	text="Successfully saved changes.Do you want to Raise another Document?"
	  	                       	type="success";
	  	                       }else{
	  	                    	title="Oops! Data Not saved";
	  	                    	text=response.validationMessage+".Do you want to Raise again?";
	  	                      	type="warning";
	  	                       } 
	  	                     $('#productPicker').val(product1);
	  	                       $('#businessPicker').val(customer1);
	  	                       $('#channelPicker').val(channel1);
	  	                         swal({
							        title: title,
							        text: text,
							        type: type,
							        showCancelButton: true,
							        confirmButtonColor: "#DD6B55",
							        confirmButtonText: "YES",
							        cancelButtonText: "NO",
							        closeOnConfirm: true,
							        closeOnCancel: true,
				    				}, function(isConfirm) {
				    				
				    				if(isConfirm){
				    					new_dialog();
				    					 
				    				}
				    				});
	  	                      
			    				 handsonComm.updateOptions({		    					
	                        	 			data:getDataByIdentifier(identifier)
	                        	 	});
	                        	 	handsonComm.render();
	  					},
	  	              complete: function(){
	  	            	 $("#CommGrid").css('visibility', 'visible');
	                       
	                        $("#savediv").show();
	                        $("#confirmdiv").show();
	                        
	                        $("#loadingmsg").css('visibility', 'hidden');  
	  	              }
	  	              });
	                       dlg.dialog("close");    
		                       $("#CommGrid").css('visibility', 'hidden');
		                       
		                        $("#savediv").hide();
		                        $("#confirmdiv").hide();
		                        
		                        $("#loadingmsg").css('visibility', 'visible');                        
	                }
                }
                   
             
          };
          var customer;
          var product;
          var channel;
          var accountLead;  
            $("#newoffer").click(function(){
            	//accountLead=$("#selection").val();
            	
            	
            	 
                   
                  /* if( empty(customer) || empty(product)|| empty(channel)){
                	   alert("Please select account,product,channel to raise new document");
                   }else{*/
                	   /*alert("hi");
                	   alert("new offer"+accountLead);
                	   alert("new offer"+customer);
                	   alert("new offer"+product);
                	   alert("new offer"+channel);*/
                	   new_dialog();
               //    }
            });
            
            function empty(str)
      	  {
      	      if (typeof str == 'undefined' || !str || str.length === 0 || str === '' || !/[^\s]/.test(str) || /^\s*$/.test(str))
      	      {
      	          return true;
      	      }
      	      else
      	      {
      	          return false;
      	      }
      	  }
            
            function checkfiletype(ext) {
            	var supportedfiletype=['xls', 'xlsx', 'doc','docx' , 'ppt', 'pptx', 'zip', 'pdf', 'jpg', 'jpeg','msg'];
            	if(supportedfiletype.includes(ext)){
            		return true;
            	}
               return false;
            };      
            function validatefilesize(file,dlg)
            	{
            	//alert("file validation"+file.name);
            	var success=true;
            	  var startdate=dlg.find("#effectivedate").val();
                  var enddate=dlg.find("#enddate").val();
                  //alert("start date"+startdate+"End date"+enddate);
                //  var daterequestsentops=dlg.find("#daterequestsentops").val();
                  var trimnumber=dlg.find("#trimnumber").val();
                  var bokofbusiness=dlg.find("#bookofbusiness1").val();
                  var medicalpharmacy=dlg.find("#medicalpharmacy1").val();
                  var document=dlg.find("#document1").val();                   
                  var customertype1=dlg.find("#customertype1").val();
                  //alert(customertype1);
                  if(empty(startdate) || empty(enddate)){
                	  dlg.find("#mandatorystartenddate").show(); 
                	  success=false;
                  }else if(empty(bokofbusiness) || empty(document) || empty(customertype1)|| empty(medicalpharmacy) ){
                	  dlg.find("#mandatorystartenddatedifference").hide();
                	  dlg.find("#mandatoryfield").show(); 
                	  success=false;
                  }else if(enddate<startdate){
                	  dlg.find("#mandatorystartenddate").hide();
                	  dlg.find("#mandatorystartenddatedifference").show(); 
                	  success=false;
                  }
                 /* if(!empty(trimnumber)){
                	  if(empty(daterequestsentops)){
                		  dlg.find("#mandatorydateRequestSent").show();
                		  success=false;
                	  }
                  }*/
            	if(file!=null){
	            	var ext=(file.name).split('.')[1];
	            	if(!checkfiletype(ext)) {
	            	
	            	 dlg.find("#mandatoryfieldMsgType").show(); 
	            	 success=false;
	            	}
	            	if(file.size > 5*1024*1024)
	               	{
	               //  $(this).val('');
	                 dlg.find("#mandatoryfieldMsgSize").show(); 
	                 success=false;
	               	}
	            	
            	}
            	return success;
            	
             } 
 
});



