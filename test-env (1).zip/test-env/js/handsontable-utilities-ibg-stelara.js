
function Handson(containerid){
	
         var container = document.getElementById(containerid);
        var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
         var data;
         console.log("filter"+filter);
         
    		var options = {
    			data:[],
        	    colWidths: [75,75,75, 150,100, 150, 200, 200,200,200,200],
        	  //  rowHeights:20,
        	    comments: true,
        	    search:true,
        	    columnSorting: true,
        	    sortIndicator: true,
        	    manualColumnResize: true,
        	    manualRowResize: true, 
        	    preventOverflow: 'horizontal',
        	 //   filters:true,
        	    colHeaders:true,
        	    contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        } }
                },
        	    contextMenuCopyPaste: {
        	        swfPath: 'js/ZeroClipboard.swf'
        	      },
        	    fixedColumnsLeft: 3,
        	    manualColumnFreeze:true,
        	  //  dropdownMenu: true,
        	  //  filters:true,
        	    nestedHeaders: [
        	                    [{label: ' ', colspan:3}, {label: 'Stelara CD IBG Launch Insights', colspan:8}],
       	                     ['Field Director','Business Name', 'IBG Tier','Is a system level formulary decision applicable to Stelara CD for your account?','When do you expect a formulary decision to be made on Stelara CD?','If the formulary decision has already been made, please let us know the result','As it relates to your health system account, is there anything that will prevent a patient prescribed Stelara CD from accessing their initial infusion dose?','If you answered Yes to the Access issues question, please select what the issue(s)/barrier(s) is(are) from the menu below','Please describe the action plan in place to resolve the issues preventing a patient from accessing the Stelara CD product within your system','Please describe what resources/partnerships you need that you don�t currently have access to that would enable you to deliver on the action plan and resolve the issues preventing a patient from accessing Stelara CD within your system','Please provide any additional context here as it relates to ensuring access within your system to Stelara CD']],
       	         columns: [
                      	    	{
                              	      data:'ibgId.fieldDirectorId',
                              	      readOnly:true
                              	  },                                 	    
                           	      {
                              	      data:'ibgId.businessNameId',
                              	      readOnly:true
                              	   },
                              	   {
                              	      data:'ibgId.ibgTierId',
                              	      readOnly:true
                              	   },
                              	   {
                          	    	  data:'levelformularydecision',
                          	    	renderer:safeHtmlRenderer,
                          	    	editor: 'select',
                                    selectOptions: ["Yes","No, Stelara CD will not need to be added to my system's formulary to enable access to the product","No, my system's formulary decisions are made in a decentralized way, i.e. at a local facility level"]
                          	    	 
                            	   },
                            	   {
                         	    	  data:'exceptformularydecision',
                         	    	 type: 'date',
                        	          dateFormat: 'MM/YYYY',
                        	          correctFormat: true,
                        	          defaultDate: '2016-06-29',
                        	          allowEmpty: false,
                        	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                        	          datePickerConfig: {
                        	          // First day of the week (0: Sunday, 1: Monday, etc)
                        	          firstDay: 0,
                        	          showWeekNumber: true,
                        	          numberOfMonths: 1,
                        	         
                        	          }
                             	    	 
                           	      },
                           	      {
                         	    	  data:'formularydecisionresult',
                         	    	  renderer:safeHtmlRenderer,
                        	    	  allowInvalid: false,
                                      editor: 'select',
                                      selectOptions: ['Added with no restrictions', 'Added with restrictions', 'Not added']
                         	    	 
                           	      },
                           	      {
                         	    	  data:'prescribedStelaraCD',
                         	    	  renderer:safeHtmlRenderer,
                        	    	  editor: 'select',
                                      selectOptions: ["Yes, there are issues in my account that are disrupting patient access to Stelara CD","No, patients prescribed Stelara CD that are flowing through my system are not currently experiencing any disruptions in access"]
                         	    	 
                           	      },
                         	      {
                         	    	  data:'issuesbarriers',
                         	    	  renderer:safeHtmlRenderer,
                        	    	  allowInvalid: false,
                                      editor: 'select',
                                      selectOptions: ["Hospital formulary", "Payer", "Distribution/Trade", "Other (Free Text comment box included so DSA's can describe the issue)"]
                         	    	 
                           	      },
                        	      {
                         	    	 data:'actionplan' ,
                         	    	 renderer:safeHtmlRenderer,
                         	    	 allowInvalid: false,
                                      validator: limit_validator_regexp
                        	    	
                        	      },
                        	      {
                          	    	 data:'resourcepartnership' ,
                          	    	 renderer:safeHtmlRenderer,
                          	    	 allowInvalid: false,
                                       validator: limit_validator_regexp
                         	    	
                         	      },
                        	      {
                          	    	 data:'additionalcontext' ,
                          	    	 renderer:safeHtmlRenderer,
                          	    	 allowInvalid: false,
                                       validator: limit_validator_regexp
                         	    	
                         	      }
                               	      ] ,
                               	      
                               	        afterGetColHeader: function(col, TH) {
                    	    var TR = TH.parentNode;
                    	    var THEAD = TR.parentNode;
                    	    var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                    	    function applyClass(elem, className) {
                    	      if (!Handsontable.Dom.hasClass(elem, className)) {
                    	        Handsontable.Dom.addClass(elem, className);
                    	      }
                    	    }

                    	    // first level from the top
                    	    if (headerLevel === -2 && (col===0||col===1||col===2)) {
                      	      applyClass(TH, 'color2');

                      	    // second level from the top
                      	    }else if (headerLevel === -2 && (col===3||col===4||col===5||col===6||col===7||col===8||col===9||col===10)) {
                        	      applyClass(TH, 'bluecolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -1) {
                      	    	applyClass(TH, 'color1');
                       	       
                    	      }
                  	     
                       }
                  	      
        	
        	  }
    		
    		var network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
    	
      
    		
}
        	  