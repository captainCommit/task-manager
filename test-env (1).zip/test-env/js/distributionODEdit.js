 $(document).ready(function(){
$('#requestorApproval').change(function(){
							if ($("#requestorApproval").val()=='Yes')
								{
							/*	$('#Approvaldropdown').append('<option selected>Select Option</option>');*/
								$('#Approvaldropdown').append('<option value="Budget" class="approve">Budget</option>');
								$('#Approvaldropdown').append('<option class="approve" value="Bus. Partner Risk Assesment">Bus. Partner Risk Assesment</option>');
								$('#Approvaldropdown').append('<option class="approve" value="Contract and Pricing Committee">Contract and Pricing Committee</option>');
								$('#Approvaldropdown').append(' <option class="approve" value="Pharmacovigilance">Pharmacovigilance</option>');
								$('#Approvaldropdown').append('<option class="approve" value="Privacy">Privacy</option>');
								$('#Approvaldropdown').append('<option class="approve" value="Regulatory">Regulatory</option>');
								$('#Approvaldropdown').append('<option class="approve" value="Other">Other</option>');
								$(".selectpicker").selectpicker('refresh');
								}
							else
							{
								$('#Approvaldropdown').empty();
								/*$('#otherApproval').val(" ");*/
								$("#otherApproval")
								.prop(
										"readonly",
										true);
								 $(".selectpicker").selectpicker('refresh');
								}
						  });	
 });	

					var urlPrefix = window.location.protocol
							+ '//'
							+ window.location.hostname
							+ (window.location.port ? ':'
									+ window.location.port : '');
					var Response;
					function UniqueRow(uniqueId){

										var uniqueIdentifier = uniqueId;
										 $(".selectpicker").selectpicker('refresh');

										document.getElementById("UniqueId").defaultValue = uniqueIdentifier;
										if (empty(uniqueIdentifier)) {

											alert("Please enter the Unique Identifier");

										} else {

											jQuery
													.ajax({
														type : "get",
														dataType : "json",
														url : urlPrefix
																+ "/JanssenSCG/getDistributionContractById",
														data : {
															user : userID,
															uniqueIdentifier : uniqueIdentifier
														},
														async : false,
														cache : false,
														success : function(
																responseText) {

															Response = responseText;
															console
																	.log(Response);
															
															if (empty(Response)) {
																swal({
																	title : "No Contract Found!",
																	text : "Data not found.",
																	type : "warning",
																	showCancelButton : false,
																	confirmButtonColor : "#DD6B55",
																	confirmButtonText : "OK",
																	cancelButtonText : "No",
																	closeOnConfirm : true,
																	closeOnCancel : true
																});

															} 
															 
															else if((userTypeAccess!="REQUESTOR")||(Response[0].Userid==userID)) {
															
																
																document.getElementById("pr_no").defaultValue = empty(Response[0].otherPurchaseNum) ? ""
																		: Response[0].otherPurchaseNum;
																document
																		.getElementById("CompletionDate").defaultDate = empty(Response[0].CompletionDate) ? ""
																		: Response[0].CompletionDate;
																document
																		.getElementById("OtherChannel").defaultValue = empty(Response[0].otherChannel) ? ""
																		: Response[0].otherChannel;
																document
																		.getElementById("Description").defaultValue = empty(Response[0].Description) ? ""
																		: Response[0].Description;
															
																
																
																
																
																document
																		.getElementById("OtherRequestor").defaultValue = empty(Response[0].otherRequestType) ? ""
																		: Response[0].otherRequestType;
																document
																		.getElementById("OtherContractingparty").defaultValue = empty(Response[0].otherContractingParty) ? ""
																		: Response[0].otherContractingParty;
																document
																		.getElementById("OtherDocumentType").defaultValue = empty(Response[0].otherDocumentType) ? ""
																		: Response[0].otherDocumentType;
																document.getElementById("EmpICD").defaultValue = empty(Response[0].EmpICD) ? ""
																		: Response[0].EmpICD;
																// document.getElementById("ProductNDC").defaultValue=empty(Response[0].ProductNumb)?"":Response[0].ProductNumb;

																document
																		.getElementById("OtherTotality").defaultValue = empty(Response[0].otherTotalityNum) ? ""
																		: Response[0].otherTotalityNum;
																
																document
																.getElementById("otherApproval").defaultValue = empty(Response[0].otherApproval
																) ? ""
																: Response[0].otherApproval;

																document
																		.getElementById("requestorName").defaultValue = empty(Response[0].RequestorName) ? ""
																		: Response[0].RequestorName;
																

																
																document
																		.getElementById("RequestorEmail").defaultValue = empty(Response[0].RequestorMail) ? ""
																		: Response[0].RequestorMail;

																document
																		.getElementById("StakeholderName").defaultValue = empty(Response[0].StakeholderName
																		) ? ""
																		: (Response[0].StakeholderName
																		);
																
																document
																.getElementById("StakeholderEmail").defaultValue = empty(Response[0].StakeholderMail
																) ? ""
																: Response[0].StakeholderMail
																		;
																											document
																		.getElementById("InternalSignatoryName").defaultValue = empty(Response[0].ISignatoryName
																		) ? ""
																		: Response[0].ISignatoryName
																				;
																document
															.getElementById("InternalSignatoryTitle").defaultValue = empty(Response[0].ISignatoryTitle
																				) ? ""
										                    : Response[0].ISignatoryTitle
																										;												
																											
																											
																document
																		.getElementById("InternalSignatoryEmail").defaultValue = empty(Response[0].ISignatoryMail
																		) ? ""
																		: Response[0].ISignatoryMail
																				;
																document
																		.getElementById("ExternalSignatoryName").defaultValue = empty(Response[0].ExSignatoryName
																		) ? ""
																		: Response[0].ExSignatoryName
																				;
																document
																		.getElementById("ExternalSignatoryEmail").defaultValue = empty(Response[0].ExSignatoryMail
																		) ? ""
																		: Response[0].ExSignatoryMail
																				;
																
																
																
																
															//	populating drop-down options
																
																var completionDate = Response[0].CompletionDate;
																
																
																
																 var efdate=Response[0].EffectiveDate;
	                                                              var eddate=Response[0].EndDate;    
																	$("#CompletionDate").val(DateExchange(completionDate));
																	
																	$("#EffectiveDate").val(DateExchange(efdate));
																	
																	$("#EndDate").val(DateExchange(eddate));
																	
																	//OD fields
																	
                                                                     $("#dateProject").val(DateExchange(Response[0].ApprovedDate));
																	
																	$("#deliveryDate").val(DateExchange(Response[0].DateSent));
																	
																	$("#firstRedlinesDate").val(DateExchange(Response[0].ContractDate));
																	
																	$("#firstRedlinesDateResp").val(DateExchange(Response[0].CustomerResponseDate));
																	
																	$("#dateSigned").val(DateExchange(Response[0].DateSigned));
																	
																	$("#DocNumber").val((Response[0].DocumentNum));
																		
																    $("#iterations").val((Response[0].Iteration));
																		
																	//$("#complexityScore").val((Response[0].ComplexityLevel));
																	
																	$("#hpeContent").val((Response[0].TrimNumRoot));
																		
																	$("#icdNumber").val((Response[0].ICDNum));
																	
																	//end	
															
															var Select = $("Select", "#myModalHorizontal");	
                                                     
													
															for(var i=0;i<(Select[0].length);i++)
															{
																if ((Select[0][i]).value==Response[0].Approval)
																{
																Select[0][i].selected=true;      
																}
																
															}
															/*for(var i=0;i<(Select[1].length);i++)
															{
																if ((Select[1][i]).value==Response[0].Approvaldropdown)
																{
																Select[1][i].selected=true;      
																}
																
															}*/
															for(var i=0;i<(Select[2].length);i++)
															{
																if ((Select[2][i]).value==Response[0].PurchaseNum)
																{
																Select[2][i].selected=true;      
																}
																
															}
															
															
															//$('#Approvaldropdown').selectpicker('val', Response[0].Approvaldropdown);
															//Entity
															for(var i=0;i<(Select[3].length);i++)
															{
																if ((Select[3][i]).value==Response[0].Entity)
																{
																Select[3][i].selected=true;      
																}
																
															}
															
															
															for(var i=0;i<(Select[4].length);i++)
															{
																if ((Select[4][i]).value==Response[0].CustomType)
																{
																Select[4][i].selected=true;      
																}
																
															}
															
															
															$('<option/>').val(Response[0].channel).html(Response[0].channel).appendTo('#Channel1');
															$('<option/>').val(Response[0].RequestType).html(Response[0].RequestType).appendTo('#RequestType1');
															$('<option/>').val(Response[0].ContractingParty).html(Response[0].ContractingParty).appendTo('#ContractingParty');
															//$('<option/>').val(Response[0].CustomType).html(Response[0].CustomType).appendTo('#CustomerType');
															//$('<option/>').val(Response[0].Product).html(Response[0].Product).appendTo('#Product');
															/*for(var i=0;i<(Select[5].length);i++)
															{
																if ((Select[5][i]).value==Response[0].channel)
																{
																Select[5][i].selected=true;      
																}
																
															}*/
																														//DocumentType1
															

															for(var i=0;i<(Select[8].length);i++)
															{
																if ((Select[8][i]).value==Response[0].DocumentType)
																{
																Select[8][i].selected=true;      
																}
																
															}
															for(var i=0;i<(Select[10].length);i++)
															{
																if ((Select[10][i]).value==Response[0].Active)
																{
																Select[10][i].selected=true;      
																}
																
															}	
															
															
															
															//CouponStatus
															
															for(var i=0;i<(Select[11].length);i++)
															{
																if ((Select[11][i]).value==Response[0].CouponStatus)
																{
																Select[11][i].selected=true;      
																}
																
															}
															//hasinformed1
															for(var i=0;i<(Select[12].length);i++)
															{
																if ((Select[12][i]).value==Response[0].HasInformed)
																{
																Select[12][i].selected=true;      
																}
																
															}
															for(var i=0;i<(Select[13].length);i++)
															{
																if ((Select[13][i]).value==Response[0].TotalityNum)
																{
																Select[13][i].selected=true;      
																}
																
															}
															for(var i=0;i<(Select[14].length);i++)
															{
																if ((Select[14][i]).value==Response[0].TotalityStatus)
																{
																Select[14][i].selected=true;      
																}
																
															}
															for(var i=0;i<(Select[15].length);i++)
															{
																if ((Select[15][i]).value==Response[0].Status)
																{
																Select[15][i].selected=true;      
																}
																
															}
															for(var i=0;i<(Select[16].length);i++)
															{
																if ((Select[16][i]).value==Response[0].ODpoc)
																{
																Select[16][i].selected=true;      
																}
																
															}
															for(var i=0;i<(Select[17].length);i++)
															{
																if ((Select[17][i]).value==Response[0].ComplexityLevel)
																{
																Select[17][i].selected=true;      
																}
																
															}
															for(var i=0;i<(Select[18].length);i++)
															{
																if ((Select[18][i]).value==Response[0].contractUploadTotality)
																{
																Select[18][i].selected=true;      
																}
																
															}			
															
															
																document
																		.getElementById("ExternalSignatoryTitle").defaultValue = empty(Response[0].ExSignatoryTitle
																		) ? ""
																		: Response[0].ExSignatoryTitle
																				;
																document
																.getElementById("comments").defaultValue = empty(Response[0].Comments
																) ? ""
																: Response[0].Comments
																		;
																
																$(
																		'#myModalHorizontal')
																		.modal(
																				'show');
															}
															
															
															else if (Response[0].Userid!=userID) {
																swal({
																	title : "Access Restricted",
																	text : "Unique Identifier not associated with your user name.",
																	type : "warning",
																	showCancelButton : false,
																	confirmButtonColor : "#DD6B55",
																	confirmButtonText : "OK",
																	cancelButtonText : "No",
																	closeOnConfirm : true,
																	closeOnCancel : true
																
																});

															} 
														},
														complete : function() {
															data = Response;

															// alert(data);
														}

													});

											/*
											 * document.getElementById("requestor1").defaultValue =
											 * data[0].Requestor;
											 */
											
											
											
											// document.getElementById("requestor1").defaultValue
											// = data[0].Requestor;

											// document.getElementById("Comments").defaultValue
											// = data[0].Comments;

											// document.getElementById("attachment").defaultValue=empty(data[0].attachment.fileExtension)?"":data[0].attachment;

										}
					}
										
					$(document)
							.ready(
									function() {
																		
										 $('#PRdropdown').change(
														function() {
															if ($("#PRdropdown")
																	.val() == 'Yes') {
																// alert("Hello");
																$("#pr_no")
																		.prop(
																				"readonly",
																				false);
															} else {
																$("#pr_no")
																		.prop(
																				"readonly",
																				true);
															}
														});

										$('#RequestType1')
												.change(
														function() {
															if ($(
																	"#RequestType1")
																	.val() == 'Other') {
																// alert("Hello");
																$(
																		"#OtherRequestor")
																		.prop(
																				"readonly",
																				false);
															} else {
																$(
																		"#OtherRequestor")
																		.prop(
																				"readonly",
																				true);
															}
														});

										$('#Channel1')
												.change(
														function() {
															if ($("#Channel1")
																	.val() == 'Other') {
																// alert("Hello");
																$(
																		"#OtherChannel")
																		.prop(
																				"readonly",
																				false);
															} else {
																$(
																		"#OtherChannel")
																		.prop(
																				"readonly",
																				true);
															}
														});

										$('#ContractingParty')
												.change(
														function() {
															if ($(
																	"#ContractingParty")
																	.val() == 'Other') {
																// alert("Hello");
																$(
																		"#OtherContractingparty")
																		.prop(
																				"readonly",
																				false);
															} else {
																$(
																		"#OtherContractingparty")
																		.prop(
																				"readonly",
																				true);
															}
														});
										$('#DocumentType1')
												.change(
														function() {
															if ($(
																	"#DocumentType1")
																	.val() == 'Other') {
																// alert("Hello");
																$(
																		"#OtherDocumentType")
																		.prop(
																				"readonly",
																				false);
															} else {
																$(
																		"#OtherDocumentType")
																		.prop(
																				"readonly",
																				true);
															}
														});
										$('#Active')
												.change(
														function() {
															if ($("#Active")
																	.val() == 'Yes') {
																// alert("Hello");
																$("#EmpICD")
																		.prop(
																				"readonly",
																				false);
															} else {
																$("#EmpICD")
																		.prop(
																				"readonly",
																				true);
															}
														});
										
										$('#Approvaldropdown')
										.change(
												function() {
													if ($("#Approvaldropdown")
															.val().includes('Other')) {
														// alert("Hello");
														$("#otherApproval")
																.prop(
																		"readonly",
																		false);
													} else {
														$("#otherApproval")
																.prop(
																		"readonly",
																		true);
													}
												});
										
										
										
										$('#TotalityNumber').change(function(){
											if ($("#TotalityNumber").val()=='Yes')
												{
											  //  alert("Hello");
												$("#OtherTotality").prop("readonly",false);
												$("#HCCStatus").prop("disabled",false);
												}
											else
												{
												$("#OtherTotality").prop("readonly",true);
												$("#OtherTotality").val("");
												$("#HCCStatus").prop("disabled",true);
												$("#HCCStatus").prop('selectedIndex',0);
												}
										  });

									});

					

					function empty(str) {
						if (typeof str == 'undefined' || !str
								|| str.length === 0 || str === ''
								|| !/[^\s]/.test(str) || /^\s*$/.test(str)) {
							return true;
						} else {
							return false;
						}
					}

					function DateExchange(xz)
					{
					
				if(empty(xz))
					{
					return "";
					}
				else {
					var yz = xz.split("/");
				var	zz = yz[2] + "-" + yz[0] + "-" + yz[1];
					return zz;
				}
				
					};
														
					
					
					function checkfiletype(ext) {
						var supportedfiletype = [ 'xls', 'xlsx', 'doc', 'docx',
								'ppt', 'pptx', 'zip', 'pdf', 'jpg', 'jpeg' ];
						if (supportedfiletype.includes(ext)) {
							return true;
						}
						return false;
					}
					;

			//	});
 $(document).ready(function(){
$("#newoffer")
		.click(
				function() {

					var uniqueIdentifier = document.getElementById("UniqueId").value;
					var InternalSignatoryName;
					var RequestorName;
					var StakeholderName1;
					var ExternalSignatoryName;
					var RequestorEmail;

					jQuery.ajax({
						type : "get",
						dataType : "json",
						url : urlPrefix
								+ "/JanssenSCG/getDistributionContractById",
						data : {
							user : userID,
							uniqueIdentifier : uniqueIdentifier
						},
						async : false,
						success : function(responseText) {

							Response = responseText;
							console.log(Response);
							if (empty(Response)) {
								swal({
									title : "No Contract Found",
									text : "No contract found",
									type : "warning",
									showCancelButton : false,
									confirmButtonColor : "#DD6B55",
									confirmButtonText : "OK",
									cancelButtonText : "No",
									closeOnConfirm : true,
									closeOnCancel : true
								});
							}
						},
						complete : function() {
							data = Response;

							// alert(data);
						}

					});

					// var mailformat =
					// /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
					var se = $("#StakeholderEmail").val();
					var re = $("#RequestorEmail").val();
					var ie = $("#InternalSignatoryEmail").val();
					var Ee = $("#ExternalSignatoryEmail").val();

					// alert(uniqueidentifier);
					// var
					// ContractStatus=$("#ContractStatus").val();
					// alert(accountLead);
					// var ODpoc=$("#ODpoc").val();
					// alert(customer1);
					var requestor1 = $("#requestor1").val();
					requestor1 = empty(requestor1) ? ""
							: requestor1;

					// alert(product1);
					var RequestorName = empty($("#requestorName").val())?"":$("#requestorName").val();
					//var RequestorTitle = ;
					var RequestorTitle = empty($("#RequestorTitle").val())?"":$("#RequestorTitle").val();

					var RequestorEmail = empty($("#RequestorEmail").val())?"":$("#RequestorEmail").val();

					var CustomerType = $("#CustomerType").val();
					// alert(CustomerType);
					var Channel = $("#Channel1").val();
                    var Channel1=empty(Channel)?"":Channel;
					var stakeholder = empty($("#Stakeholder").val())?data[0].Stakeholder:$("#Stakeholder").val();
					var RequestType = $("#RequestType1").val();
					var RequestType1=empty(RequestType)?"":RequestType;
					
					
					var Sname = $("#StakeholderName").val();
					var STitle = $("#StakeholderTitle").val();
					var Smail = $("#StakeholderEmail").val();
					

						StakeholderName1 = empty(Sname)?"":Sname;
						StakeholderTitle1=empty(STitle)?"":STitle;
						StakeholderEmail1=empty(Smail)?"":Smail;
						
					
					var id = $("#UniqueId").val();

					var requestorApproval1 = $("#requestorApproval").val();
					requestorApproval1 = empty(requestorApproval1) ? data[0].Approval
							: requestorApproval1;

					var Approvaldropdown1 = "";
					
					 var lth1=$("#Approvaldropdown").val().length;
			          for(var i=0;i<lth1;i++)
			   	   {
			   	   
			        	  Approvaldropdown1= $("#Approvaldropdown").val()[i]+", "+ Approvaldropdown1 ;
			   	   }
			          
			          Approvaldropdown1=Approvaldropdown1+" ";

			          Approvaldropdown1=  Approvaldropdown1.replace(",  ","");
					
					
					
					
					empty(Approvaldropdown1) ? data[0].Approvaldropdown
							: Approvaldropdown1;
					
					
					var PRdropdown1 = $("#PRdropdown").val();
					PRdropdown1 = empty(PRdropdown1) ? data[0].PurchaseNum
							: PRdropdown1;

					var PRNO = $("#pr_no").val();
					PRNO = empty(PRNO) ? "" : PRNO;

					var ContractingParty1 = $("#ContractingParty").val();
					ContractingParty1 = empty(ContractingParty1) ?""
							: ContractingParty1;

					var DocumentType1 = $("#DocumentType1").val();
					DocumentType1 = empty(DocumentType1) ? ""
							: DocumentType1;

					var ActiveMSASOW1 = $("#Active").val();
					ActiveMSASOW1 = empty(ActiveMSASOW1) ? data[0].Active
							: ActiveMSASOW1;

					//var Product2 = $("#Product").val();
					
					  var Product2="";
			          //var Product2=$("#Product").val();
			          var lth=$("#Product").val().length;
			          for(var i=0;i<lth;i++)
			   	   {
			   	   
			        	  Product2= $("#Product").val()[i]+", "+ Product2 ;
			   	   }
			          
			        Product2=Product2+" ";

			       Product2=  Product2.replace(",  ","");
			          
					Product2 = empty(Product2) ? "" : Product2;

					var Description = $("#Description").val();
					var Description1=empty(Description)?"":Description;
					var CouponStatus1 = $("#CouponStatus").val();
					CouponStatus1 = empty(CouponStatus1) ? data[0].CouponStatus
							: CouponStatus1;
					// var
					// DocumentNumber=$("#DocumentNumber").val();
					var name = $("#InternalSignatoryName").val();
					var Title=$("#InternalSignatoryTitle").val();
					var mail = $("#InternalSignatoryEmail").val();
					
				

					var	InternalSignatoryName1 = empty (name)?"":name;
					var	InternalSignatoryTitle1 = empty (Title)?"":Title;
					var	InternalSignatoryMail1 = empty (mail)?"":mail;
						
					
					var hasinformed1 = $("#hasinformed1").val();
					hasinformed1 = empty(hasinformed1) ? ""
							: hasinformed1;

					var Ename = $("#ExternalSignatoryName").val();
					var ETitle = $("#ExternalSignatoryTitle").val();
					var Email = $("#ExternalSignatoryEmail").val();
					
					var	ExternalSignatoryName1 =empty (Ename)?"":Ename;
                    var ExternalSignatoryTitle1=empty(ETitle)?"":ETitle;
                    var ExternalSignatoryEmail1=empty(Email)?"":Email;

					// var
					// ExternalSignatoryName=$("#ExternalSignatoryName").val()+","+$("#ExternalSignatoryEmail").val();

					var TotalityNumb = $("#TotalityNumber").val();
					var TotalityNumber=empty(TotalityNumb)?data[0].TotalityNum:TotalityNumb;
					var OtherTotality = empty($("#OtherTotality").val())?"":$("#OtherTotality").val();
					
					var HCCStatus = empty($("#HCCStatus").val())?data[0].TotalityStatus:$("#HCCStatus").val();

					
					var CompletionDate = empty($("#CompletionDate").val()) ? ""
							: $("#CompletionDate").val();
					var Entity = empty($("#Entity").val())?"":$("#Entity").val();
					var OtherChannel = empty($("#OtherChannel").val())?"":$("#OtherChannel").val();
					var OtherRequestor = empty($("#OtherRequestor").val())?"":$("#OtherRequestor").val();
					var OtherContractingparty = empty($("#OtherContractingparty").val())?"":$("#OtherContractingparty").val();
					var OtherDocumentType = empty($("#OtherDocumentType").val())?"":$("#OtherDocumentType").val();
					var otherApproval = empty($("#otherApproval").val())?"":$("#otherApproval").val();

					
					
					var EffectiveDate = empty($("#EffectiveDate").val()) ? ""
							: $("#EffectiveDate").val();

					var EndDate = empty($("#EndDate").val()) ? "": $(
							"#EndDate").val();
					var EmpICD = $("#EmpICD").val();
					/*
					 * var TRIMNumberRoot=$("#TRIMNumberRoot").val(); var
					 * TRIMNumberRootExtension=$("#TRIMNumberRootExtension").val();
					 * var ICDNumber=$("#ICDNumber").val();
					 */
					var Comments = empty($("#comments").val())?"":$("#comments").val();
					//OD fields
					var contractStatus=empty($("#ContractStatus").val())?data[0].Status:$("#ContractStatus").val();
			           var odPoint=empty($("#odPoc").val())?data[0].ODpoc:$("#odPoc").val();
			           var DocNumber=empty($("#DocNumber").val())?"":$("#DocNumber").val();
			           var dateProject=empty($("#dateProject").val())?"":$("#dateProject").val();
			           var deliveryDate=empty($("#deliveryDate").val())?"":$("#deliveryDate").val();
			           var firstRedlinesDate=empty($("#firstRedlinesDate").val())?"":$("#firstRedlinesDate").val();
			           var firstRedlinesDateResp=empty($("#firstRedlinesDateResp").val())?"":$("#firstRedlinesDateResp").val();
			           var dateSigned=empty($("#dateSigned").val())?"":$("#dateSigned").val();
			           var iterationNumber=empty($("#iterations").val())?"":$("#iterations").val();
			           var complexityScore=empty($("#complexityScore").val())?data[0].ComplexityLevel:$("#complexityScore").val();
			           var hpeContent=empty($("#hpeContent").val())?"":$("#hpeContent").val();
			           var icdNumber=empty($("#icdNumber").val())?"":$("#icdNumber").val();
			           var hasContract=empty($("#hasContract").val())?data[0].contractUploadTotality:$("#hasContract").val();
					//end
					// var
					// HasAttachments=$("#HasAttachments").val();

					// var filecontract =
					// $("#filecontract").get(0).files[0];
					// var
					// validateSuccess=validatefilesize(filecontract,dlg);

					// alert(notifyFD);
					var formData = new FormData();
					// var filecontract =
					// $("#filecontract").get(0).files[0];
					var validateSuccess = validatefilesize();
					/*
					 * formData.append('filecontract', filecontract);
					 */
					// formData.append('filecontract',
					// filecontract);
					if (validateSuccess) {
						// alert();
						var dataArray = new Array();
						// for(var
						// i=0;i<bokofbusinesses.length;i++){
						var data = {
							'Uniqueidentifier' : id,
							'Requestor' : requestor1,
							'RequestorName' : RequestorName,
							'RequestorTitle' : RequestorTitle,
							'RequestorMail' : RequestorEmail,
							'channel' : Channel1,
							'RequestType' : RequestType1,
							'StakeholderName' : StakeholderName1,
							
							'StakeholderMail' : StakeholderEmail1,
							'Approval' : requestorApproval1,
							'Approvaldropdown' : Approvaldropdown1.toString(),
							'otherApproval' :otherApproval,
							'PurchaseNum' : PRdropdown1,
							'otherPurchaseNum' : PRNO,
							'ContractingParty' : ContractingParty1,
							'DocumentType' : DocumentType1,
							'Active' : ActiveMSASOW1,
							'product' : Product2.toString(),
							'Description' : Description1,
							'CouponStatus' : CouponStatus1,
							'CustomType' : CustomerType,
							"ISignatoryName" : InternalSignatoryName1,
							"ISignatoryTitle" : InternalSignatoryTitle1,
							"ISignatoryMail" : InternalSignatoryMail1,
							"HasInformed" : hasinformed1,
							"ExSignatoryName" : ExternalSignatoryName1,
							"ExSignatoryTitle" : ExternalSignatoryTitle1,
							"ExSignatoryMail" : ExternalSignatoryEmail1,
							"TotalityNum" : TotalityNumber,
							"otherTotalityNum" : OtherTotality,
							"TotalityStatus" : HCCStatus,
							"CompletionDate" : CompletionDate,
							"Entity" : Entity,
							"otherChannel" : OtherChannel,
							"otherRequestType" : OtherRequestor,
							"otherContractingParty" : OtherContractingparty,
							"otherDocumentType" : OtherDocumentType,
							"EmpICD" : EmpICD,
							"EffectiveDate" : EffectiveDate,
							"EndDate" : EndDate,
							"Comments" : Comments,
							"Stakeholder" :StakeholderTitle1,
							"Status":contractStatus,"ODpoc":odPoint,
							"DocumentNum":DocNumber,"ApprovedDate":dateProject,
							"DateSent":deliveryDate,"ContractDate":firstRedlinesDate,
							"CustomerResponseDate":firstRedlinesDateResp,"DateSigned":dateSigned,"Iteration":iterationNumber,
							"ComplexityLevel":complexityScore,"TrimNumRoot":hpeContent,
							"ICDNum":icdNumber,"contractUploadTotality":hasContract
							

						};
						dataArray.push(data);
						// }

						var jsonData = JSON.stringify(dataArray);
						// alert(jsonData);

						$("#CommGrid").css('visibility', 'hidden');
						// alert("hi1");
						// $("#savediv").style.visibility =
						// "hidden";
						$("#savediv").hide();
						// alert("hi2");
						// document.getElementById("confirmdiv").style.visibility
						// = "hidden";

						// alert("hi4");
						$("#loadingmsg").css('visibility', 'hidden');
						formData.append('content', jsonData);
						formData.append('requestorType',"OD");
						jQuery.ajax({
							type : "post",
							dataType : "json",
							url : urlPrefix + "/JanssenSCG/distributionedit",
							data : formData,
							async : true,
							processData : false,
							contentType : false,
							success : function(response) {
								// alert("ajax
								// response
								// contractadd"+response);
								Response = response.saveSuccess;
								var title;
								var alertText;
								if (Response == 'saveSuccess') {
									title = "Sucessfully Saved!";
									text = "Successfully saved changes."
										 type="success";
								} else {
									title = "Oops! Data Not saved!";
									text = "Oops! Data not saved ";
									// text=text+response.validationMessage;
								}
								// $('#productPicker').val(product1);
								// $('#businessPicker').val(customer1);
								// $('#channelPicker').val(channel1);
								 swal({
								        title: title,
								        text: text,
								        type: "warning",
								        showCancelButton: false,
								        confirmButtonColor: "#DD6B55",
								        confirmButtonText: "OK",
								        cancelButtonText: "No",
								        closeOnConfirm: true,
								        closeOnCancel: false
					    				}, function(isConfirm) {
					    				
					    				if(isConfirm){
					    					//$(".selectpicker").selectpicker('refresh');
					    					$("#Product").val('default');
					    					$("#Product").selectpicker("refresh");
					    					$('.dependentDropdown').empty();
					    				 handsonComm.updateOptions({
			                        	 			data:getData1()
			                        	 	});
			                        	// 	var data=handsonComm.getSourceData();
	    				
							    			//alert(network.countRows());
							    			
			                        	 	handsonComm.render();
					    				}
					    				});
			                        	 	
		  					},
		  	    
							complete : function() {
								$("#CommGrid").css('visibility', 'visible');

								$("#savediv").show();
								$("#confirmdiv").show();

								$("#loadingmsg").css('visibility', 'hidden');

							}
						});
						/* dlg.dialog("close"); */
						$('#myModalHorizontal').modal('hide');
						
						$('#myModalHorizontal').on('hide.bs.model',function()
								{
							alert("form will close");
								})
						$("#savediv").show();
						$("#confirmdiv").show();

						$("#CommGrid").css('visibility', 'hidden');

						$("#loadingmsg").css('visibility', 'visible');
					}

				});

function other()
{
var otherChannel=$("#OtherChannel").val();
var otherRequestor=$("#OtherRequestor").val();
var otherContracting=$("#OtherContractingparty").val();
var otherDocument=$("#OtherDocumentType").val();
var c=0;
	  if (($("#Channel1").val()=='Other'))
 	   {
 		   if((empty(otherChannel)))
 			   {
 			   c++;
 			   /*alert("Please enter 'Other' fields value");
 	   			success=false;*/

 			   }
 	   }
       if (($("#RequestType1").val()=='Other'))
 			   {

 		        if((empty(otherRequestor)))
 		   
 			      c++;
 		      /* alert("Please enter 'Other' fields value");
 	   			success=false;*/
 			   }
       if (($("#ContractingParty").val()=='Other')){
 		   if((empty(otherContracting)))
 		   {
 			   //alert("Please enter 'Other' fields value");
 			   	c++;
 	   			//success=false;
 		   }
 	  }
       if(($("#DocumentType1").val()=='Other'))
 		   {
 		   	if(empty(otherDocument))
 		   		{
 		   		/*alert("Please enter 'Other' fields value");
 	   			success=false;*/
 		          c++;
 		   		}
 		   }
 	 return c;
}
function validatefilesize() {
	// alert("file validation"+file.name);
	var success = true;
	var startdate = $("#EffectiveDate").val();
	var enddate = $("#EndDate").val();
	var name = $("#InternalSignatoryName").val();
	var mail = $("#InternalSignatoryEmail").val();
	var Ename = $("#ExternalSignatoryName").val();
	var Email = $("#ExternalSignatoryEmail").val();
	var se = $("#StakeholderEmail").val();
	var re = $("#RequestorEmail").val();
	var Description = $("#Description").val();
	var contractType = $("#CustomerType").val();
	var targetDate = $("#CompletionDate").val();
	var legalentity = $("#Entity").val();
	var Channel2 = $("#Channel1").val();
	var RequestType2 = $("#RequestType1").val();
	var contractingEntity = $("#ContractingParty").val();
	var DocumentType1 = $("#DocumentType1").val();
	var product1 = $("#Product").val()
	var RequestorName1 = $("#RequestorName").val();
	var RequestorMail1 = $("#RequestorEmail").val();
	var stakeholder1 = $("#StakeholderName").val();
	var Sname = $("#StakeholderName").val();
	var hasinformed1 = $("#hasinformed1").val();
	var title=$("#InternalSignatoryTitle").val();
    var Etitle=$("#ExternalSignatoryTitle").val();
	
    var otherChannel=$("#OtherChannel").val();
    var otherRequestor=$("#OtherRequestor").val();
    var otherContracting=$("#OtherContractingparty").val();
    var otherDocument=$("#OtherDocumentType").val();
	
	var Stitle= $("#StakeholderName").val();
	var k;var n=4;var c=0;
	
	/*
	 if(empty(title)||empty(Etitle) ||empty(hasinformed1)||empty(stakeholder1)||empty(RequestType2)||empty(targetDate)||empty(legalentity)||empty(Description)||empty(RequestorName1)||empty(contractType)||empty(Channel2)||empty(contractingEntity)||empty(DocumentType1)||empty(product1)||empty(name)||empty(Ename))
     {

     alert ("Please Enter Mandatory fields.")
     success=false;
     }*/
	 var emptyFieldCount=0;
     var invalidFieldCount=0;
     if(empty(RequestorName1))
     	 {
     	 // alert ("Please select Requestor's Name.")
     	 $("#RequestorName").css( "border", "1px solid red"); 
     	 $("#RequestorName").css( "box-shadow", "none");
     	 emptyFieldCount++;
     	 success=false;
     	 }

      if(empty(re))
     	 {
     	 // alert ("Please enter Requestor's Email.")
     	 $("#RequestorEmail").css( "border", "1px solid red"); 
     	 $("#RequestorEmail").css( "box-shadow", "none");
     	 emptyFieldCount++;
     	 success=false;
     	 }
      
      if(empty(stakeholder1))
     	 {
     	 //alert ("Please enter Stakeholder's Name.")
     	 $("#StakeholderName").css( "border", "1px solid red"); 
     	 $("#StakeholderName").css( "box-shadow", "none");
     	 emptyFieldCount++;
     	 success=false;
     	 }
      
      
      if(empty(se))
     	 {
     	 //alert ("Please enter Stakeholder's Email.")
     	 $("#StakeholderEmail").css( "border", "1px solid red"); 
     	 $("#StakeholderEmail").css( "box-shadow", "none");
     	 emptyFieldCount++;
     	 success=false;
     	 }

     if(empty(targetDate))
       	 {
     	 //alert ("Please select Targeted Completion Date.")
       	 $("#CompletionDate").css( "border", "1px solid red"); 
     	 $("#CompletionDate").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(legalentity))
       	 {
     	 //alert ("Please select J&J Legal Entity.")
       	 $("#Entity").css( "border", "1px solid red"); 
     	 $("#Entity").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(contractType))
       	 {
     	 //alert ("Please select Contracting Party Type.")
       	 $("#CustomerType").css( "border", "1px solid red"); 
     	 $("#CustomerType").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(Channel2))
       	 {
     	 //alert ("Please select Channel.")
       	 $("#Channel1").css( "border", "1px solid red"); 
     	 $("#Channel1").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }
       
     if(empty(RequestType2))
       	 {
     	 //alert ("Please select Request Type.")
       	 $("#RequestType1").css( "border", "1px solid red"); 
     	 $("#RequestType1").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(contractingEntity))
       	 {
     	 //alert ("Please select Contracting Party Legal Entity.")
       	 $("#ContractingParty").css( "border", "1px solid red"); 
     	 $("#ContractingParty").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(DocumentType1))
       	 {
         // alert ("Please select Document Type Requested.")
       	 $("#DocumentType1").css( "border", "1px solid red"); 
     	 $("#DocumentType1").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(product1))
   	 {
     // alert ("Please select Product(s) & NDC Number(s).")
   	 $("#productvalidation").css( "border", "1px solid red"); 
 	 $("#productvalidation").css( "box-shadow", "none");
 	 $("#productvalidation").css( "border-radius", "5px");
 	 $("#productvalidation").css( "height", "37px");
 	 emptyFieldCount++;
   	 success=false;
   	 }
 else
	 {
	 $("#productvalidation").css( "border", ""); 
 	 $("#productvalidation").css( "box-shadow", "");
 	 $("#productvalidation").css( "border-radius", "");
 	 $("#productvalidation").css( "height", "37px");
	 }


     if(empty(Description))
       	 {
         //alert ("Please enter Project Description.")
       	 $("#Description").css( "border", "1px solid red"); 
     	 $("#Description").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(name))
       	 {
     	 //alert ("Please enter Internal Signatory (Name).")
     	 $("#InternalSignatoryName").css( "border", "1px solid red"); 
     	 	 $("#InternalSignatoryName").css( "box-shadow", "none");
     	 emptyFieldCount++;
         success=false;
       	 }

     if(empty(title))
         {
         //alert ("Please enter Internal Signatory (Title).")
     	 $("#InternalSignatoryTitle").css( "border", "1px solid red"); 
     	 	 $("#InternalSignatoryTitle").css( "box-shadow", "none");
     	 emptyFieldCount++;
         success=false;
         }

     if(empty(mail))
        {
        // alert ("Please enter Internal Signatory Email.")
     	$("#InternalSignatoryEmail").css( "border", "1px solid red"); 
     	 	$("#InternalSignatoryEmail").css( "box-shadow", "none");
     	 	emptyFieldCount++;
        success=false;
        }

     if(empty(hasinformed1))
       	 {
       	 //alert ("Please select Has Internal Signatory Been Informed of Project?")
       	 $("#hasinformed1").css( "border", "1px solid red"); 
      	 $("#hasinformed1").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(Ename))
       	 {
       	 //alert ("Please enter External Signatory (Name).")
       	 $("#ExternalSignatoryName").css( "border", "1px solid red"); 
      	 $("#ExternalSignatoryName").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(Etitle))  
       	 {
       	 // alert ("Please enter External Signatory (Title).")
       	 $("#ExternalSignatoryTitle").css( "border", "1px solid red"); 
      	 $("#ExternalSignatoryTitle").css( "box-shadow", "none");
     	 emptyFieldCount++;
       	 success=false;
       	 }

     if(empty(Email))
      	 {
      	 //alert ("Please enter External Signatory Email.")
      	 $("#ExternalSignatoryEmail").css( "border", "1px solid red"); 
      	 $("#ExternalSignatoryEmail").css( "box-shadow", "none");
     	 emptyFieldCount++;
      	 success=false;
      	 }

     if(emailIsValid(re))
       	 {
         //alert ("Requestor's Email entered is Invalid !!")
     	 $("#RequestorEmail").css( "border", "1px solid red"); 
     	 $("#RequestorEmail").css( "box-shadow", "none");
     	 invalidFieldCount++;
       	 success=false;
       	 }

     if(emailIsValid(se))
     	 {
     	// alert ("Stakeholder's Email entered is Invalid !!")
     	 $("#StakeholderEmail").css( "border", "1px solid red"); 
     	 $("#StakeholderEmail").css( "box-shadow", "none");
     	 invalidFieldCount++;
     	 success=false;
     	 }

     if(emailIsValid(Email))
       	 {
       	 //alert (" External Signatory Email entered is Invalid !!")
       	 $("#ExternalSignatoryEmail").css( "border", "1px solid red"); 
      	 $("#ExternalSignatoryEmail").css( "box-shadow", "none");
      	invalidFieldCount++;
       	 success=false;
       	 }

     if(emailIsValid(mail))
       	 {
       	 //alert ("Internal Signatory Email entered is Invalid !!")
     	 $("#InternalSignatoryEmail").css( "border", "1px solid red"); 
     	 $("#InternalSignatoryEmail").css( "box-shadow", "none");
     	 invalidFieldCount++;
       	 success=false;
       	 }


     //validation css border      
     	 if(RequestorName1)
        	 {
        	 $("#RequestorName").css( "border", ""); 
        	 $("#RequestorName").css( "box-shadow", "");
        	 
        	 }
     	 
     	 if(!(emailIsValid(re)))
        	 {
        	 $("#RequestorEmail").css( "border", ""); 
             $("#RequestorEmail").css( "box-shadow", "");
        	 }
     	 
     	 if(stakeholder1)
        	 {
        	 $("#StakeholderName").css( "border", ""); 
             $("#StakeholderName").css( "box-shadow", "");
        	 }
     	 
     	 if(!(emailIsValid(se)))
     		 {
     		 $("#StakeholderEmail").css( "border", ""); 
        	 $("#StakeholderEmail").css( "box-shadow", "");
     		 }
     	 
     	 if((targetDate))
           	 {
     	     $("#CompletionDate").css( "border", ""); 
             $("#CompletionDate").css( "box-shadow", "");
     	     }
     	 
     	 if((legalentity))
       	 	{
       	  	$("#Entity").css( "border", ""); 
       	  	$("#Entity").css( "box-shadow", "");
       	 	}
     	 
     	 if((contractType))
           	 {
           	 $("#CustomerType").css( "border", ""); 
        	 $("#CustomerType").css( "box-shadow", "");
           	 }
     	 
     	 if((Channel2))
           	 {
           	 $("#Channel1").css( "border", ""); 
        	 $("#Channel1").css( "box-shadow", "");
           	 }
     	 
     	 if((RequestType2))
       	 	 {
       	     $("#RequestType1").css( "border", ""); 
       	     $("#RequestType1").css( "box-shadow", "");
       	 	 }
     	 
     	 if((contractingEntity))
           	 {
           	 $("#ContractingParty").css( "border", ""); 
        	 $("#ContractingParty").css( "box-shadow", "");
           	 }
     	 
     	 if((DocumentType1))
           	 {
             $("#DocumentType1").css( "border", ""); 
        	 $("#DocumentType1").css( "box-shadow", "");
           	 }
     	 
     	
     	 
     	 if((Description))
           	 {
           	 $("#Description").css( "border", ""); 
        	 $("#Description").css( "box-shadow", "");
           	 }
     	 
     	 if((name))
           	 {
        	 $("#InternalSignatoryName").css( "border", ""); 
       	 	 $("#InternalSignatoryName").css( "box-shadow", "");
             }
     	 
     	 if((title))
             {
             $("#InternalSignatoryTitle").css( "border", ""); 
       	 	 $("#InternalSignatoryTitle").css( "box-shadow", "");
             }
     	 
     	 if(!(emailIsValid(mail)))
             {
             $("#InternalSignatoryEmail").css( "border", ""); 
      	 	 $("#InternalSignatoryEmail").css( "box-shadow", "");
             }

     	 if((hasinformed1))
           	 {
         	 $("#hasinformed1").css( "border", ""); 
     	 	 $("#hasinformed1").css( "box-shadow", "");
           	 } 
     	 
     	 if((Ename))
           	 {
           	 $("#ExternalSignatoryName").css( "border", ""); 
     	 	 $("#ExternalSignatoryName").css( "box-shadow", "");
           	 }
     	 
     	 if((Etitle))
           	 {
           	 $("#ExternalSignatoryTitle").css( "border", ""); 
     	 	 $("#ExternalSignatoryTitle").css( "box-shadow", "");
           	 }

     	 if(!(emailIsValid(Email)))
           	 {
           	 $("#ExternalSignatoryEmail").css( "border", ""); 
     	 	 $("#ExternalSignatoryEmail").css( "box-shadow", "");
           	
           	 }
     	
	
	/*if(empty(stakeholder1))
	 {
	 alert ("Please enter Stakeholder's Name.")
	 success=false;
	 }
	else if(empty(se))
	 {
	 alert ("Please enter Stakeholder's Email.")
	 success=false;
	 }
	 else if(emailIsValid(se))
   	 {
   	 alert ("Stakeholder's Email entered is Invalid !!")
   	 success=false;
   	 }
	 else if(empty(targetDate))
   	 {
   	 alert ("Please select Targeted Completion Date.")
   	 success=false;
   	 }
	 else if(empty(legalentity))
   	 {
   	 alert ("Please select J&J Legal Entity.")
   	 success=false;
   	 }
	 else if(empty(contractType))
   	 {
   	 alert ("Please select Contracting Party Type.")
   	 success=false;
   	 }
	 else if(empty(Channel2))
   	 {
   	 alert ("Please select Channel.")
   	 success=false;
   	 }
	 else if(empty(RequestType2))
   	 {
   	 alert ("Please select Request Type.")
   	 success=false;
   	 } 
	 else if(empty(contractingEntity))
   	 {
   	 alert ("Please select Contracting Party Legal Entity.")
   	 success=false;
   	 }
	 else if(empty(DocumentType1))
   	 {
   	 alert ("Please select Document Type Requested.")
   	 success=false;
   	 }
	 else if(empty(product1))
   	 {
   	 alert ("Please select Product(s) & NDC Number(s).")
   	 success=false;
   	 }
	 else if(empty(Description))
   	 {
   	 alert ("Please enter Project Description.")
   	 success=false;
   	 }
	 else if(empty(name))
   	 {
   	 alert ("Please enter Internal Signatory (Name).")
   	 success=false;
   	 }
	 else if(empty(title))
     {
     alert ("Please enter Internal Signatory (Title).")
     success=false;
     }
	 else if(empty(mail))
     {
     alert ("Please enter Internal Signatory Email.")
     success=false;
     }
	 else if(emailIsValid(mail))
   	 {
   	 alert ("Internal Signatory Email entered is Invalid !!")
   	 success=false;
   	 }
	 else if(empty(hasinformed1))
   	 {
   	 alert ("Please select Has Internal Signatory Been Informed of Project?")
   	 success=false;
   	 }
	 else if(empty(Ename))
   	 {
   	 alert ("Please enter External Signatory (Name).")
   	 success=false;
   	 }
	 else if(empty(Etitle))
   	 {
   	 alert ("Please enter External Signatory (Title).")
   	 success=false;
   	 }
	 else if(empty(Email))
   	 {
   	 alert ("Please enter External Signatory Email.")
   	 success=false;
   	 }
	 else if(emailIsValid(Email))
   	 {
   	 alert (" External Signatory Email entered is Invalid !!")
   	 success=false;
   	 }
	 else if(empty(RequestorName1))
   	 {
   	 alert ("Please enter Requestor's Name.")
   	 success=false;
   	 }
	 else if(empty(product1))
   	 {
   	 alert ("Please select Product(s) & NDC Number(s).")
   	 success=false;
   	 }
	 else if(empty(re))
   	 {
   	 alert ("Please enter Requestor's Email.")
   	 success=false;
   	 }
	 else if(emailIsValid(RequestorMail1))
   	 {
   	 alert ("Please enter Requestor's Email.")
   	 success=false;
   	 }
	*/

	   /*else if (($("#ContractingParty").val()=='Other')||($("#Channel1").val()=='Other')||($("#RequestType2").val()=='Other'))
		   {
        	if($("#DocumentType1").val()=='Other')
        	{
        	
		        	if(empty(otherChannel)||empty(otherRequestor)||empty(otherContracting)||empty(otherDocument))
		   		{
		   			alert("Please enter 'Other' fields value");
		   			success=false;
		   		}
		   	
        	}


        	 else if(empty(otherChannel)||empty(otherRequestor)||empty(otherContracting))
        	 {
         			alert("Please enter 'Other' fields value");
         				success=false;
          		   }
          		   
		   
		   } */
	
	  if (($("#Channel1").val()=='Other'))
	   {
		   if((empty(otherChannel)))
			   {
			   c++;
			   /*alert("Please enter 'Other' fields value");
	   			success=false;*/
			   $("#OtherChannel").css( "border", "1px solid red"); 
  			   $("#OtherChannel").css( "box-shadow", "none");
  			
  			   }
  		   else
		   {
		  
		   $("#OtherChannel").css( "border", ""); 
		   $("#OtherChannel").css( "box-shadow", "");
		   }
			  
	   }
	  else if(($("#Channel1").val()!='Other') || empty($("#Channel1").val()))
 	 {
 	 $("#OtherChannel").css( "border", ""); 
		   $("#OtherChannel").css( "box-shadow", "");
 	 
 	 }
	  
	  if (($("#RequestType1").val()=='Other'))
			   {

		        if((empty(otherRequestor)))
		        {
			      c++;
		      /* alert("Please enter 'Other' fields value");
	   			success=false;*/
			      $("#OtherRequestor").css( "border", "1px solid red"); 
	   			    $("#OtherRequestor").css( "box-shadow", "none");
	   			 
	  		        }
	  		      else
	  			   {
	  			  
	  			   $("#OtherRequestor").css( "border", ""); 
	  			   $("#OtherRequestor").css( "box-shadow", "");
	  			   }
			   }
	  else if(($("#RequestType1").val()!='Other') || empty($("#RequestType1").val()))
 	 {
 	 $("#OtherRequestor").css( "border", ""); 
		   $("#OtherRequestor").css( "box-shadow", "");
 	 
 	 }
	  
	  if (($("#ContractingParty").val()=='Other')){
		   if((empty(otherContracting)))
		   {
			   //alert("Please enter 'Other' fields value");
			   	c++;
	   			//success=false;
			   	$("#OtherContractingparty").css( "border", "1px solid red"); 
	 			  $("#OtherContractingparty").css( "box-shadow", "none");
	 			 
	  		   }
	  		 else
			   {
			  
			   $("#OtherContractingparty").css( "border", ""); 
			   $("#OtherContractingparty").css( "box-shadow", "");
			   }
	  }
	  else if(($("#ContractingParty").val()!='Other') || empty($("#ContractingParty").val()))
 	 {
 	 $("#OtherContractingparty").css( "border", ""); 
	   $("#OtherContractingparty").css( "box-shadow", "");
 	 
 	 }
	  if(($("#DocumentType1").val()=='Other'))
		   {
		   	if(empty(otherDocument))
		   		{
		   		/*alert("Please enter 'Other' fields value");
	   			success=false;*/
		          c++;
		          $("#OtherDocumentType").css( "border", "1px solid red"); 
	   			    $("#OtherDocumentType").css( "box-shadow", "none");
	   			
	  		   		}
	  		  else
			   {
			  
			   $("#OtherDocumentType").css( "border", ""); 
			   $("#OtherDocumentType").css( "box-shadow", "");
			   }
		   } 
	  else if(($("#DocumentType1").val()!='Other') || empty($("#DocumentType1").val()))
      {
		  	$("#OtherDocumentType").css( "border", ""); 
		  	$("#OtherDocumentType").css( "box-shadow", "");

       }
	//  k=c;
	  
	  
	  if(emptyFieldCount!=0)
  	{
		 alert ("Please Enter Mandatory fields.")
		 success=false;
  	}
	 else if(invalidFieldCount!=0)  
		 {
		 alert ("Please Enter Valid email ID.")
		 success=false;
		 }  
	 else if(c>0)    	{
	    	alert("Please enter 'Other' fields value");
	    		success=false;
	    	}

	/*else if(enddate<startdate){
	 alert("End date should be greater than Effective date!!");
	 success=false; 
	 }*/
	
	/*if(empty(Stitle))
	{
		alert("Please Enter Stakeholder Title")
		success=false;
	}
	*/
		// alert("file validation"+file.name);
	/*
	 * var success=true; var startdate=dlg.find("#startdate").val(); var
	 * enddate=dlg.find("#enddate").val(); var
	 * bokofbusiness=dlg.find("#bookofbusiness1").val(); var
	 * bokofbusinesses=bokofbusiness.toString().split(","); var
	 * customertype1=dlg.find("#customertype1").val(); //alert(bokofbusiness);
	 * var product1=dlg.find("#product1").val(); var
	 * medicalpharmacy=dlg.find("#medicalpharmacy1").val(); var
	 * document=dlg.find("#document1").val(); var
	 * epudesc1=dlg.find("#epudesc1").val(); var
	 * utilizationmanagement1=dlg.find("#utilizationmanagement1").val(); var
	 * strategyName=dlg.find("#strategyName").val(); var
	 * rebate=dlg.find("#rebate").val(); var
	 * notifyFD=dlg.find("#notifyFD").is(':checked'); //alert("start
	 * date"+startdate+"End date"+enddate); if(empty(bokofbusiness) ||
	 * empty(document) || empty(product1) || empty(medicalpharmacy) ||
	 * empty(epudesc1) ||
	 * empty(strategyName)||empty(rebate)||empty(customertype1)||empty(utilizationmanagement1)||(!dlg.find("#notifyFD").is(':checked'))){
	 * dlg.find("#mandatorystartenddatedifference").hide();
	 * dlg.find("#mandatoryfield").show(); success=false; }else
	 * if(empty(startdate) || empty(enddate)){
	 * dlg.find("#mandatorystartenddate").show(); success=false;
	 * 
	 * }else if(enddate<startdate){ dlg.find("#mandatorystartenddate").hide();
	 * dlg.find("#mandatorystartenddatedifference").show(); success=false; }
	 * if(file!=null){ var ext=(file.name).split('.')[1];
	 * if(!checkfiletype(ext)) {
	 * 
	 * dlg.find("#mandatoryfieldMsgType").show(); success=false; } if(file.size >
	 * 2*1024*1024) { // $(this).val('');
	 * dlg.find("#mandatoryfieldMsgSize").show(); success=false; } }
	 */
	return success;   

}


function emailIsValid(email) {
	var re = /^(?:[a-zA-Z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-zA-Z0-9-]*[a-zA-Z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
	return !re.test(email);
}
 });
