
function Handson(containerid){
	
         var container = document.getElementById(containerid);
   //     var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
    		var options = {
    			data:getData(),
    			 colWidths: [120,120,130,120,140,120,150,140,120,130],
        	  //  rowHeights:20,
        	    comments: true,
        	    search:true,
        	    columnSorting: true,
        	    sortIndicator: true,
        	    manualColumnResize: true,
        	    manualRowResize: true, 
        	    multiSelect: true,        	   
        	   // preventOverflow: 'horizontal',
        	    filters:true,
        	    colHeaders:true,
        	    afterOnCellMouseDown: function(event, coords){
        	        // 'coords.row < 0' because we only want to handle clicks on the header row
        	       // alert(coords.row);
        	    	var rowTemp= coords.row;
        	    	 var data=this.getDataAtRow(coords.row);
        	    	 var data1 = JSON.stringify(data);
        	    	// var b= getIsLockedContract(data1);
        	    	
        	    	// if(b == true)
					//	{
					//	 alert("This row is being edited by some other user....Please try after some time");
					//	 this.deselectCell();
						/* if(rowTemp == 0){
							 this.selectCell(rowTemp+1,rowTemp+1);
						 }else{
							 this.selectCell(rowTemp-1,rowTemp-1);
						 }*/
						 
						// return false;
						//}
					 
        	    },
        	    
        	    contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        }
                    	}
                },
        	    contextMenuCopyPaste: {
        	        swfPath: 'js/ZeroClipboard.swf'
        	      },
        	   // fixedColumnsLeft: 3,
        	    manualColumnFreeze:true,
        	    fillHandle: {
            		autoInsertRow: false,
        		},
        	  //  dropdownMenu: true,
        	  //  filters:true,
        	    nestedHeaders: [
        	                  
       	                     ['CHANNEL','PRODUCT','ACCOUNT','CURRENTLY IN ACTIVE BID CYCLE','BID REBATE','BID APPROACH','PROJECTED FORMULARY STATUS','BID DUE DATE','LAST MODIFIED BY','LAST MODIFIED ON']],
       	         columns: [
                      	    	 
                      	    	 
                      	    	       {
                                   	      data:'channelName',
                                   	      renderer:safeHtmlRenderer,
                                   	      readOnly:true
                                   	   },
                                   	   {
                                   	      data:'productName',
                                   	      renderer:safeHtmlRenderer,
                                   	      readOnly:true
                                   	   },  
                                	   {
                                   	      data:'accountName',
                                   	      renderer:safeHtmlRenderer,
                                   	      readOnly:true
                                   	   },
                                   	 {
                                 	         data:'isBidActive',
                                 	        editor: 'select',
                                 	       renderer:yesNoRenderer,
                                            selectOptions: ['Yes','No',' '],
                                        	   readOnly:false
                                 	      
                                 	      },
                                 	       {
                                 	         data:'bidRebate',
                                 	        renderer:safeHtmlRenderereditable,
                                  	    	 readOnly:false
                                 	      
                                 	      },
                                 	       {
                                 	         data:'bidApproach',
                                 	         renderer:safeHtmlRenderereditable,
                                  	    	 readOnly:false
                                 	      
                                 	      },
                                 	       {
                                 	         data:'projectedFormularyStatus',
                                 	         renderer:safeHtmlRenderereditable,
                                  	    	 readOnly:false
                                 	      
                                 	      },
                                 	      {
                                 	    	  data:'bidDuedate',
                                 	    	  type: 'date',
                                 	      renderer:dateRenderer,
                               	          dateFormat: 'MMM DD,YYYY',
                               	           //validator: customDateValidator,
                               	       correctFormat: true,
                               	          //defaultDate: '2016-06-29',
                               	          allowEmpty: false,
                               	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                               	          datePickerConfig: {
                               	          // First day of the week (0: Sunday, 1: Monday, etc)
                               	          firstDay: 0,
                               	          showWeekNumber: true,
                               	          numberOfMonths: 1,
                               	          
                               	        },
                               	        readOnly:false
                                 	    	}  ,  
                                 	    {
                                    	     data:'lastModifiedBy',
                                    	     renderer:safeHtmlRenderer,
                                     	    readOnly:true
                                    	      
                                    	      },
                                 	      
                                 	     {
                                	    	  data:'lastModifiedOn',
                                	    	  type: 'date',
                                	    	  renderer:safeHtmlRenderer,
                              	          dateFormat: 'MMM DD,YYYY',
                              	          correctFormat: true,
                              	          //defaultDate: '2016-06-29',
                              	          allowEmpty: false,
                              	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                              	          datePickerConfig: {
                              	          // First day of the week (0: Sunday, 1: Monday, etc)
                              	          firstDay: 0,
                              	          showWeekNumber: true,
                              	          numberOfMonths: 1,
                              	          
                              	        },
                              	        readOnly:true
                                	    	}
                                	   /* {
                                       	   data:'confirmedBy',
                                       	   renderer:safeHtmlRenderer,
                                           readOnly:true
                                       	      
                                       	 },
                                       	 {
                               	    	  data:'confirmedOn',
                               	    	  type: 'date',
                               	    	  renderer:safeHtmlRenderer,
                             	          dateFormat: 'MMM DD,YYYY',
                             	          correctFormat: true,
                             	          //defaultDate: '2016-06-29',
                             	          allowEmpty: false,
                             	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                             	          datePickerConfig: {
                             	          // First day of the week (0: Sunday, 1: Monday, etc)
                             	          firstDay: 0,
                             	          showWeekNumber: true,
                             	          numberOfMonths: 1,
                             	          
                             	        },
                             	        readOnly:true
                               	    	}*/
                                    	      
                               	      ] ,
                               	  
                               	        afterGetColHeader: function(col, TH) {
                    	    var TR = TH.parentNode;
                    	    var THEAD = TR.parentNode;
                    	    var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                    	    function applyClass(elem, className) {
                    	      if (!Handsontable.Dom.hasClass(elem, className)) {
                    	        Handsontable.Dom.addClass(elem, className);
                    	      }
                    	    }

                    	    // first level from the top
                    	    if (headerLevel === -2 && (col===0||col===1||col===2)) {
                      	      applyClass(TH, 'color2');

                      	    // second level from the top
                      	    }else if (headerLevel === -2 && (col===3||col===4||col===5||col===6||col===7||col===8||col===9||col===10)) {
                        	      applyClass(TH, 'bluecolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -1) {
                      	    	applyClass(TH, 'color1');
                       	       
                    	      }
                  	     
                       }
                  	      
        	
        	  }
    		
    		var network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
    		var numberValidator = /^\d+$/;
    		
    		var customDateValidator = function(value, callback) {
    			
    			  if (value === '') {
    				  alert(value);
    				  value=null;
    			  } /*else {
    			    Handsontable.DateValidator.call(this, value, callback);
    			  }*/
    			};
    		
    	/*	var notEmpty = function (value, callback) {
    			alert("dghjfdhg");
    			//var numberValidator = /^\d+$/;
    			var patt = new RegExp("/^\d+$/");
    		    if (patt.test(value)) {
    		     //   alert("a number");
    		        
    		    } else {
    		    	 alert("Number needed");
    		    	 callback(false);
    		    }
    		};*/
    		
    		/*function getIsLockedContract(data1)
    		{
    		
    		jQuery.ajax({
    	 		type:"get",
    	 		dataType:"json",
    	 		url:urlPrefix+"/JanssenSCG/lockStatusContract",
    	 		data:{data:data1},
    	 		async:false,
    	 		success: function(responseText) { 
    			    Response= responseText;
    		},
    		complete: function(){
    			data = Response;
    		 }
    		 });
    		 
    		 return data;
    		}
    		*/
    		
}
        	  