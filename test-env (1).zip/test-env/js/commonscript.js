$( window ).load(function() {
	$(".filterSection").css("margin-top", $(".home-header").outerHeight());
	$(".contentSectionView,.contentSection,.contentSection_ContractEdit,.contentSection_Contract").css("margin-top", ($(".filterSection").outerHeight()+$(".home-header").outerHeight()));
});

$( window ).resize(function() {
	$(".filterSection").css("margin-top", $(".home-header").outerHeight());
	$(".contentSectionView,.contentSection,.contentSection_ContractEdit,.contentSection_Contract").css("margin-top", ($(".filterSection").outerHeight()+$(".home-header").outerHeight()));
});