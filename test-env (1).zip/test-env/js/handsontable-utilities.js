
function Handson(containerid){
	
         var container = document.getElementById(containerid);
        var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
         var data;
         console.log("filter"+filter);
         
    		var options = {
    			data:[],
        	    colWidths: [75,125,200,200,80,75,80,80,75,200,140],
        	  //  rowHeights:20,
        	    comments: true,
        	    search:true,
        	    columnSorting: true,
        	    sortIndicator: true,
        	    manualColumnResize: true,
        	    manualRowResize: true, 
        	    preventOverflow: 'horizontal',
        	 //   filters:true,
        	    colHeaders:true,
        	    contextMenu: {
                    items: {  "copy": {name: "Copy"},
                        "paste": {
                            name: 'Paste',
                            callback: function () {
                                this.copyPaste.triggerPaste();
                            }
                        } }
                },
        	    contextMenuCopyPaste: {
        	        swfPath: 'js/ZeroClipboard.swf'
        	      },
        	    fixedColumnsLeft: 1,
        	    manualColumnFreeze:true,
        	  //  dropdownMenu: true,
        	  //  filters:true,
        	    nestedHeaders: [
        	                    [{label: ' ', colspan:5}, {label: 'If in Active Review', colspan:6}],
        	                     [ 'Product','Current Formulary Status','Key Meeting To Date','Account Feedback & Next Steps','Next Meeting Date','Active Review(Y/N)','Bid Due Date','VAC / P&T Dates','VP Engaged (Y/N)','Bid Activity Summary','Projected Formulary Status']],
        	   // colHeaders: [ 'Product', 'Pharmacy Lives','Medical Lives','Current Formulary Status','Contract Expiration Date','Key meeting To Date','Account Feedback & Next Steps','Next Meeting Date','Active review(Y/N)','At Risk(H-M-L)','Bid Due Date','VAC / P&T Dates','Clinical Lead Engaged (Y/N)','VP Engaged (Y/N)','Bid Active Summary','Projected Formulary Status','created_on','last_modified_by','last_modified_on'],
        	     columns: [
                               	   
                                  	   
                               	      {
                                  	      data:'productName',
                                  	      readOnly:true
                                  	   },
                             	      
                             	      
                               	      {
                                	    	 data:'currentFormularyStatus' ,
                                	    	 renderer:safeHtmlRenderer,
                                	    	 allowInvalid: false,
                                             validator: limit_validator_regexp
                               	    	
                               	      },
                               	    	
                               	      {
                                   	      data:'keyMeetingsToDate',
                                   	      renderer:safeHtmlRenderer,
                                   	   allowInvalid: false,
                                       validator: limit_validator_regexp
                                   	    	 
                               	      },
                               	      {
                                	    	 data:'accountFeedback',
                                	    	  renderer:safeHtmlRenderer,
                                	    	  allowInvalid: false,
                                              validator: limit_validator_regexp
                               	    	  
                               	      },
                               	      {
                               	    	  data:'nextMeetingDateTime',
                               	    	  type: 'date',
                             	          dateFormat: 'MM/DD/YYYY',
                             	          correctFormat: true,
                             	          allowEmpty: false,
                             	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                             	          datePickerConfig: {
                             	          // First day of the week (0: Sunday, 1: Monday, etc)
                             	          firstDay: 0,
                             	          showWeekNumber: true,
                             	          numberOfMonths: 1,
                             	          
                             	          }
                               	      },
                               	      
                               	      {
                               	    	data:'isReviewActive',
                               	    	renderer:yesNoRenderer
                               	      },
                               	      {
                              	    	  data:'bidDueDate',
                               	    	  type: 'date',
                             	          dateFormat: 'MM/DD/YYYY',
                             	          correctFormat: true,
                             	          allowEmpty: false,
                             	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                             	          datePickerConfig: {
                             	          // First day of the week (0: Sunday, 1: Monday, etc)
                             	          firstDay: 0,
                             	          showWeekNumber: true,
                             	          numberOfMonths: 1,
                             	          
                             	          }
                               	      },
                               	      {
                              	    	  data:'vacPandTDate',
                               	    	  type: 'date',
                             	          dateFormat: 'MM/DD/YYYY',
                             	          correctFormat: true,
                             	          defaultDate: '2016-06-29',
                             	          allowEmpty: false,
                             	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                             	          datePickerConfig: {
                             	          // First day of the week (0: Sunday, 1: Monday, etc)
                             	          firstDay: 0,
                             	          showWeekNumber: true,
                             	          numberOfMonths: 1,
                             	         
                             	          }
                                  	       
                               	      },
                               	      {
                               	    	data:'isBusinessVpEngaged',
                               	    	renderer:yesNoRenderer
                               	      },
                               	      {
                                	    	 data:'bidActiveSummary' ,
                                	    	   renderer:safeHtmlRenderer,
                                	    	   allowInvalid: false,
                                               validator: limit_validator_regexp
                               	    	    
                               	      },
                               	      {
                                	    	 data:'projectedFormularyStatus' ,
                                	    	  renderer:safeHtmlRenderer,
                                	    	  allowInvalid: false,
                                              validator: limit_validator_regexp
                               	    	
                               	      },
                               	    
                               	    /*  {
                              	    	  data:'last_modified_by',
                              	    	 renderer:safeHtmlRenderer
                                  	       
                               	      },
                               	      {
                              	    	  data:'last_modified_on',
                               	    	  type: 'date',
                             	          dateFormat: 'MM/DD/YYYY',
                             	          correctFormat: true,
                             	          defaultDate: '2016-06-29',
                             	          allowEmpty: false,
                             	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                             	          datePickerConfig: {
                             	          // First day of the week (0: Sunday, 1: Monday, etc)
                             	          firstDay: 0,
                             	          showWeekNumber: true,
                             	          numberOfMonths: 1,
                             	         
                             	          }
                                  	       
                               	      }*/
                               	      ] ,
                               	      
                               	        afterGetColHeader: function(col, TH) {
                    	    var TR = TH.parentNode;
                    	    var THEAD = TR.parentNode;
                    	    var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                    	    function applyClass(elem, className) {
                    	      if (!Handsontable.Dom.hasClass(elem, className)) {
                    	        Handsontable.Dom.addClass(elem, className);
                    	      }
                    	    }

                    	    // first level from the top
                    	    if (headerLevel === -2 && (col===0||col===1||col===2||col===3||col===4)) {
                    	      applyClass(TH, 'color2');

                    	    // second level from the top
                    	    }else if (headerLevel === -2 && (col===5||col===6||col===7||col===8||col===9||col===10)) {
                      	      applyClass(TH, 'activecolor');

                      	    // second level from the top
                      	    } 
                    	    else if (headerLevel === -1) {
                    	    	applyClass(TH, 'color1');
                     	       
                  	      }
                  	     
                       }
                  	      
        	
        	  }
    		
    		var network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
    	
      
    		
}
        	  