
function Handson(containerid){
	
         var container = document.getElementById(containerid);
   //     var limit_validator_regexp = /(^[\s\S]{0,6000}$)/;
    		var options = {
    			data:[],
    			colWidths: [100,100,100,120,140,150,120,140,140,120,150,150,130,100,100,130,120,120,120,120,130,130,130,130,130,130,130,150,150,130,130,130,130,130,130,130,120,120,120,120,100,100,100,100,100,100,100,100,100,100],
        	  //  rowHeights:20,
    			  comments: true,
          	    search:true,
          	    columnSorting: true,
          	    sortIndicator: true,
          	    manualColumnResize: true,
          	    manualRowResize: true, 
          	    preventOverflow: 'horizontal',
          	 //   filters:true,
          	    colHeaders:true,
          	    contextMenu: {
                      items: {  "copy": {name: "Copy"},
                          "paste": {
                              name: 'Paste',
                              callback: function () {
                                  this.copyPaste.triggerPaste();
                              }
                          } }
                  },
          	    contextMenuCopyPaste: {
          	        swfPath: 'js/ZeroClipboard.swf'
          	      },
          	    fixedColumnsLeft: 2,
          	    manualColumnFreeze:true,
        	  //  dropdownMenu: true,
        	  //  filters:true,
          		nestedHeaders: [
        	                    [{label: ' ', colspan:2}, {label: 'EPU Requirements', colspan:27}, {label: 'Data requirements', colspan:4}, {label: 'Immunology Required Data Elements', colspan:17},{label: ' ', colspan:2}],
        	                    // [ 'Current DSA','Field Director','Business Name', 'IBG Tier','Segmentation','PHS Mix','Remicades Pre-Biosim Launch Formulary Status? ','Projected Date of REMICADE vs. Inflectra P&T Formulary Review? ','What do you expect the outcome of the P&T Formulary Review will be for Remicade? ','Remicade Current Formulary Status? ','Inflectra Current Formulary Status? ','Will your customer treat Remicade and the biosimilar as interchangeable?','Do you expect the customer to employ Non-Medical Switching to Inflectra? ','Please add any additional Comments regarding Remicade Access for this Account','Has this account received a  competitive offer?','Was the competitive offer for an individual product,  as part of portfolio overlay, or both','Has the customer compliantly informed you of the net discount range that  will be required by Janssen to maintain competitive access ','Please select the form of  discount requested','Required Date for Remicades competitive pricing/contract response ','Please add any additional VOC regarding the offer required by Janssen to remain competitive in this account.','Total Remicade  Sales $','Rebate Eligible MD Sales','Overlay Contract Status','Remicade Blended Discount; Before Supplemental GPO Offer','Is Janssen putting a Supplemental GPO Discount into the market','Date the Supplemental GPO contract was delivered to customer','Please provide any customer feedback/status regarding the Supplemental GPO Contract Offer','Date the Supplemental GPO contract was signed by the customer','Remicade Proposed Supplemental GPO Discount','Remicade Blended Discount After Supplemental GPO Offer','Please remember CLEAR HCC communication principles while entering the comments','Last Modified By','Last Modified On','Last Confirmed By','Last Confirmed On']],
        	                    //cghosh2 added
        	                     [ 'Field Director','Business Name','Books of business associated with Health Plan','How does the customer state control criteria(e.g. tier placement, NDC block, step edit, quantity limits, prior authorization, etc.)?(Free Text)','Are there varying controls by Book of Business?','Do you have multiple formularies within your health plan?','What is your Level of Control','Explain(Free Text)','Open or Closed Formulary',,'What are your Co-Pay Structures?  Do you have any Therapeutic Classes that don\'t follow traditional tier structures? Traditional brands on tier(Free Text)','In what format do your members access formularies and guidelines? (Free Text)<br><u>Choose all that apply</u><br>Online - Abbreviated<br>Online - Comprehensive<br>E-file - Abbreviated<br>E-file - Comprehensive<br>Other (Explain)','How will you provide access of formularies and guidelines to JJHCS?(Free Text)<br><u>Choose all that apply</u><br>Online - Abbreviated<br>Online - Comprehensive<br>E-file - Abbreviated<br>E-file - Comprehensive<br>Other (Explain)','What is the process for updating Formularies?(Free Text)','How do you notify Providers of changes?','Do you push an e prescribing platform?','Do you provide formularies to any provider EHR system\'s?If yes,please answer the following three questions','Do they use Surescript\'s as their e prescribing platform?(Free Text)','How often do they send updates to the EHR systems?(Free Text)','How does the payer validate the accuracy of the information? (Free Text)','How often do you update Formularies for Product changed (Add, Delete, Change)?Janssen\'s products and DDM','Are non-listed products or therapeutic classes excluded from coverage?','Any customer specific information please add(Free Text)','Do you publish or maintain Medical Benefit Policies For all Medical Benefit Products as evidence of coverage?','If yes - How often do you update?(Free Text)','If no - Please outline when you establish policies?(Free Text)',' Can you provide Co-Insurance / Co-Pay information for medical to validate tier placement?','How often does your P & T committee meet? Schedule?(Free Text)','Where are PA/ST/QL documents? Can you provide documentation to JJHCS for J&J and competitive market basket?(Free Text)','If Product has a mid-quarter start or waiver ends mid quarter, would customer be able to update all documentation to ensure compliance to the terms and conditions of the contract?','Do you have any state law or Dept. of Insurance mandate that governs formulary position or effects notification to providers?','What are the states? Explain the law or mandate (Free Text)','For a Medical Benefit Claim - Can the customer provide the NDC and J Code?(Free Text)','Can customer break out data by plan?(ex. customer who submit by state and not formulary)','Contact Personnel:  Who will be the customer contact for payment team (data), CVA team (formulary/guideline questions. ST/PA questions), etc.?(Free Text)','Can you provide De - Identified Patient ID if requested','Plan Name','NDC','Product Description','Total Quantity','Unit of Measure','Diagnosis Code','Date Of Service','J-Code','Place of service','Allowed Amount','Claim Number','Encrypted Patient ID Code','Any other special cirmstances(free Text)','Customer Contact','Date']],
        	   // colHeaders: [ 'Product', 'Pharmacy Lives','Medical Lives','Current Formulary Status','Contract Expiration Date','Key meeting To Date','Account Feedback & Next Steps','Next Meeting Date','Active review(Y/N)','At Risk(H-M-L)','Bid Due Date','VAC / P&T Dates','Clinical Lead Engaged (Y/N)','VP Engaged (Y/N)','Bid Active Summary','Projected Formulary Status','last_confirmed_by','last_confirmed_on'],
       	         columns: [
                      	    	 
									{
									      data:'customerCapabilityId.fieldDirectorId',
									      readOnly:true
									  },                                 	    
									   {
									      data:'customerCapabilityId.businessNameId',
									      readOnly:true
									   },
									   {
                                 	         data:'customerCapabilityId.bobHealthPlan',
                                 	         //editor: 'select',
                                 	         //renderer:safeHtmlRenderer,
                                 	        //renderer:customRenderer,
                                 	        // selectOptions: ['Part D','Commercial','MAPD','Health Care Exchange'],
                                        	   readOnly:true
                                	    	
                                 	      
                                 	      },
									   /*{
									      data:'customerCapabilityId.ibgTierId',
									      readOnly:true
									   },*/
                                	   {
                                   	      data:'customerStateControlCriteria',
                                   	   renderer:safeHtmlRenderereditable,
                                   	      readOnly:false
                                   	   },
                                   	 {
                                 	         data:'varyingCntrlBob',
                                 	        editor: 'select',
                                 	       renderer:yesNoRenderer,
                                            selectOptions: ['Yes','No',' '],
                                        	   readOnly:false
                                 	      
                                 	      },
                                 	     {
                                  	         data:'formulariesHealthPlan',
                                  	        editor: 'select',
                                  	      renderer:yesNoRenderer,
                                             selectOptions: ['Yes','No',' '],
                                         	   readOnly:false                                         	   
                                  	      
                                  	      },
                                  	   
                                 	       {
                                 	         data:'levelOfControl',
                                 	        editor: 'select',
                                    	      renderer:yesNoRenderer,
                                               selectOptions: ['High','Medium','Low'],
                                  	    	 readOnly:false
                                 	      
                                 	      },
                                 	     {
                                  	         data:'levelOfControlExplain',
                                  	         renderer:safeHtmlRenderereditable,
                                   	    	 readOnly:false
                                  	      
                                  	      },
                                 	     {
                                  	         data:'openClosedFormulary',
                                  	       renderer:safeHtmlRenderereditable,
                                  	       editor: 'select',
                                 	       renderer:yesNoRenderer,
                                            selectOptions: ['Open Formulary','Closed Formulary','Both'],
                                   	    	 readOnly:false
                                  	      
                                 	    	}  ,  
                                 	     {
                                    	     data:'copayStructures',
                                    	     renderer:safeHtmlRenderereditable,
                                     	    readOnly:false
                                    	      
                                    	      },
                                    	 {
                                        	  data:'copayPublishChannel',
                                        	  //editor: 'select',
                                        	  //renderer:yesNoRenderer,
                                              //selectOptions: ['Online - Abbreviated','Online - Comprehensive','Paper - Abbreviated','Paper - Comprehensive','Other','All of the above'],
                                        	// renderer:safeHtmlRenderereditable,
                                        	  renderer: customDropdownRenderer,
                                              editor: 'chosen',
                                              //width: 150,
                                              chosenOptions: {
                                                  multiple: true,
                                                  data: [
                                                      {
                                                          id: "Online - Abbreviated",
                                                          label: "Online - Abbreviated"
                                                      }, {
                                                          id: "Online - Comprehensive",
                                                          label: "Online - Comprehensive"
                                                      }, {
                                                          id: "E-file - Abbreviated",
                                                          label: "E-file - Abbreviated"
                                                      }, {
                                                          id: "E-file - Comprehensive",
                                                          label: "E-file - Comprehensive"
                                                      }, {
                                                          id: "All of the above",
                                                          label: "All of the above"
                                                      }, {
                                                          id: "Other",
                                                          label: "Other"
                                                      }
                                                  ]
                                              },
                                        	 
                                              readOnly:false
                                        	      
                                        	      },
                                        	 {
                                             	  data:'validateJjhcs',
                                               	 // editor: 'select',
                                               	//renderer:yesNoRenderer,
                                                  //selectOptions: ['Online - Abbreviated','Online - Comprehensive','Paper - Abbreviated','Paper - Comprehensive','Other','All of the above'],
                                             	 //renderer:safeHtmlRenderereditable,
                                             	 renderer: customDropdownRenderer,
                                                 editor: 'chosen',
                                                 //width: 150,
                                                 chosenOptions: {
                                                     multiple: true,
                                                     data: [
                                                         {
                                                             id: "Online - Abbreviated",
                                                             label: "Online - Abbreviated"
                                                         }, {
                                                             id: "Online - Comprehensive",
                                                             label: "Online - Comprehensive"
                                                         }, {
                                                             id: "E-file - Abbreviated",
                                                             label: "E-file - Abbreviated"
                                                         }, {
                                                             id: "E-file - Comprehensive",
                                                             label: "E-file - Comprehensive"
                                                         }, {
                                                             id: "All of the above",
                                                             label: "All of the above"
                                                         }, {
                                                             id: "Other",
                                                             label: "Other"
                                                         }
                                                     ]
                                                 },
                                                  readOnly:false
                                                   
                                                   },
                                            {
                                               data:'processFormularies',
                                               renderer:safeHtmlRenderereditable,
                                               readOnly:false
                                              	      
                                             }, 
                                             {
                                           	  data:'notifyProviderChangeChannel',
                                           	  editor: 'select',
                                           	  renderer:yesNoRenderer,
                                                 selectOptions: ['Online','Email'],
                                                 readOnly:false
                                           	      
                                           	      },
                                           	   {
                                           	    	  data:'ePrescribingPlatform',
                                           	    	 editor: 'select',
                                                  	  renderer:yesNoRenderer,
                                                        selectOptions: ['Yes','No'],
                                         	          readOnly:false
                                           	      },
                                           	       {
                                           	    	  data:'formulariesEHR',
                                           	    	 editor: 'select',
                                                  	  renderer:yesNoRenderer,
                                                        selectOptions: ['Yes','No'],
                                         	          readOnly:false
                                           	      },
                                           	       {
                                           	    	  data:'explainEHR',
                                           	    	 renderer:safeHtmlRenderereditable,
                                         	          readOnly:false
                                           	      },
                                           	     {
                                           	    	  data:'explainEHR1',
                                           	    	 renderer:safeHtmlRenderereditable,
                                         	          readOnly:false
                                           	      },
                                           	     {
                                           	    	  data:'explainEHR2',
                                           	    	 renderer:safeHtmlRenderereditable,
                                         	          readOnly:false
                                           	      },
                                           	   {
                                                  data:'formulariesChangeFrequency',
                                                   editor: 'select',
                                                   renderer:yesNoRenderer,
                                                    selectOptions: ['Monthly','Quarterly','Annually','Other'],
                                                     readOnly:false
                                                   	      
                                                     },
                                              {
                                                 data:'nonListedProductCoverage',
                                                 editor: 'select',
                                                 renderer:yesNoRenderer,
                                                 selectOptions: ['Yes','No',' '],
                                                 readOnly:false
                                              	      
                                              	},
                                              	 {
                                                    data:'explananations',
                                                    renderer:safeHtmlRenderereditable,
                                                    readOnly:false
                                                   	      
                                                  },
                                                  {
                                                      data:'maintainMedicalBenifitPolicies',
                                                      editor: 'select',
                                                      renderer:yesNoRenderer,
                                                      selectOptions: ['Yes','No',' '],
                                                      readOnly:false
                                                   	      
                                                   	},
                                                {
                                                  data:'maintainMedicalBenifitPoliciesFrequency',
                                                  renderer:safeHtmlRenderereditable,
                                                  readOnly:false
                                                     	      
                                                 },
                                                 {
                                                     data:'notMaintainMedicalBenifitPoliciesReason',
                                                     renderer:safeHtmlRenderereditable,
                                                     readOnly:false
                                                        	      
                                                    },
                                               {
                                                   data:'copayInfoMedical',
                                                   editor: 'select',
                                                   renderer:yesNoRenderer,
                                                   selectOptions: ['Yes','No',' '],
                                                   readOnly:false
                                                     	      
                                               	},
                                                {
                                       	    	data:'ptComitteSchedule' ,
                                       	    	renderer:safeHtmlRenderereditable,
                                                readOnly:false
                                      	       },
                                                {
                                                    data:'PaStDocumentsToJJHCS',
                                                    renderer:safeHtmlRenderereditable,
                                                    readOnly:false
                                                       	      
                                                   },
                                               {
                                                  data:'updateDocEnsureCompliance',
                                                  editor: 'select',
                                                  renderer:yesNoRenderer,
                                                 selectOptions: ['Yes','No',' '],
                                                  readOnly:false
                                                         	      
                                               },
                                               {
                                                   data:'deptOfInsuranceFormularyPosition',
                                                   editor: 'select',
                                                   renderer:yesNoRenderer,
                                                  selectOptions: ['Yes','No',' '],
                                                   readOnly:false
                                                          	      
                                                },
                                                {
                                                    data:'statesEffectNotification',
                                                    renderer:safeHtmlRenderereditable,
                                                    readOnly:false
                                                       	      
                                                   },
                                               {
                                                  data:'dataCustomerNdcJcode',
                                                  renderer:safeHtmlRenderereditable,
                                                  readOnly:false
                                                          	      
                                                  },
                                                  {
                                                     data:'dataCustomerBreakoutPlan',
                                                     editor: 'select',
                                                     renderer:yesNoRenderer,
                                                     selectOptions: ['Yes','No',' '],
                                                     readOnly:false
                                                             	      
                                                   },
                                                   {
                                                     data:'dataCustomerContactPaymentTeam',
                                                     renderer:safeHtmlRenderereditable,
                                                     readOnly:false
                                                               	      
                                                   },
                                                   {
                                                       data:'identifiedPatientId',
                                                       editor: 'select',
                                                       renderer:yesNoRenderer,
                                                       selectOptions: ['Yes','No',' '],
                                                       readOnly:false
                                                               	      
                                                     },
                                                   /* {
                                                         data:'dataCheckListRequiredDataElement',
                                                         editor: 'select',
                                                         renderer:yesNoRenderer,
                                                         selectOptions: ['Can Provide-Yes','Can not Provide-No',' '],
                                                         readOnly:false
                                                                 	      
                                                       },*/
                                                       
                                                       {
                                                           data:'planName',
                                                           editor: 'select',
                                                           renderer:yesNoRenderer,
                                                           selectOptions: ['Yes','No',' '],
                                                           readOnly:false
                                                                     	      
                                                         },
                                                        {
                                                            data:'ndc',
                                                            editor: 'select',
                                                            renderer:yesNoRenderer,
                                                            selectOptions: ['Yes','No',' '],
                                                            readOnly:false
                                                                       	      
                                                         },
                                                         {
                                                           data:'productDescription',
                                                           editor: 'select',
                                                           renderer:yesNoRenderer,
                                                           selectOptions: ['Yes','No',' '],
                                                           readOnly:false
                                                                         	      
                                                           },
                                                           {
                                                               data:'totalQuantity',
                                                               editor: 'select',
                                                               renderer:yesNoRenderer,
                                                               selectOptions: ['Yes','No',' '],
                                                               readOnly:false
                                                                         	      
                                                             },
                                                            {
                                                                data:'unitOfMeasure',
                                                                editor: 'select',
                                                                renderer:yesNoRenderer,
                                                                selectOptions: ['Yes','No',' '],
                                                                readOnly:false
                                                                
                                                               /* renderer: customDropdownRenderer,
                                                                editor: 'chosen',
                                                                width: 150,
                                                                chosenOptions: {
                                                                    multiple: true,
                                                                    data: [
                                                                        {
                                                                            id: "Yes",
                                                                            label: "Yes"
                                                                        }, {
                                                                            id: "No",
                                                                            label: "No"
                                                                        }, {
                                                                            id: "None",
                                                                            label: "None"
                                                                        }
                                                                    ]
                                                                }*/
                                                                           	      
                                                             },
                                                             {
                                                               data:'diagnosisCode',
                                                               editor: 'select',
                                                               renderer:yesNoRenderer,
                                                               selectOptions: ['Yes','No',' '],
                                                               readOnly:false
                                                                             	      
                                                               },
                                                             
                                                             
                                 	      
                                           {
                                	    	  data:'dateOfService',
                                	    	  /*type: 'date',
                                	    	  renderer:dateRenderer,
                              	          dateFormat: 'MMM DD,YYYY',
                              	          correctFormat: true,
                              	          //defaultDate: '',
                              	          allowEmpty: false,
                              	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                              	          datePickerConfig: {
                              	          // First day of the week (0: Sunday, 1: Monday, etc)
                              	          firstDay: 0,
                              	          showWeekNumber: true,
                              	          numberOfMonths: 1,
                              	          
                              	        },*/
                              	      editor: 'select',
                                      renderer:yesNoRenderer,
                                      selectOptions: ['Yes','No',' '],
                              	        readOnly:false
                                	    	},
                                	    	
                                     	      {
                                      	    	 data:'jCode' ,
                                      	    	readOnly:false,
                                      	    	 editor: 'select',
                                                 renderer:yesNoRenderer,
                                                 selectOptions: ['Yes','No',' '],
                                     	      },
                                     	      {
                                      	    	 data:'placeOfService' ,
                                      	    	 editor: 'select',
                                                 renderer:yesNoRenderer,
                                                 selectOptions: ['Yes','No',' '],
                                      	    	readOnly:false
                                     	    	
                                     	      },
                                     	      
                                     	      {
                                      	    	 data:'allowedAmount' ,
                                      	    	 editor: 'select',
                                                 renderer:yesNoRenderer,
                                                 selectOptions: ['Yes','No',' '],
                                      	    	readOnly:false
                                     	    	
                                     	      },
                                     	      {
                                      	    	 data:'claimnumber' ,
                                      	    	 editor: 'select',
                                                 renderer:yesNoRenderer,
                                                 selectOptions: ['Yes','No',' '],
                                      	    	readOnly:false
                                     	    	
                                     	      },
                                     	      {
                                      	    	 data:'encyptedPatientCode' ,
                                      	    	 editor: 'select',
                                                 renderer:yesNoRenderer,
                                                 selectOptions: ['Yes','No',' '],
                                      	    	readOnly:false
                                     	    	
                                     	      },
                                     	      {
                                      	    	 data:'specialCircumstances' ,
                                      	    	renderer:safeHtmlRenderereditable,
                                      	    	readOnly:false
                                     	    	
                                     	      },
                                             {
                                               data:'updatedBy' ,
                                              renderer:safeHtmlRenderereditable,
                                              readOnly:false
                                            
                                            },
                                             {
                                               data:'date' ,
                                               type: 'date',
                                 	    	  renderer:dateRenderer,
                               	          dateFormat: 'MMM DD,YYYY',
                               	          correctFormat: true,
                               	          //defaultDate: '',
                               	          allowEmpty: false,
                               	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                               	          datePickerConfig: {
                               	          // First day of the week (0: Sunday, 1: Monday, etc)
                               	          firstDay: 0,
                               	          showWeekNumber: true,
                               	          numberOfMonths: 1,
                               	          }
                                             }
                                	   /* {
                                       	   data:'confirmedBy',
                                       	   renderer:safeHtmlRenderer,
                                           readOnly:true
                                       	      
                                       	 },
                                       	 {
                               	    	  data:'confirmedOn',
                               	    	  type: 'date',
                               	    	  renderer:safeHtmlRenderer,
                             	          dateFormat: 'MMM DD,YYYY',
                             	          correctFormat: true,
                             	          //defaultDate: '2016-06-29',
                             	          allowEmpty: false,
                             	        // datePicker additional options (see https://github.com/dbushell/Pikaday#configuration)
                             	          datePickerConfig: {
                             	          // First day of the week (0: Sunday, 1: Monday, etc)
                             	          firstDay: 0,
                             	          showWeekNumber: true,
                             	          numberOfMonths: 1,
                             	          
                             	        },
                             	        readOnly:true
                               	    	}*/
                                    	      
                               	      ] ,
                               	  
                               	        afterGetColHeader: function(col, TH) {
                    	    var TR = TH.parentNode;
                    	    var THEAD = TR.parentNode;
                    	    var headerLevel = (-1) * THEAD.childNodes.length + Array.prototype.indexOf.call(THEAD.childNodes, TR);

                    	    function applyClass(elem, className) {
                    	      if (!Handsontable.Dom.hasClass(elem, className)) {
                    	        Handsontable.Dom.addClass(elem, className);
                    	      }
                    	    }
                    	    /*if (headerLevel === -1 && (col===2 || col===3 ||col===4 || col===5 || col===6 || col===7||col===8||col===9||col===10||col===11||col===12||col===13||col===14||col===15||col===16||col===17)) {
                      	      applyClass(TH, 'highlightcolor');

                      	    }*/
                    	    if (headerLevel === -1 && (col>1 && col<51)) {
                      	      applyClass(TH, 'highlightcolor');
                      	      }
                    	    
                    	    if (headerLevel === -2 && (col===0||col===1)) {
                      	      applyClass(TH, 'color2');

                      	    // second level from the top
                      	    }else if (headerLevel === -2 && (col===2 ||col===3||col===4||col===5||col===6||col===7||col===8||col===9||col===10||col===11||col===12||col===13||col===14||col===15||col===16||col===17||
                      	    col===18||col===19||col===20||col===21||col===22||col===23||col===24||col===25||col===26||col===27||col===28 || col===29)) {
                        	      applyClass(TH, 'bluecolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -2 && (col===30||col===31 || col===32||col===33 )) {
                        	      applyClass(TH, 'marooncolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -2 && ( col>33 && col<51)) {
                        	      applyClass(TH, 'greencolor');

                        	    // second level from the top
                        	    } else if (headerLevel === -1) {
                      	    	applyClass(TH, 'color1');
                       	       
                    	      }
                  	     
                       }
                  	      
        	
        	  }
    		
    		var network = new Handsontable(container, options);
    		
    		this.updateOptions = function(newOptions){
    			console.log("inside update");
    			network.updateSettings(newOptions);
    		}
    		
    		this.render = function(){
    			console.log("inside render");
    			network.render();
    		}
    		
    		this.getSourceData = function(){
    			console.log("inside source");
    			 return network.getSourceData();
    			
    		}
    		
    		var numberValidator = /^\d+$/;
    		
    		var customDateValidator = function(value, callback) {
    			
    			  if (value === '') {
    				  alert(value);
    				  value=null;
    			  } /*else {
    			    Handsontable.DateValidator.call(this, value, callback);
    			  }*/
    			};
    		
    	/*	var notEmpty = function (value, callback) {
    			alert("dghjfdhg");
    			//var numberValidator = /^\d+$/;
    			var patt = new RegExp("/^\d+$/");
    		    if (patt.test(value)) {
    		     //   alert("a number");
    		        
    		    } else {
    		    	 alert("Number needed");
    		    	 callback(false);
    		    }
    		};*/
    		
    	
    			
    			function customDropdownRenderer(instance, td, row, col, prop, value, cellProperties) {
    			    var selectedId;
    			    var optionsList = cellProperties.chosenOptions.data;
    			    $(td).css({"background-color":'#e0e2e5'});
    			    var values = (value + "").split(",");
    			    var value = [];
    			    for (var index = 0; index < optionsList.length; index++) {
    			        if (values.indexOf(optionsList[index].id + "") > -1) {
    			            selectedId = optionsList[index].id;
    			            value.push(optionsList[index].label);
    			        }
    			    }
    			    value = value.join(", ");
    			    var workaround = "<div class='work'>"+value+"</div>";
  	                 $(td).html(workaround);
    			    Handsontable.TextCell.renderer.apply(this, arguments);
    			}   	    	  
       	    	   
    		
}
        	  