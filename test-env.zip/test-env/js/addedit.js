function onload(){
    const stg = document.getElementById('stg')
    console.log(stg)
}
const head = [
    {
      key : 'index',
      thClass : "bg-primary text-light font-weight-bold justify-content-center font-10 nopad",
      tdClass : "smallcol justify-content-center bg-info"
    },
    {
      key: 'bundle_uid',
      label: 'UID',
      sortable: true,
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "smallcol justify-content-center bg-info"
    },
    {
      key: 'customer_name',
      label: 'Customer Name',
      sortable: true,
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "sm-col bg-info"
    },
    {
      key: 'contract_description',
      label: 'Contract Description',
      sortable: true,
      thClass : "bg-primary medcol text-light font-weight-bold font-10",
      tdClass : "sm-col bg-info"
    },
    {
      key: 'bundle_description',
      label: 'Bundle Description',
      sortable: true,
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "bg-info"
    },
    {
      key : 'action',
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "smallcol justify-content-center bg-info",
      _showDetails: true
    },
  ]
const sub = [
    {
      key : 'index',
      tdClass : "smallcol justify-content-center bg-light"
    },
    {
      key: 'bundle_uid',
      label: 'UID',
      sortable: true,
      tdClass : "smallcol bg-light"
    },
    {
      key: 'customer_name',
      label: 'Customer Name',
      sortable: true,
      tdClass : "sm-col bg-light"
    },
    {
      key: 'contract_description',
      label: 'Contract Description',
      sortable: true,
      tdClass : "bg-light medcol"
    },
    {
      key : 'bundle_description',
      label: 'Bundle Description',
      tdClass : "justify-content-center bg-light",
    },
  ]
const dump = [
    {
      "customer_uid" : 2001,
      "customer_name" : "Zinc",
      "contract_description" : "PBM",
      "bundles" : [
        {
          "bundle_uid" : 1001,
          "bundle_description" : "Stelara PsO Additional Rebate",
        }
      ]
    },
    {
      "customer_uid" : 2002,
      "customer_name" : "ITP",
      "contract_description" : "IMM: Remicade, Simponi Aria",
      "bundles" : [
        {
          "bundle_uid" : 1101,
          "bundle_description" : "Immunology ITP Chargeback",
        },
        {
          "bundle_uid" : 1102,
          "bundle_description" : "Immunology Competitive Threat Rebate",
        },
        {
          "bundle_uid" : 1003,
          "bundle_description" : "Immunology Competitive Threat OID",
        }
      ]
    },
    {
      "customer_uid" : 2003,
      "customer_name" : "Prime",
      "contract_description" : "IMM: Portfolio",
      "bundles" : [
        {
          "bundle_uid" : 1201,
          "bundle_description" : "Immunology Overlay",
        },
        {
          "bundle_uid" : 1202,
          "bundle_description" : "Immunology Enhanced MBM Rebate",
        },
      ]
    },
    {
      "customer_uid" : 2004,
      "customer_name" : "CPP",
      "contract_description" : "ONC: 2019 Procrit",
      "bundles" : [
        {
          "bundle_uid" : 1301,
          "bundle_description" : "Immunology CPP Chargeback",
        },
        {
          "bundle_uid" : 1302,
          "bundle_description" : "Immunology CPP Fee",
        },
        {
          "bundle_uid" : 1303,
          "bundle_description" : "Pending",
        }
      ]
    },
    {
      "customer_uid" : 2005,
      "customer_name" : "ESI",
      "contract_description" : "IMM: Remicade ESI (Cigna)",
      "bundles" : [
        {
          "bundle_uid" : 1401,
          "bundle_description" : "Net Price Floor",
        },
        {
          "bundle_uid" : 1402,
          "bundle_description" : "Immunology Enhanced MBM Rebate",
        },
        {
          "bundle_uid" : 1403,
          "bundle_description" : "Immunology Future Formulary",
        }
      ]
    },
    {
      "customer_uid" : 2006,
      "customer_name" : "CVS Caremark",
      "contract_description" : "IMM - MBM Preferred Infusible",
      "bundles" : [
        {
          "bundle_uid" : 1501,
          "bundle_description" : "Net Price Floor",
        },
        {
          "bundle_uid" : 1502,
          "bundle_description" : "Immunology Enhanced MBM Rebate",
        },
        {
          "bundle_uid" : 1503,
          "bundle_description" : "Immunology Rebate",
        }
      ]
    },
    {
      "customer_uid" : 2006,
      "customer_name" : "Ascent/SCO - Stelara",
      "contract_description" : "Immunology Future Formulary",
      "bundles" : [
        {
          "bundle_uid" : 1501,
          "bundle_description" : "IMM: Stelara Ascent/SCO",
        }
      ]
    }
  ]

  /********************************************************************************************************/
  //                                     V2                                                               //
  /********************************************************************************************************/

  const headV2 = [
    /*{
      key : 'index',
      thClass : "bg-primary text-light font-weight-bold justify-content-center font-10 nopad",
      tdClass : "smallcol justify-content-center bg-info"
    },*/
    {
      key: 'customer_name',
      label: 'Customer Name',
      sortable: true,
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "medcol bg-info"
    },
    {
      key: 'contract_description',
      label: 'Contract Description',
      sortable: true,
      thClass : "bg-primary medcol text-light font-weight-bold font-10",
      tdClass : "bg-info"
    },
    /*
    {
      key: 'contract_description',
      label: 'Contract Description',
      sortable: true,
      thClass : "bg-primary medcol text-light font-weight-bold font-10",
      tdClass : "bg-info"
    },
    {
      key: 'bundle_description',
      label: 'Bundle Description',
      sortable: true,
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "bg-info"
    },
    */
    {
      key : 'action',
      thClass : "bg-primary text-light font-weight-bold font-10",
      tdClass : "smallcol justify-content-center bg-info",
      _showDetails: true
    },
  ]